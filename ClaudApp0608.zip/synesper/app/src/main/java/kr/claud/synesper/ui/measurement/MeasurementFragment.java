package kr.claud.synesper.ui.measurement;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import java.util.ArrayList;

import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.data.BleData;
import kr.claud.synesper.databinding.FragmentMeasurementBinding;
import kr.claud.synesper.dsp.ADPCM;
import kr.claud.synesper.dsp.PulseSignal;
import kr.claud.synesper.media.ProfileImage;
import kr.claud.synesper.ui.chart.ChartFragment;
import ky.labsource.LsBluetooth;
import ky.labsource.bluetooth.BLEManager;
import ky.labsource.widget.GraphView;
import ky.labsource.widget.ProgressCircle;
import ky.labsource.widget.ProgressGaugeCircle;

public class MeasurementFragment extends Fragment {
    public static final String TAG = "MeasurementFragment";

    private FragmentMeasurementBinding binding;

    private boolean mGraphState = true;
    private GraphView mGraphViewPCG;
    private GraphView mGraphViewPPG;

    private ImageView mImageViewPlayBaby;
    private ProgressGaugeCircle mProgressCircleMom;

    private Handler mHandler;
    private static final int MSEC_DISABLE_PLAYBABY = 5000;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.i("Measure_Kim","onCreateView");
        MeasurementViewModel measurementViewModel = new ViewModelProvider(this).get(MeasurementViewModel.class);

        binding = FragmentMeasurementBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        mHandler = new Handler();

        initButton();
        initGraphView();
        initMeasurementView();

        AppData ad = AppData.I();
        if(ad.BLE_RECEIVE_STATE_Profile){
            changeGraphState(false);
        }
        //final TextView textView = binding.textMeasurement;
        //measurementViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        Log.d(TAG, "onCreateView().....Measurement");
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.i("Measure_Kim","onViewCreated");
        super.onViewCreated(view, savedInstanceState);

        LsBluetooth lsBt = LsBluetooth.IGet();
        updateBleState(lsBt.getState() == BLEManager.VOBLE_PROFILE_CONNECTED);
        Log.d(TAG, "onViewCreated().....Measurement");
    }

    @Override
    public void onDestroyView() {
        Log.i("Measure_Kim","onDestroyView");
        MainActivity macty = (MainActivity) getActivity();

        macty.destroyChildFragment(MeasurementFragment.class);

        super.onDestroyView();

        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
        }
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        //kim (수정) -> 다시 측정화면으로 돌아오면 player 시작
        //MainActivity macty = (MainActivity) getActivity();
        //macty.setSupportActionBar(binding.toolbar);
        Log.i("Measure_Kim","onResume");

        binding.toolbar.setNavigationIcon(R.drawable.ic_baseline_dehaze_24);
        binding.toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity macty = (MainActivity) getActivity();
                macty.clickDrawerMenuByMeasurementFragment();
            }
        });
    }


    public enum HELPTYPE {
        START(0), STOP(1), STORE(2);

        int index;
        HELPTYPE(int index) {
            this.index = index;
        }

        public int index() {
            return this.index;
        }
    }

    private void updateMeasurementHelp(HELPTYPE helpType) {
        switch (helpType.index()) {
            case 0: // START
                binding.imageViewRecTop.setImageResource(R.drawable.measurement_1_button_1);
                binding.imageButtonRec.setImageResource(R.drawable.measurement_1_button_4);
                binding.textViewRecMsg.setText(R.string.rec_msg_start);
                binding.imageButtonUsage.setVisibility(View.VISIBLE);
                break;
            case 1: // STOP
                binding.imageViewRecTop.setImageResource(R.drawable.measurement_2_button_1);
                binding.imageButtonRec.setImageResource(R.drawable.measurement_2_button_2);
                binding.textViewRecMsg.setText(R.string.rec_msg_stop);
                binding.imageButtonUsage.setVisibility(View.GONE);
                break;
            case 2: // STORE
                //binding.imageViewRecTop.setImageResource(R.drawable.measurement_1_button_1);
                binding.imageViewRecTop.setImageResource(R.drawable.measurement_3_bottom_1);
                binding.imageButtonRec.setImageResource(R.drawable.measurement_1_button_4);
                //binding.textViewRecMsg.setText(R.string.rec_msg_start);
                binding.textViewRecMsg.setText(R.string.rec_msg_save);
                binding.imageButtonUsage.setVisibility(View.GONE);
                break;
        }
    }
    //-----------------------------------------------
    private void initButton() {
        MainActivity macty = (MainActivity) getActivity();
        ProfileImage pi = AppData.I().mUserData.mProfileImage;
        updateProfilePhoto(pi.getImage());
        //kim(수정)
        binding.imageToolProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppData ad = AppData.I();
                boolean result = ad.changeBLE_RECEIVE_STATE_Profile(MeasurementFragment.this);
                Log.i("imageToolProfile","click");
                Log.i("imageToolProfile","결과 : "+result);
                macty.clickProfileToolByMeasurementFragment();
            }
        });

        binding.imageButtonUsage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                macty.clickUsageByMeasurementFragment(false);
            }
        });


        //kim -> 측정 기록
        binding.imageButtonRec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //kim (수정) -> TX 데이터가 전체 없으면 버림
//                while()
                updatePPGUi(0, 0, 0);
                macty.clickMeasureByMeasurementFragment();
            }
        });

        //-------------------------------------------
        // init imageViewSave
        binding.imageViewSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateMeasurementSave(false);

                updateMeasurementState(false);
                updateMeasurementHelp(HELPTYPE.START);

                macty.clickSaveByMeasurementFragment();
            }
        });
        updateMeasurementSave(false);

        AppData ad = AppData.I();
        updateSpeakerUi(ad.mPrefVolumeOn);
        binding.imageViewSpeaker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                macty.clickVolumeByMeasurementFragment();
                updateSpeakerUi(ad.mPrefVolumeOn);
            }
        });
    }

    private void initGraphView() {
        mGraphViewPCG = (GraphView) binding.graphViewStetho;
        mGraphViewPCG.setMinMaxValue((float)-500, (float)500);
        mGraphViewPCG.setGraphStyle(Color.rgb(0, 211, 251), 7.0f);
        mGraphViewPCG.enableAxis(false);
        mGraphViewPCG.enableGuideline(false);

        mGraphViewPPG = (GraphView) binding.graphViewPPG;
        mGraphViewPPG.setMinMaxValue((float)-500, (float)500);
        mGraphViewPPG.setGraphStyle(Color.rgb(171, 147, 227), 7.0f);
        mGraphViewPPG.enableAxis(false);
        mGraphViewPPG.enableGuideline(false);

        mGraphState = true;
    }

    private void initMeasurementView() {
/*
        ArrayList<ProgressCircle.Divider> dividerList = new ArrayList<ProgressCircle.Divider>();
        dividerList.add(new ProgressCircle.Divider(0.25f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.50f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.75f, 1.00f, Color.GREEN, "GOOD", Color.rgb(255, 167, 38)));
        dividerList.add(new ProgressCircle.Divider(1.00f, 1.00f, Color.GREEN, "GOOD", Color.rgb(81, 196, 203)));

        mProgressCircleResult = binding.progressCircleResult;
        mProgressCircleResult.setDividerList(dividerList);
        mProgressCircleResult.setTextGravity(Gravity.CENTER_VERTICAL);
        mProgressCircleResult.setEnable(false);
        mProgressCircleResult.setEnableText(false);
        //mProgressCircleResult.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_heart_border_24));
        mProgressCircleResult.setProgress(0.0f, 0.9f);
        mProgressCircleResult.sweepProgress();
*/

        mImageViewPlayBaby = binding.imageViewPlayBaby;

        mProgressCircleMom = binding.progressCircleMom;
        mProgressCircleMom.setTextGravity(Gravity.BOTTOM);
        mProgressCircleMom.setMinMax(0.f, 250.f);
        mProgressCircleMom.setRange(0.f, 0.f);
        mProgressCircleMom.setValue(0.0f, false);
        mProgressCircleMom.sweepProgress();

        updateMeasurementState(false);
    }

    public void updateProfilePhoto(Bitmap bitmap) {
        if (bitmap != null) {
            binding.imageToolProfile.setImageBitmap(bitmap);
        } else {
            binding.imageToolProfile.setImageResource(R.drawable.profile_app_bar_icon1);
        }
    }

    private int playBabyColorFilter = -1;

    private void setColorBabyControls(int ivColor, int textColor) {
        if (ivColor != playBabyColorFilter) {
            playBabyColorFilter = ivColor;
            mImageViewPlayBaby.setColorFilter(playBabyColorFilter);
            binding.textViewBabyPulse.setTextColor(textColor);
        }
    }

    public void updatePCGUi(int pcgBpm, int pcgMin, int pcgMax) {
        if (pcgBpm > 0) {
            mHandler.removeCallbacksAndMessages(null);

            int cfGood = ContextCompat.getColor(getActivity(), R.color.measure_good);
            int textColor = getResources().getColor(R.color.synesper_text);
            setColorBabyControls(cfGood, textColor);

            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    int cfDisable = ContextCompat.getColor(getActivity(), R.color.measure_disable);
                    int textColor = getResources().getColor(R.color.synesper_text_lightgray);
                    setColorBabyControls(cfDisable, textColor);
                }
            }, MSEC_DISABLE_PLAYBABY);
        } else if (pcgBpm == 0) {
            mHandler.removeCallbacksAndMessages(null);
            int cfDisable = ContextCompat.getColor(getActivity(), R.color.measure_disable);
            int textColor = getResources().getColor(R.color.synesper_text_lightgray);
            setColorBabyControls(cfDisable, textColor);
        }
    }

    public void updatePPGUi(int ppgBpm, int ppgMin, int ppgMax) {
        if (ppgBpm <= 0)
            return;

        //Log.d(TAG, "ppg=" + ppgBpm + ", min=" + ppgMin + ", max=" + ppgMax);
        mProgressCircleMom.setValue((float) ppgBpm, false);
        mProgressCircleMom.setText("" + ppgBpm);
        if (ppgMax >= ppgMin && ppgMin > 0) {
            mProgressCircleMom.setRange((float) ppgMin, (float) ppgMax);
            mProgressCircleMom.sweepProgress();
        }
        mProgressCircleMom.invalidate();
    }

    public void updateMeasuringUi(int pcgBpm, int ppgBpm) {
        updatePCGUi(pcgBpm, 0, 0);
        updatePPGUi(ppgBpm, 0, 0);
    }

    private void updateSpeakerUi(boolean bOn) {
        ImageView ivSpk = binding.imageViewSpeaker;
        if (bOn) {
            ivSpk.setImageResource(R.drawable.ic_baseline_volume_up_24);
        } else {
            ivSpk.setImageResource(R.drawable.ic_baseline_volume_off_24);
        }
    }


    // TODO: Next Version
    //private static final boolean BabyPulse_not_supported = true;

    private void updateMeasurementState(boolean bEnable) {
        boolean momEnable = bEnable;
        //boolean babyEnable = (BabyPulse_not_supported) ? false : bEnable;
        boolean babyEnable = false; //bEnable;
        MainActivity macty = (MainActivity) getActivity();

        int momTextColor = (momEnable) ? getResources().getColor(R.color.synesper_text) : getResources().getColor(R.color.synesper_text_lightgray);
        int momFilterColor = (momEnable) ? ContextCompat.getColor(macty, R.color.measure_good): ContextCompat.getColor(macty, R.color.measure_disable);
        //binding.textViewMomPulse.setTextColor(momTextColor);
        binding.imageViewHeartMom.setColorFilter(momFilterColor);
        mProgressCircleMom.setEnable(momEnable);
        mProgressCircleMom.invalidate();

        int babyTextColor = (babyEnable) ? getResources().getColor(R.color.synesper_text) : getResources().getColor(R.color.synesper_text_lightgray);
        int babyFilterColor = (babyEnable) ? ContextCompat.getColor(macty, R.color.measure_good) : ContextCompat.getColor(macty, R.color.measure_disable);
        setColorBabyControls(babyFilterColor, babyTextColor);

        binding.textViewTimeLapse.setTextColor(momTextColor);
        binding.imageViewRecState.setColorFilter(momFilterColor);
        binding.imageViewRecState.setVisibility(View.VISIBLE);
    }

    private void updateMeasurementSave(boolean bEnable) {
        if (bEnable) {
            binding.imageViewSave.setEnabled(true);
            // change "app:tint"
            binding.imageViewSave.setColorFilter(ContextCompat.getColor(getContext(), R.color.synesper_500));
        } else {
            binding.imageViewSave.setEnabled(false);
            // change "app:tint"
            binding.imageViewSave.setColorFilter(ContextCompat.getColor(getContext(), R.color.measure_disable));
        }
    }

    public void showToolbar(boolean bShow) {
        binding.toolbar.setVisibility(bShow ? View.VISIBLE : View.GONE);
    }

    public void updateBleState(boolean bConnected) {
        MainActivity macty = (MainActivity) getActivity();
        if (bConnected) {
            binding.imageViewDeviceState.setImageResource(R.drawable.synesper_device_state);
            binding.imageViewBluetooth.setImageResource(R.drawable.ic_baseline_bluetooth_connected_24);
            binding.imageViewBluetooth.setColorFilter(ContextCompat.getColor(macty, R.color.bluetooth_color));

            binding.imageButtonRec.setEnabled(true);
            binding.imageButtonRec.setImageResource(R.drawable.measurement_1_button_4);
        } else {
            binding.imageViewDeviceState.setImageResource(R.drawable.synesper_device_disable);
            binding.imageViewBluetooth.setImageResource(R.drawable.ic_baseline_bluetooth_disabled_24);
            binding.imageViewBluetooth.setColorFilter(ContextCompat.getColor(macty, R.color.measure_disable));

            binding.imageButtonRec.setEnabled(false);
            binding.imageButtonRec.setImageResource(R.drawable.measurement_1_button_4_disable);
        }
    }

    //---------------------------------------
    public void MeasurementManager_StateChanged(boolean bMeasurement) {
        if (bMeasurement) {
            updateMeasurementState(true);
            updateMeasurementHelp(MeasurementFragment.HELPTYPE.STOP);

            updateMeasurementSave(false);
        } else {
            updateMeasurementState(true);
            updateMeasurementHelp(MeasurementFragment.HELPTYPE.STORE);

            updateMeasurementSave(true);
        }
    }

    public void MeasurementManager_TimeLapse(int timeLapse) {
        String szTimeLapse = String.format("%02d:%02d", timeLapse/60, timeLapse%60);
        binding.textViewTimeLapse.setText(szTimeLapse);

        if (timeLapse%2 == 0) {
            binding.imageViewRecState.setVisibility(View.VISIBLE);
        } else {
            binding.imageViewRecState.setVisibility(View.GONE);
        }
    }

    public void MeasurementManager_BeatDetected(int type) {
        switch (type) {
            case MeasurementManager.BEATTYPE_MOM:
                binding.imageViewHeartMom.setImageResource(R.drawable.ic_heart_border_24);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        binding.imageViewHeartMom.setImageResource(R.drawable.ic_heart_border_12);
                    }
                }, 50);
                break;

            case MeasurementManager.BEATTYPE_BABY:
                break;
        }
    }

    //---------------------------------------
    private static ADPCM.State mAdpcmState;
    private static PulseSignal.MovingAverage maPCG;
    static {
        mAdpcmState = new ADPCM.State();
        mAdpcmState.reset();

        maPCG = new PulseSignal.MovingAverage();
    }

    public void updateGraph(short[] adpcmVoice) {
        if (!mGraphState)
            return;

        if (mGraphViewPCG != null) {
            mGraphViewPCG.updateWaveform(adpcmVoice);
        }
    }

    public void updatePPGGraph(short[] ppgSamples, short ppgMin, short ppgMax) {
        if (!mGraphState)
            return;

        if (mGraphViewPPG != null) {
            mGraphViewPPG.updateWaveform(ppgSamples);
        }
    }

    public void changeGraphState(boolean bState) {
        mGraphState = bState;

        mGraphViewPCG.setZOrderOnTop(bState);
        mGraphViewPPG.setZOrderOnTop(bState);

        if (!bState) {
            mGraphViewPCG.clearWaveform();
            mGraphViewPPG.clearWaveform();
        }
    }
}