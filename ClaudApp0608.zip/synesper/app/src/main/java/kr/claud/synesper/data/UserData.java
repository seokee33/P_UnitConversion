package kr.claud.synesper.data;

import android.content.Context;
import android.icu.util.TimeUnit;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

import kotlin.time.DurationUnit;
import kr.claud.synesper.R;
import kr.claud.synesper.media.ProfileImage;

public class UserData {

    public DBHelper.UserItem mUser = new DBHelper.UserItem();

    public String mDevName = null;
    public String mDevAddr = null;
    public ProfileImage mProfileImage = null;

    private Context _ctx;

    public UserData(Context ctx) {
        this._ctx = ctx;

        mProfileImage = new ProfileImage(ctx);
    }


    public DBHelper.UserItem user() {
        return mUser;
    }

    public void setUser(DBHelper.UserItem user) {
        this.mUser.num = user.num;
        this.mUser.id = user.id;
        this.mUser.name = user.name;
        this.mUser.passwd = user.passwd;
        this.mUser.email = user.email;
        this.mUser.delivery = user.delivery;
    }

    public void setDevice(String devName, String devAddr) {
        this.mDevName = devName;
        this.mDevAddr = devAddr;
    }

    public void setProfileImage() {
        if (mUser == null) {
            mProfileImage.clearImage();
            return;
        }
        mProfileImage.setImage(userId());
    }

    //------------------------------------------------
    public static int weeksPregnantFromDelivery(Date curDate, int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        return weeksPregnantFromDelivery(curDate, c.getTime());
    }

    public static int weeksPregnantFromDelivery(Date curDate, String strDelivery) {
        Date dateDelivery = DBHelper.dateFromString(strDelivery, null);
        if (dateDelivery == null) {
            return 0;
        }
        return weeksPregnantFromDelivery(curDate, dateDelivery);
    }

    //kim(수정) : 임신주기 실제 변환하는 곳
    public static int weeksPregnantFromDelivery(Date curDate, Date dateDelivery) {
//        long diff = dateDelivery.getTime() - curDate.getTime(); //원래
        long diff = curDate.getTime() - dateDelivery.getTime();
        int numOfDays = (int)(diff / (1000*60*60*24));
//        int week = (280 - numOfDays) / 7;
//        int week = (int)(numOfDays/7)+1;
        int week = ((int)(numOfDays+280)/7);
        return week;
    }
    //------------------------------------------------
    public int userNum() {
        return mUser.num;
    }

    public String userId() {
        return mUser.id;
    }
    public void setUserId(String userId) {
        mUser.id = userId;
    }

    public String userName() {
        return mUser.name;
    }
    public void setUserName(String name) {
        mUser.name = name;
    }

    public String userPasswd() {
        return mUser.passwd;
    }
    public void setUserPasswd(String passwd) {
        mUser.passwd = passwd;
    }

    public String userEmail() {
        return mUser.email;
    }
    public void setUserEmail(String email) {
        mUser.email = email;
    }

    public String userDelivery() {
        return mUser.delivery;
    }
    public void setUserDelivery(String delivery) {
        mUser.delivery = delivery;
    }

    public int userWeek() {
        return UserData.weeksPregnantFromDelivery(new Date(), mUser.delivery);
    }
}
