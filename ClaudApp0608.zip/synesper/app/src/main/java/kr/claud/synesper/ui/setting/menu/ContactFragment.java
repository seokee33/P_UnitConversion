package kr.claud.synesper.ui.setting.menu;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import kr.claud.libs.crypto.AES256Chiper;
import kr.claud.libs.enums.KeySize;
import kr.claud.libs.internet.Email;
import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.databinding.FragmentContactBinding;
import kr.claud.synesper.dialog.DialogUtil;

public class ContactFragment extends Fragment {
    public static final String TAG = "ContactFragment";

    private FragmentContactBinding binding;

    private EditText editTextUserName;
    private EditText editTextEmail;
    private EditText editTextModel;
    private EditText editTextSubject;
    private EditText editTextContent;
    private Button buttonSubmit;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ContactViewModel contactViewModel = new ViewModelProvider(this).get(ContactViewModel.class);

        binding = FragmentContactBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initContact(root);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    //----------------------------------------------------------
    ActivityResultLauncher<Intent> emailActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                    if (data != null && result.getResultCode() == RESULT_OK) {

                    } else if (result.getResultCode() == RESULT_CANCELED) {

                    }
                }
            });


    private void sendInquiry(String subject, String content) {
        if (AppData.emailEncoded == null || AppData.pwEncoded == null)
            return;

        AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
        String emailDecoded = null;
        String pwDecoded = null;

        try {
            emailDecoded = aes.AES_Decode(AppData.emailEncoded);
            pwDecoded = aes.AES_Decode(AppData.pwEncoded);
            //Log.d(TAG, "Decoded=" + emailDecoded + "/" + pwDecoded);
        } catch (NoSuchPaddingException | BadPaddingException | InvalidKeyException | IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException | InvalidAlgorithmParameterException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }

        if (emailDecoded == null || pwDecoded == null) {
            return;
        }

        Email email = new Email(emailDecoded, pwDecoded, Email.MailProvider.GMAIL);
        email.viaHtml(emailDecoded, subject, content, new Email.OnEmailListener() {
            @Override
            public void onDone(boolean bResult) {
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bResult) {
                            DialogUtil.showDialogMessage(getActivity(), getString(R.string.menu_contact), "제출되었습니다.", null);
                        } else {
                            DialogUtil.showDialogMessage(getActivity(), getString(R.string.menu_contact), "전송에 실패하였습니다.", null);
                        }
                    }
                });
            }
        });
/*
        Intent emailIntent = Email.buildMailIntent("pysbill@gmail.com", subject, content);

        if (emailIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            emailActivityResultLauncher.launch(emailIntent);
        }
 */
        //DialogUtil.showDialogMessage(getActivity(), getString(R.string.menu_contact), "제출되었습니다.", null);
    }


    private void initContact(View root) {
        editTextUserName = (EditText) root.findViewById(R.id.editUsername);
        editTextEmail = (EditText) root.findViewById(R.id.editEmail);
        editTextModel = (EditText) root.findViewById(R.id.editModel);
        editTextSubject = (EditText) root.findViewById(R.id.editSubject);
        editTextContent = (EditText) root.findViewById(R.id.editInquiry);

        buttonSubmit = (Button) root.findViewById(R.id.buttonSubmit);
        buttonSubmit.setEnabled(false);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String szSubject = editTextSubject.getText().toString().trim();
                Log.d(TAG, "buttonSubmit: szSubject=" + szSubject);
                if (szSubject.length() == 0) {
                    DialogUtil.showDialogMessage(getActivity(), getString(R.string.menu_contact), "제목을 입력하세요.", null);
                    return;
                }

                String szContent = editTextContent.getText().toString().trim();
                Log.d(TAG, "buttonSubmit: szContent=" + szContent);
                if (szContent.length() == 0) {
                    DialogUtil.showDialogMessage(getActivity(), getString(R.string.menu_contact), "문의 내용을 작성하세요.", null);
                    return;
                }

                String szName = editTextUserName.getText().toString();
                String szEmail = editTextEmail.getText().toString();
                String szModel = editTextModel.getText().toString();
                String szBody = buildEmailBody(szName, szEmail, szModel, szSubject, szContent);
                sendInquiry(szSubject, szBody);
            }
        });

        AppData ad = AppData.I();
        UserData ud = ad.mUserData;
        editTextUserName.setText(ud.userName());
        editTextEmail.setText(ud.userEmail());
        if (ud.mDevName != null && ud.mDevAddr != null) {
            editTextModel.setText(ud.mDevName + "(" + ud.mDevAddr + ")");
        }

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                String szSubject = editTextSubject.getText().toString().trim();
                String szContent = editTextContent.getText().toString().trim();

                if (szSubject.length() == 0 || szContent.length() == 0) {
                    buttonSubmit.setEnabled(false);
                } else {
                    buttonSubmit.setEnabled(true);
                }
            }
        };

        editTextSubject.addTextChangedListener(afterTextChangedListener);
        editTextContent.addTextChangedListener(afterTextChangedListener);
    }

    private String buildEmailBody(String username, String email, String model, String subject, String content) {
        String newContent = content.replace("\n", "<br>");
        String strHeader = "사용자: " + ((username!=null) ? username : "") + "<br>이메일: " + ((email!=null) ? email : "") + "<br>모델명: " + ((model!=null) ? model : "");
        String strBody = "<div style='color:black;'>" +  strHeader + "<br>--------------------------------------------------<br><br>" + "문의내용:<br>" + newContent + "</div>";
        return strBody;
    }
}