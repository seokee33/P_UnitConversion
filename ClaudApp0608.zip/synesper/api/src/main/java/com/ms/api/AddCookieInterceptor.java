package com.ms.api;

import android.content.SharedPreferences;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AddCookieInterceptor implements Interceptor {
    private final SharedPreferences sharedPreferences;

    public AddCookieInterceptor(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request.Builder builder = chain.request().newBuilder();

        // 쿠키를 가져와서 Request에 추가
        String cookieString = sharedPreferences.getString("cookie", "");
        builder.addHeader("Cookie", cookieString);

        return chain.proceed(builder.build());
    }
}