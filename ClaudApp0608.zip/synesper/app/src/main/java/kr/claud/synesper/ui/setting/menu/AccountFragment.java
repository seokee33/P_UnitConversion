package kr.claud.synesper.ui.setting.menu;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONException;

import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.ms.api.changeuser.ChangeAccount;
import com.ms.api.login.Login;
import kr.claud.libs.crypto.AES256Chiper;
import kr.claud.libs.enums.KeySize;
import kr.claud.synesper.AppData;
import kr.claud.synesper.BuildConfig;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.UserActivity;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.databinding.FragmentAccountBinding;
import kr.claud.synesper.dialog.DialogUtil;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AccountFragment extends Fragment {
    public static final String TAG = "AccountFragment";

    public AccountViewModel mViewModel;
    private FragmentAccountBinding binding;

    private boolean bUsernameChanged = false;
    private boolean bPasswdChanged = false;
    private boolean bEmailChanged = false;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mViewModel = new ViewModelProvider(this).get(AccountViewModel.class);

        binding = FragmentAccountBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //final TextView textView = binding.textAccount;
        //accountViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mViewModel.getAccountFormState().observe(getViewLifecycleOwner(), new Observer<AccountFormState>() {
            @Override
            public void onChanged(AccountFormState accountFormState) {
                if (accountFormState == null) {
                    return;
                }
                //nextButton.setEnabled(accountFormState.isDataValid());
                if (accountFormState.getUsernameError() != null) {
                    binding.username.setError(getString(accountFormState.getUsernameError()));
                }
                if (accountFormState.getPasswordError() != null) {
                    binding.password.setError(getString(accountFormState.getPasswordError()));
                }
                if (accountFormState.getPasswordNewError() != null) {
                    binding.passwordNew.setError(getString(accountFormState.getPasswordNewError()));
                }
                if (accountFormState.getPasswordConfirmError() != null) {
                    binding.passwordConfirm.setError(getString(accountFormState.getPasswordConfirmError()));
                }
            }
        });

        binding.tvAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String password = binding.password.getText().toString();
                Log.i("kimkimkim",password.toString());
                if (password.length() > 0) {
                    Log.i("kimkimkim","true");
                    account(password);
                } else {
                    DialogUtil.showDialogMessage(getActivity(), "비밀번호를 입력해주세요", "회원 탈퇴를 진행하려면 비밀번호를 입력하셔야 합니다.", null);
                }

            }
        });

        initButton();
        initTextView();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void initButton() {
        Activity acty = getActivity();
        binding.buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userName = null;
                String password = null;
                String passwordNew = null;
                String email = null;
                if (bPasswdChanged) {
                    AccountFormState accountFormState = mViewModel.getAccountFormState().getValue();

                    if (accountFormState.getPasswordError() != null) {
                        DialogUtil.showDialogMessage(acty, "비밀번호", "잘못된 비밀번호 형식입니다. 다시 입력하세요.", null);
                        return;
                    }
                    if (accountFormState.getPasswordNewError() != null) {
                        DialogUtil.showDialogMessage(acty, "새 비밀번호", "잘못된 비밀번호 형식입니다. 다시 입력하세요.", null);
                        return;
                    }
                    if (accountFormState.getPasswordConfirmError() != null) {
                        DialogUtil.showDialogMessage(acty, "비밀번호 확인", "잘못된 비밀번호 형식입니다. 다시 입력하세요.", null);
                        return;
                    }

                    AppData ad = AppData.I();
                    UserData ud = ad.mUserData;
                    password = binding.password.getText().toString();
                    String passwdAES;
                    try {
                        AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
                        passwdAES = aes.AES_Encode(password);
//                        passwdAES = StringToAES256.encry(password);
                    } catch (UnsupportedEncodingException | NoSuchPaddingException |
                             IllegalBlockSizeException | NoSuchAlgorithmException |
                             BadPaddingException | InvalidKeyException |
                             InvalidAlgorithmParameterException e) {
                        throw new RuntimeException(e);
                    }
                    if (ud.mUser.passwd.compareTo(passwdAES) != 0) {
                        DialogUtil.showDialogMessage(acty, "비밀번호", "비밀번호를 다시 입력하세요.", null);
                        return;
                    }

                    passwordNew = binding.passwordNew.getText().toString();
                    String passwordConfirm = binding.passwordConfirm.getText().toString();
                    if (passwordNew.compareTo(passwordConfirm) != 0) {
                        DialogUtil.showDialogMessage(acty, "비밀번호 확인", "비밀번호를 확인하고 다시 입력하세요.", null);
                        return;
                    }
                    bPasswdChanged = false;
                }
                if (bUsernameChanged) {
                    bUsernameChanged = false;
                    userName = binding.username.getText().toString();
                }
                if (bEmailChanged) {
                    bEmailChanged = false;
                    email = binding.editTextEmail.getText().toString();
                }
                if(password.length() == 0 || passwordNew.length() == 0){
                    return;
                }else{
                    updateApplyButtonUi();

                    //kim (수정) -> 서버 연동
                    changeUserData(userName, passwordNew, email);
                }
            }
        });



    }

    private void account(String password) {

        try {
            Login.account(password, new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if(response.isSuccessful()){
                        if(response.code() == 200){
                            Log.i("kimkimkim","drop");
                            AppData.clearPreferences(getActivity());
                            AppData ad = AppData.I();
//                            ad.clearDB();
                            ad.mAutoLogin = false;
                            getActivity().finish();
                            Intent intent = new Intent(getActivity(), UserActivity.class);
                            startActivity(intent);
                        }
                    }else{
                        DialogUtil.showDialogMessage(getActivity(),"회원탈퇴 실패","비밀번호를 다시 입력해주세요.",null);
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    DialogUtil.showDialogMessage(getActivity(),"회원탈퇴 실패","서버접속 오류입니다. 잠시후 다시 실행해주세요",null);
                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void changeUserData(String userName, String passwordNew, String email) {
        String passwdAES;
        try {
            AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
            passwdAES = aes.AES_Encode(passwordNew);
//            passwdAES = StringToAES256.encry(passwordNew);
        } catch (UnsupportedEncodingException | NoSuchPaddingException | IllegalBlockSizeException |
                 NoSuchAlgorithmException | BadPaddingException | InvalidKeyException |
                 InvalidAlgorithmParameterException e) {
            throw new RuntimeException(e);
        }

        try {
            ChangeAccount.password(passwordNew, new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if (response.isSuccessful()) {
                        if (response.code() == 200) {
                            MainActivity macty = (MainActivity) getActivity();
                            macty.clickApplyByAccountFragment(userName, passwdAES, email);
                            Toast.makeText(getContext(), "비밀번호가 변경되었습니다.", Toast.LENGTH_LONG).show();
                            Log.i("changeUserData", "Success");
                        } else {
                            //200 코드가 아님...
                            Log.i("changeUserData", "Fail : response.isSuccessful");
                            Toast.makeText(getContext(), "비밀번호 변경 실패 했습니다.", Toast.LENGTH_LONG).show();
                        }
                    } else {
                        //성공했지만... 오류(안됨)
                        Log.i("changeUserData", "Fail : " + response.code());
                        Toast.makeText(getContext(), "비밀번호 변경 실패 했습니다.", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.i("changeUserData", "Fail : " + call.toString());
                    Toast.makeText(getContext(), "비밀번호 변경 실패 했습니다.", Toast.LENGTH_LONG).show();
                }
            });
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }

    private void initTextView() {
        AppData ad = AppData.I();
        UserData ud = ad.mUserData;
        if (BuildConfig.USER_TYPE == BuildConfig.USER_TYPE_SINGLE) {
            binding.username.setText(ad.mUserData.userId());
            binding.username.setEnabled(false);
        } else {
            binding.username.setText(ud.userId());
        }
        binding.editTextEmail.setText(ud.userEmail());

        TextWatcher afterUsernameChangedListener = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String userName = null;
                if (binding.username.getText().toString().length() > 0) {
                    userName = binding.username.getText().toString();
                }

                mViewModel.registerDataChanged(userName, null, null, null);
                bUsernameChanged = true;

                updateApplyButtonUi();
            }
        };

        TextWatcher afterPasswdChangedListener = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String userName = binding.username.getText().toString();
                String password = null;
                String passwordNew = null;
                String passwordConfirm = null;
                if (binding.password.getText().toString().length() > 0) {
                    password = binding.password.getText().toString();
                }
                if (binding.passwordNew.getText().toString().length() > 0) {
                    passwordNew = binding.passwordNew.getText().toString();
                }
                if (binding.passwordConfirm.getText().toString().length() > 0) {
                    passwordConfirm = binding.passwordConfirm.getText().toString();
                }

                mViewModel.registerDataChanged(userName, password, passwordNew, passwordConfirm);
                bPasswdChanged = true;

                updateApplyButtonUi();
            }
        };

        TextWatcher afterEmailChangedListener = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                bEmailChanged = true;
                updateApplyButtonUi();
            }
        };

        binding.username.addTextChangedListener(afterUsernameChangedListener);
        binding.password.addTextChangedListener(afterPasswdChangedListener);
        binding.passwordNew.addTextChangedListener(afterPasswdChangedListener);
        binding.passwordConfirm.addTextChangedListener(afterPasswdChangedListener);
        binding.editTextEmail.addTextChangedListener(afterEmailChangedListener);
    }

    private void updateApplyButtonUi() {
        if (bUsernameChanged || bPasswdChanged || bEmailChanged) {
            binding.buttonApply.setEnabled(true);
        } else {
            binding.buttonApply.setEnabled(false);
        }
    }
}