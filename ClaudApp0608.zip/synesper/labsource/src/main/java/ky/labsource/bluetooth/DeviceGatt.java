package ky.labsource.bluetooth;


import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import ky.labsource.bluetooth.ble.UUIDGroup;

import static ky.labsource.bluetooth.BLEManager.ACTION_DATA_AVAILABLE;
import static ky.labsource.bluetooth.BLEManager.ACTION_DESCRIPTOR_WRITE;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_CONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_DISCONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_SERVICES_DISCOVERED;

public class DeviceGatt extends BluetoothGattCallback {
    private final static String TAG = DeviceGatt.class.getSimpleName();

    protected Context mCtx = null;
    protected BluetoothGatt mBluetoothGatt = null;
    protected int mConnectionState = BluetoothProfile.STATE_DISCONNECTED;

    protected int config_phy = -1;
    protected int config_mtu = -1;

    protected List<UUIDGroup> mUUIDServices = new ArrayList<>();


    public DeviceGatt() {
    }

    public DeviceGatt(Context ctx, BluetoothDevice device) {
        connect(ctx, device);
    }

    public void registerUUID(@NotNull String szServiceUUID, @NotNull String... szUUIDs) {
        UUIDGroup custService = UUIDGroup.SERVICE(szServiceUUID);
        custService.addCharUUIDs(szUUIDs);
        mUUIDServices.add(custService);
    }

    public void unregiserUUIDAll() {
        mUUIDServices.clear();
    }


    /*
       phy – preferred transmitter & receiver PHY. Bitwise OR of any of BluetoothDevice.PHY_LE_1M_MASK, BluetoothDevice.PHY_LE_2M_MASK, and BluetoothDevice.PHY_LE_CODED_MASK.
       mtu – 250 for voble
    */
    public void config(int phy, int mtu) {
        config_phy = phy;
        config_mtu = mtu;
    }

    @SuppressLint("MissingPermission")
    public boolean connect(Context ctx, BluetoothDevice device) {
        mCtx = ctx;
        mBluetoothGatt = device.connectGatt(ctx, false, this /*mGattCallback*/);
        Log.d(TAG, "Trying to create a new connection.");
        mConnectionState = BluetoothProfile.STATE_CONNECTING;
        return true;
    }

    public boolean connect() {
        if (mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothGatt not initialized");
            return false;
        }

        @SuppressLint("MissingPermission")
        boolean bRet = mBluetoothGatt.connect();
        if (bRet)
            mConnectionState = BluetoothProfile.STATE_CONNECTING;
        return bRet;
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read result is reported
     * asynchronously through the {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic The characteristic to read from.
     */
    @SuppressLint("MissingPermission")
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothGatt not initialized");
            return;
        }
        mBluetoothGatt.readCharacteristic(characteristic);
    }


    /**
     * Enables or disables notification on a give characteristic.
     *

     */

    /**
     * Enable Notification on characteristic
     *
     * @return
     */
    @SuppressLint("MissingPermission")
    public void enableNotification(UUID serviceUUID, UUID charUUID)
    {
    	/*
    	if (mBluetoothGatt == null) {
    		showMessage("mBluetoothGatt null" + mBluetoothGatt);
    		broadcastUpdate(DEVICE_DOES_NOT_SUPPORT_UART);
    		return;
    	}
    	*/
        BluetoothGattService curService = mBluetoothGatt.getService(serviceUUID);
        if (curService == null) {
            showMessage("Service not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_UART);
            return;
        }
        BluetoothGattCharacteristic curChar = curService.getCharacteristic(charUUID);
        if (curChar == null) {
            showMessage("Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_UART);
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(curChar,true);

        BluetoothGattDescriptor descriptor = curChar.getDescriptor(UUIDGroup.UUID_CCCD);
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);
    }

    public void writeRXCharacteristic(byte[] value)
    {
        BluetoothGattService RxService = mBluetoothGatt.getService(UUIDGroup.UUID_SERVICE_UART);
        //showMessage("mBluetoothGatt "+ mBluetoothGatt);
        if (RxService == null) {
            showMessage("Rx service not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_UART);
            return;
        }
        BluetoothGattCharacteristic RxChar = RxService.getCharacteristic(UUIDGroup.UUID_CHAR_RX);
        if (RxChar == null) {
            showMessage("Rx charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_UART);
            return;
        }
        RxChar.setValue(value);
        @SuppressLint("MissingPermission")
        boolean status = mBluetoothGatt.writeCharacteristic(RxChar);

        Log.d(TAG, "write RXchar - status=" + status);
    }

    private void showMessage(String msg) {
        Log.e(TAG, msg);
    }
    /**
     * Retrieves a list of supported GATT services on the connected device. This should be
     * invoked only after {@code BluetoothGatt#discoverServices()} completes successfully.
     *
     * @return A {@code List} of supported services.
     */
    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }


    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    @SuppressLint("MissingPermission")
    public void disconnect() {
        if (mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothGatt not initialized");
            return;
        }
        Log.w(TAG, "mBluetoothGatt disconnect");
        mBluetoothGatt.disconnect();
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    @SuppressLint("MissingPermission")
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        Log.w(TAG, "mBluetoothGatt closed");
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }


    //=========================================
    //private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {

        @Override
        public void onPhyUpdate(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyUpdate(gatt, txPhy, rxPhy, status);
            Log.w(TAG, "onPhyUpdate: txPhy=" + txPhy + ", rxPhy=" + rxPhy);
        }

        @Override
        public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
            super.onPhyRead(gatt, txPhy, rxPhy, status);
            Log.w(TAG, "onPhyRead: txPhy=" + txPhy + ", rxPhy=" + rxPhy);
        }

        @SuppressLint("MissingPermission")
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            mConnectionState = newState;

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(TAG, "Connected to GATT server.");

                if (config_phy > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    //phyOptions – preferred coding to use when transmitting on the LE Coded PHY. Can be one of BluetoothDevice.PHY_OPTION_NO_PREFERRED, BluetoothDevice.PHY_OPTION_S2 or BluetoothDevice.PHY_OPTION_S8
                    mBluetoothGatt.setPreferredPhy(config_phy, config_phy, BluetoothDevice.PHY_OPTION_NO_PREFERRED);
                }

                if (config_mtu > 0) {
                    gatt.requestMtu(config_mtu);
                } else {
                    // Attempts to discover services after successful connection.
                    gatt.discoverServices();
                    //Log.i(TAG, "Attempting to start service discovery:" + );
                }

                intentAction = ACTION_GATT_CONNECTED;
                BLEManager.broadcastUpdate(mCtx, intentAction);
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.i(TAG, "Disconnected from GATT server.");

                intentAction = ACTION_GATT_DISCONNECTED;
                BLEManager.broadcastUpdate(mCtx, intentAction);
            }
            //super.onConnectionStateChange(gatt, status, newState);
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.w(TAG, "onServicesDiscovered(): gatt=" + gatt);
                BLEManager.broadcastUpdate(mCtx, ACTION_GATT_SERVICES_DISCOVERED);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
            //super.onServicesDiscovered(gatt, status);
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLEManager.broadcastUpdate(mCtx, ACTION_DATA_AVAILABLE, characteristic);
            }
            //super.onCharacteristicRead(gatt, characteristic, status);
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            Log.w(TAG, "onCharacteristicWrite: status=" + status);
        }

        @Override
        public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorRead(gatt, descriptor, status);
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
            Log.w(TAG, "onDescriptorWrite: status=" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BLEManager.broadcastUpdate(mCtx, ACTION_DESCRIPTOR_WRITE, descriptor);
            }
        }

        @Override
        public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
            super.onReliableWriteCompleted(gatt, status);
        }

        @Override
        public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
            super.onReadRemoteRssi(gatt, rssi, status);
        }

        @SuppressLint("MissingPermission")
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);

            Log.d(TAG, "onMtuChanged: mtu=" + mtu + ", status=" + status);
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "onMtuChanged - gatt.discoverServices");
                gatt.discoverServices();
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            //Log.d(TAG, "onCharacteristicChanged: length=" + characteristic.getValue().length);
            //super.onCharacteristicChanged(gatt, characteristic);
        }
    //};
    //=========================================
}
