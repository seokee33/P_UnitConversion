package kr.claud.synesper.adapter;

import android.graphics.Color;
import android.graphics.ColorSpace;
import android.media.Image;
import android.os.Handler;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.libs.enums.WeekDay;
import kr.claud.synesper.ui.notice.NoticeCache;


public class HcalNoticeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final String TAG = "HcalNoticeAdapter";

    private final int VIEW_TYPE_ITEM = 0;
    private final int VIEW_TYPE_LOADING = 1;


    private ArrayList<HcalNoticeItem> mList;
    private boolean mLoading = false;
    private int mItemLimit = 10;


    public interface OnAdapterListener {
        void onItemClick(View v, HcalNoticeItem item, int pos);
        void onItemChanged(HcalNoticeAdapter adapter, int firstPos, int lastPos);
    }
    private OnAdapterListener mOnAdapterListener = null;
    public void setOnAdapterListener(OnAdapterListener l) {
        mOnAdapterListener = l;
    }

    public HcalNoticeAdapter(ArrayList<HcalNoticeItem> list) {
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_ITEM) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_notice_item, parent, false);
            HcalNoticeViewHolder viewHolder = new HcalNoticeViewHolder(view);
            return viewHolder;
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_notice_loading_item, parent, false);
            LoadingViewHolder viewHolder = new LoadingViewHolder(view);
            return viewHolder;
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HcalNoticeViewHolder) {
            populateHcalNotice((HcalNoticeViewHolder) holder, position);
        } else if (holder instanceof LoadingViewHolder) {
            showLoadingView((LoadingViewHolder) holder, position);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return mList.get(position) == null ? VIEW_TYPE_LOADING : VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }


    public HcalNoticeItem getItem(int index) {
        if (index >= 0 && index < mList.size()) {
            return mList.get(index);
        }
        return null;
    }

    //------------------------------------------------------------------------
    // scroll listener
    public RecyclerView.OnScrollListener mOnScrollListener = new RecyclerView.OnScrollListener() {
        private int scrollState = RecyclerView.SCROLL_STATE_IDLE;

        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            //Log.d("HcalNoticeAdapter", "onScrollStateChanged() - newState=" + newState);

            scrollState = newState;
        }

        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);

            if (mList.size() >= mItemLimit && dx == 0)
                return;

            LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            if (layoutManager != null) {
                if (!mLoading) {
                    int firstPos = layoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastPos = layoutManager.findLastCompletelyVisibleItemPosition();
                    //Log.d("HcalNoticeAdapter", "onScrolled(): dx=" + dx + ", dy=" + dy);
                    loadMoreItems(firstPos, lastPos);
                }
            }
        }
    };


    public boolean addHcalNotice(HcalNoticeAdapter.HcalNoticeItem item, boolean bNotify) {
        boolean bRet = mList.add(item);
        if (bNotify) {
            notifyDataSetChanged();
        }
        return bRet;
    }

    public boolean addHcalNotice(int index, HcalNoticeAdapter.HcalNoticeItem item, boolean bNotify) {
        mList.add(index, item);
        if (bNotify) {
            notifyDataSetChanged();
        }
        return true;
    }

    public boolean addHcalNotice(String curDate, int notice, boolean bNotify) {
        HcalNoticeAdapter.HcalNoticeItem deviceItem = new HcalNoticeAdapter.HcalNoticeItem(curDate, notice);
        return addHcalNotice(deviceItem, bNotify);
    }

    public boolean addHcalNotice(int index, String curDate, int notice, boolean bNotify) {
        HcalNoticeAdapter.HcalNoticeItem deviceItem = new HcalNoticeAdapter.HcalNoticeItem(curDate, notice);
        return addHcalNotice(index, deviceItem, bNotify);
    }

    public boolean addHcalNoticeToday(int notice, boolean bNotify) {
        String curDate = HcalNoticeAdapter.HcalNoticeItem.stringFromDate(new Date());
        return addHcalNotice(curDate, notice, bNotify);
    }

    public boolean addHcalNoticeToday(int index, int notice, boolean bNotify) {
        String curDate = HcalNoticeAdapter.HcalNoticeItem.stringFromDate(new Date());
        return addHcalNotice(index, curDate, notice, bNotify);
    }

    public void invalidateHcalNotice(Date date, int notice) {
        int pos = 0;
        for (HcalNoticeItem item : mList) {
            if (item.compareDate(date)) {
                item.notice = notice;
                notifyItemChanged(pos);
                break;
            }
            pos++;
        }
    }


    public void loadMoreItems(int firstPos, int lastPos) {
        boolean bHead = (firstPos == 0);
        boolean bTail = (lastPos == mList.size() - 1);
        if (!bHead && !bTail)
            return;

        mLoading = true;

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
/*
                if (bHead) {
                    mArrayListHcalNotice.add(0, null);
                    mHcalNoticeAdapter.notifyItemInserted(0);
                }
                if (bTail) {
                    mArrayListHcalNotice.add(null);
                    mHcalNoticeAdapter.notifyItemInserted(mArrayListHcalNotice.size() - 1);
                }


                if (bHead) {
                    mArrayListHcalNotice.remove(0);
                    mHcalNoticeAdapter.notifyItemRemoved(0);
                }
                if (bTail) {
                    mArrayListHcalNotice.remove(mArrayListHcalNotice.size() - 1);

                    int scrollPosition = mArrayListHcalNotice.size();
                    mHcalNoticeAdapter.notifyItemRemoved(scrollPosition);

                }
*/

                if (bHead) {
                    HcalNoticeAdapter.HcalNoticeItem item = mList.get(0).newItemPrev();
                    addHcalNotice(0, item, false);
                    notifyItemInserted(0);

                    if (mList.size() > mItemLimit) {
                        mList.remove(mList.size() - 1);
                        notifyItemRemoved(mList.size());
                    }
                }
                if (bTail) {
                    HcalNoticeAdapter.HcalNoticeItem item = mList.get(mList.size()-1).newItemNext();
                    addHcalNotice(item, false);
                    notifyItemInserted(mList.size() - 1);

                    if (mList.size() > mItemLimit) {
                        mList.remove(0);
                        notifyItemRemoved(0);
                    }
                }

                if (mOnAdapterListener != null) {
                    mOnAdapterListener.onItemChanged(HcalNoticeAdapter.this, firstPos, lastPos);
                }
                //mHcalNoticeAdapter.notifyDataSetChanged();
                mLoading = false;
            }
        }, 10);
    }
    //------------------------------------------------------------------------
    public static class HcalNoticeItem {

        public static String pattern = "yyyy-MM-dd";
        public static String stringFromDate(Date date) {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
            return sdf.format(date);
        }

        private Date date;
        private int notice;

        public HcalNoticeItem(String date, int notice) {  // yyyy-MM-dd
            DateFormat fmt = new SimpleDateFormat(pattern);
            try {
                this.date = fmt.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            this.notice = notice;
        }

        public Date getDate() {
            return this.date;
        }

        public boolean compareDate(Date date) {
            return DateUtil.compareDate(this.date, date);  // (this.date.compareTo(date) == 0);
        }

        public int getYear() {
            return DateUtil.yearFromDate(this.date);
        }

        public int getMonth() {
            return DateUtil.monthFromDate(this.date);
        }

        public int getDay() {
            return DateUtil.dayFromDate(this.date);
        }

        public int getWeekday() {
            return DateUtil.weekdayFromDate(this.date);
        }

        public int getNotice() {
            return notice;
        }

        public void setNotice(int notice) {
            this.notice = notice;
        }

        public HcalNoticeItem newItemPrev() {
            Calendar c = Calendar.getInstance();
            c.setTime(this.date);
            c.add(Calendar.DATE, -1);

            Date prevDate = c.getTime();
            AppData ad = AppData.I();
            NoticeCache.NoticeDay nd = ad.getNotice(prevDate);
            int notice = 0;
            if (nd != null) {
                notice = nd.getCount();
            }
            return new HcalNoticeItem(stringFromDate(prevDate), notice);
        }

        public HcalNoticeItem newItemNext() {
            Calendar c = Calendar.getInstance();
            c.setTime(this.date);
            c.add(Calendar.DATE, 1);

            Date nextDate = c.getTime();
            AppData ad = AppData.I();
            NoticeCache.NoticeDay nd = ad.getNotice(nextDate);
            int notice = 0;
            if (nd != null) {
                notice = nd.getCount();
            }
            return new HcalNoticeItem(stringFromDate(nextDate), notice);
        }
    }

    //----------------------------------------------------
    public class HcalNoticeViewHolder extends RecyclerView.ViewHolder {

        protected TextView weekday;
        protected TextView day;
        protected ImageView notice;

        public HcalNoticeViewHolder(@NonNull View itemView) {
            super(itemView);

            this.weekday = (TextView) itemView.findViewById(R.id.weekday);
            this.day = (TextView) itemView.findViewById(R.id.day);
            this.notice = (ImageView) itemView.findViewById(R.id.notice);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            mOnAdapterListener.onItemClick(v, mList.get(pos), pos);
                        }
                    }
                }
            });
        }
    }

    private void populateHcalNotice(HcalNoticeViewHolder holder, int position) {
        holder.weekday.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        holder.day.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);

        holder.weekday.setGravity(Gravity.CENTER);
        holder.day.setGravity(Gravity.CENTER);

        HcalNoticeItem item = mList.get(position);
        int weekday = item.getWeekday();
        int day = item.getDay();
        int noticeType = item.getNotice();

        WeekDay wd = WeekDay.fromIndex(weekday);
        holder.weekday.setText(wd.getShortName());
        holder.weekday.setTextColor(wd.getColor());
        holder.day.setText("" + day);

        Log.d(TAG, "day=" + day + ", notice=" + noticeType);

        if (noticeType <= 0) {
            holder.notice.setVisibility(View.GONE);
        } else {
            holder.notice.setColorFilter(wd.getColor());
            holder.notice.setVisibility(View.VISIBLE);
        }
    }

    //-----------------------------------------------
    private class LoadingViewHolder extends RecyclerView.ViewHolder {
        private ProgressBar progressBar;

        public LoadingViewHolder(@NonNull View itemView) {
            super(itemView);
            progressBar = itemView.findViewById(R.id.progressBar);
        }
    }

    private void showLoadingView(LoadingViewHolder holder, int position) {

    }
}
