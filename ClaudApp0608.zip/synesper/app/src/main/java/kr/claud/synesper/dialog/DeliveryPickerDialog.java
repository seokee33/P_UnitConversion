package kr.claud.synesper.dialog;

/*
    DeliveryPickerDialog dpdlg = new DeliveryPickerDialog(ctx, R.style.Theme_ClaudApp_PopupDialogTheme);
    dpdlg.setDialogListener(listener);
    dpdlg.show();
 */

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;

import kr.claud.synesper.R;

public class DeliveryPickerDialog extends Dialog implements View.OnClickListener {

    private DatePicker datePicker;
    private Button btnClear;
    private Button btnOk;
    private Button btnCancel;

    public interface DeliveryPickerDialogListener {
        void onClearClicked();
        void onPositiveClicked(int year, int month, int day);
        void onNegativeClicked();
    }
    private DeliveryPickerDialogListener mDeliveryPickerDialogListener;
    public void setDialogListener(DeliveryPickerDialogListener l) {
        this.mDeliveryPickerDialogListener = l;
    }


    public DeliveryPickerDialog(@NonNull Context context) {
        super(context);
    }

    public DeliveryPickerDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_delivery_picker);

        datePicker = (DatePicker) findViewById(R.id.dataPickerDelivery);
        btnClear = (Button) findViewById(R.id.buttonClear);
        btnOk = (Button) findViewById(R.id.buttonOK);
        btnCancel = (Button) findViewById(R.id.buttonCancel);

        btnClear.setOnClickListener(this);
        btnOk.setOnClickListener(this);
        btnCancel.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.buttonClear:
                if (mDeliveryPickerDialogListener != null) {
                    mDeliveryPickerDialogListener.onClearClicked();
                }
                dismiss();
                break;

            case R.id.buttonOK:
                if (mDeliveryPickerDialogListener != null) {
                    int year = datePicker.getYear();
                    int month = datePicker.getMonth() + 1;
                    int day = datePicker.getDayOfMonth();
                    mDeliveryPickerDialogListener.onPositiveClicked(year, month, day);
                }
                dismiss();
                break;

            case R.id.buttonCancel:
                if (mDeliveryPickerDialogListener != null) {
                    mDeliveryPickerDialogListener.onNegativeClicked();
                }
                dismiss();
                break;
        }
    }
}
