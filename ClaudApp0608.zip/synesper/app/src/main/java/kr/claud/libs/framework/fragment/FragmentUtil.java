package kr.claud.libs.framework.fragment;

import androidx.fragment.app.Fragment;

import java.util.List;

public class FragmentUtil {

    public static Fragment getChildFragment(Fragment hostFragment, Class cls) {
        if (hostFragment != null && hostFragment.getChildFragmentManager() != null) {
            List<Fragment> fragmentList = hostFragment.getChildFragmentManager().getFragments();
            for (Fragment fragment : fragmentList) {
                if (cls.isInstance(fragment)) {
                    return fragment;
                }
            }
        }
        return null;
    }
}