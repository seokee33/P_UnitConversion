package kr.claud.synesper.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.io.File;

import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.synesper.data.SynesperSupport;
import kr.claud.synesper.media.PCMPlayer;
import kr.claud.synesper.media.SmdFileReader;

public class SmdPlayerDialog  extends Dialog implements View.OnClickListener {

    private ImageView btnOk;
    private ImageView btnCancel;

    private boolean bStatePlay = true;

    private String numString = "";
    private String dateString = null;
    private String fileName = null;
    private File fileDir = null;

    private SmdFileReader smdFileReader = null;
    private PCMPlayer pcmPlayer = null;


    public interface SmdPlayerDialogListener {
        int onNumber();
        String onDate();
        String onFileName();
        File onFileDir();

        int onPlayPauseClicked(SmdPlayerDialog dlg, boolean bState);
        void onCloseClicked();
    }
    private SmdPlayerDialogListener mSmdPlayerDialogListener;
    public void setDialogListener(SmdPlayerDialogListener l) {
        this.mSmdPlayerDialogListener = l;
    }


    public SmdPlayerDialog(@NonNull Context context, SmdPlayerDialogListener l) {
        super(context);
        setDialogListener(l);
        initPlayer();
    }

    public SmdPlayerDialog(@NonNull Context context, int themeResId, SmdPlayerDialogListener l) {
        super(context, themeResId);
        setDialogListener(l);
        initPlayer();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_smd_player);

        TextView tvNumber = (TextView) findViewById(R.id.textViewNumber);
        tvNumber.setText(numString);

        if (dateString != null) {
            TextView tvDate = (TextView) findViewById(R.id.textViewDate);
            tvDate.setText(dateString);
        }

        if (fileName != null) {
            TextView tvFile = (TextView) findViewById(R.id.textViewFile);
            tvFile.setText(fileName);
        }

        btnOk = (ImageView) findViewById(R.id.imageViewPlayPause);
        btnCancel = (ImageView) findViewById(R.id.imageViewClose);
        btnOk.setOnClickListener(this);
        btnCancel.setOnClickListener(this);

        if (smdFileReader == null || pcmPlayer == null) {
            btnOk.setEnabled(false);
            btnOk.setColorFilter(Color.LTGRAY);
        }
    }

    @Override
    public void dismiss() {
        super.dismiss();
        closePlayer();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.imageViewPlayPause:
                if (mSmdPlayerDialogListener != null) {
                    int ret = mSmdPlayerDialogListener.onPlayPauseClicked(this, bStatePlay);
                    if (ret < 0) {
                        dismiss();
                    }
                }
                break;

            case R.id.imageViewClose:
                if (mSmdPlayerDialogListener != null) {
                    mSmdPlayerDialogListener.onCloseClicked();
                }
                dismiss();
                break;
        }
    }

    private void initPlayer() {
        if (mSmdPlayerDialogListener != null) {
            int pos = mSmdPlayerDialogListener.onNumber();
            numString = String.format("No.%d", pos+1);

            dateString = mSmdPlayerDialogListener.onDate();
            fileName = mSmdPlayerDialogListener.onFileName();
            fileDir = mSmdPlayerDialogListener.onFileDir();
        }

        //smdFileReader = new SmdFileReader();
        //smdFileReader.open(fileName, fileDir);

        pcmPlayer = new PCMPlayer();
    }

    private void closePlayer() {
        if (pcmPlayer != null) {
            pcmPlayer.stop();
            pcmPlayer = null;
        }
        if (smdFileReader != null) {
            smdFileReader.close();
            smdFileReader = null;
        }
    }

    private void startPlayer() {
        pcmPlayer.play(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, SynesperSupport.AUDIOTRACK_BUFFER_SIZE);
    }

    private void stopPlayer() {
        if (pcmPlayer.isPlaying()) {
            pcmPlayer.stop();
        }
    }

    private void pcmPlaying(short[] pcmStream) {
        if (pcmPlayer.isPlaying()) {
            pcmPlayer.addPacket(pcmStream);
        }
    }
}
