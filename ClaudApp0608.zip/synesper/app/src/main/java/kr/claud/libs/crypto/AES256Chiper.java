package kr.claud.libs.crypto;

import android.util.Base64;

import androidx.annotation.NonNull;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import kr.claud.libs.datatype.StringUtil;
import kr.claud.libs.enums.KeySize;


/*
    AES는 16, 24 또는 32 바이트 크기의 암호키만 지원
 */
public class AES256Chiper {

    private byte[] ivBytes = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
    private String mSecretKey;

    public AES256Chiper(String key, KeySize keySize, byte[] scrambles) {
        this.mSecretKey = retouchKey(key, keySize, scrambles);
    }

    public static String retouchKey(@NonNull String str, @NonNull KeySize keySize, byte[] scrambles) {
        int len = keySize.value();
        String strModified = (str.length() >= len) ? str.substring(0, len) : String.format("%1$" + len + "s", str);
        if (scrambles == null || scrambles.length == 0)
            return strModified;

        String strScrambled = StringUtil.nrShift(strModified, (int) scrambles[0]);
        if (scrambles.length > 2) {
            int i;
            for (i = 0; i<scrambles.length-1 ; i+=2) {
                int n1 = (int) scrambles[i];
                int n2 = (int) scrambles[i+1];
                strScrambled = StringUtil.exchange(strScrambled, n1, n2);
            }
        }
        return strScrambled;
    }

    //AES256 암호화
    public String AES_Encode(String str) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        byte[] textBytes = str.getBytes(StandardCharsets.UTF_8);
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        SecretKeySpec newKey = new SecretKeySpec(mSecretKey.getBytes("UTF-8"), "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, newKey, ivSpec);
        return Base64.encodeToString(cipher.doFinal(textBytes), 0);
    }

    //AES256 복호화
    public String AES_Decode(String str) throws UnsupportedEncodingException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidAlgorithmParameterException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] textBytes = Base64.decode(str, 0);
        AlgorithmParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        SecretKeySpec newKey = new SecretKeySpec(mSecretKey.getBytes("UTF-8"), "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, newKey, ivSpec);
        return new String(cipher.doFinal(textBytes), "UTF-8");
    }
}
