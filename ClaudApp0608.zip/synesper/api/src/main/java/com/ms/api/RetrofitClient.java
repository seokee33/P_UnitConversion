package com.ms.api;

import com.ms.api.changeuser.ChangeAccountService;
import com.ms.api.file.FileUploadService;
import com.ms.api.login.LoginService;
import com.ms.api.personalinfoconsent.GetPersonalInfoConsentService;
import retrofit2.Retrofit;

public class RetrofitClient {
    private static Retrofit retrofitFileUpload;

    public static Retrofit retrofitLogin;

    public static Retrofit retrofitJoin;

    public static Retrofit retrofitAccount;

    public static Retrofit retrofitPersonalInfoConsent;

    public static GetPersonalInfoConsentService getPersonalInfoConsentService(){
        if(retrofitPersonalInfoConsent == null){
            Retrofit.Builder retrofitBuilder = RetrofitBuilderProvider.getRetrofitPersonalBuilder();
            retrofitPersonalInfoConsent = retrofitBuilder.build();
        }
        return retrofitPersonalInfoConsent.create(GetPersonalInfoConsentService.class);
    }

    public static FileUploadService getFileUploadService() {
        if (retrofitFileUpload == null) {
            // Retrofit.Builder 인스턴스 생성
            Retrofit.Builder retrofitBuilder = RetrofitBuilderProvider.getFileUploadBuilder();

            // Retrofit 인스턴스 생성
            retrofitFileUpload = retrofitBuilder.build();
        }
        return retrofitFileUpload.create(FileUploadService.class);
    }

    public static LoginService getJoinService(){
        if(retrofitJoin == null){
            Retrofit.Builder retrofitBuilder = RetrofitBuilderProvider.getRetrofitJoinBuilder();

            retrofitJoin = retrofitBuilder.build();
        }
        return retrofitJoin.create(LoginService.class);
    }

    public static LoginService getLoginService(){
        if (retrofitLogin == null) {
            // Retrofit.Builder 인스턴스 생성
            Retrofit.Builder retrofitBuilder = RetrofitBuilderProvider.getRetrofitLoginBuilder();

            // Retrofit 인스턴스 생성
            retrofitLogin = retrofitBuilder.build();
        }
        return retrofitLogin.create(LoginService.class);
    }

    public static ChangeAccountService getChangeAccountService(){
        if(retrofitAccount == null){
            Retrofit.Builder retrofitBuilder = RetrofitBuilderProvider.getAccountBuilder();
            retrofitAccount = retrofitBuilder.build();
        }
        return retrofitAccount.create(ChangeAccountService.class);
    }

}
