package ky.labsource.widget;

/*
    Example 1:
        ArrayList<ProgressCircle.Divider> dividerList = new ArrayList<ProgressCircle.Divider>();
        dividerList.add(new ProgressCircle.Divider(0.25f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.50f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.75f, 1.00f, Color.GREEN, "GOOD", Color.rgb(255, 167, 38)));
        dividerList.add(new ProgressCircle.Divider(1.00f, 1.00f, Color.GREEN, "GOOD", Color.rgb(81, 196, 203)));

        mProgressCircleResult = binding.progressCircleResult;
        mProgressCircleResult.setDividerList(dividerList);
        mProgressCircleResult.setTextGravity(Gravity.CENTER_VERTICAL);
        mProgressCircleResult.setEnable(false);
        mProgressCircleResult.setEnableText(false);
        //mProgressCircleResult.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_heart_border_24));
        mProgressCircleResult.setProgress(0.0f, 0.9f);
        mProgressCircleResult.sweepProgress();

    Example 2:
        mProgressCircleBaby = binding.progressCircleBaby;
        mProgressCircleBaby.setTextGravity(Gravity.BOTTOM);
        mProgressCircleBaby.setEnable(false);
        mProgressCircleBaby.setProgress(0.5f, 0.1f);
        mProgressCircleBaby.sweepProgress();
*/

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import androidx.core.view.GravityCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ky.labsource.R;


public class ProgressGaugeCircle extends View {

    private final RectF mOval = new RectF();
    private int mAngleBase = 90;  // degree
    private int angleGap = 4;  // degree
    private Bitmap icon;

    // 0.0f ~ 1.0f
    private float mSweepAngle = 0.0f;
    private float mStartAngle = 0.0f;
    private float mEndAngle = 1.0f;

    private Paint activePaint = new Paint();
    private Paint inactivePaint = new Paint();
    private TextPaint textPaint = new TextPaint();

    private Paint gaugePaint = new Paint();
    private Paint linePaint = new Paint();
    private TextPaint labelPaint = new TextPaint();

    private int gravityText = Gravity.BOTTOM;
    private float strokeWidth = 30.0f;
    private CharSequence charSeqText = null;
    private CharSequence charSeqUnit = null;
    private int textColor;
    private float textSize;


    private int activeColor;
    private int inactiveColor;
    private int gaugeColor;

    private float progressValueMin;
    private float progressValueMax;

    private float progressValueLow;
    private float progressValueHigh;
    private float progressValue;

    private boolean mEnabled = true;
    private boolean mTextEnabled = true;


    @SuppressLint("ResourceAsColor")
    public ProgressGaugeCircle(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.ProgressGaugeCircle, 0, 0);

        try {
            charSeqText = a.getText(R.styleable.ProgressGaugeCircle_android_text);
            textColor = a.getColor(R.styleable.ProgressGaugeCircle_android_textColor, android.R.color.holo_red_dark);
            textSize = a.getDimension(R.styleable.ProgressGaugeCircle_android_textSize, 100);
            charSeqUnit = a.getText(R.styleable.ProgressGaugeCircle_pgcUnitText);

            strokeWidth = a.getDimension(R.styleable.ProgressGaugeCircle_pgcStrokeWidth, 30.0f);

            activeColor = a.getColor(R.styleable.ProgressGaugeCircle_pgcActiveColor, Color.rgb(81, 196, 203));
            inactiveColor = a.getColor(R.styleable.ProgressGaugeCircle_pgcInactiveColor, android.R.color.darker_gray);
            gaugeColor = a.getColor(R.styleable.ProgressGaugeCircle_pgcGaugeColor, android.R.color.black);
        } finally {
            a.recycle();
        }

        activePaint.setColor(activeColor);
        activePaint.setStrokeWidth(strokeWidth);
        activePaint.setStyle(Paint.Style.STROKE);
        activePaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        textPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(textColor);
        textPaint.setTextSize(textSize);
        Typeface tf = Typeface.create("Roboto Condensed Light", Typeface.BOLD);
        textPaint.setTypeface(tf);

        inactivePaint.setColor(inactiveColor);
        inactivePaint.setStrokeWidth(strokeWidth);
        inactivePaint.setStyle(Paint.Style.STROKE);
        inactivePaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        gaugePaint.setColor(gaugeColor);
        gaugePaint.setStrokeWidth(5.0f);
        gaugePaint.setStyle(Paint.Style.STROKE);
        gaugePaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        linePaint.setColor(Color.BLACK);
        linePaint.setStrokeWidth(2.0f);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        labelPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        labelPaint.setColor(textColor);
        labelPaint.setTextSize(textSize*0.8f);
        Typeface tfLabel = Typeface.create("Roboto Condensed Light", Typeface.NORMAL);
        labelPaint.setTypeface(tfLabel);

        progressValueMin = 0.f;
        progressValueMax = 100.f;

        progressValueLow = 0.f;
        progressValueHigh = 0.f;
        progressValue = 0.f;
        //icon = BitmapFactory.decodeResource(getResources(), R.drawable.);

    }

    private void drawGraph(Canvas canvas, float startAngle, float sweepAngle) {
        if (sweepAngle < 0.f)
            sweepAngle = 0.f;
        else if (sweepAngle > 1.f)
            sweepAngle = 1.f;

        float currentAngleGap = (sweepAngle == 1.0f || sweepAngle == 0.f) ? 0.f : angleGap;

        float angleStart = -mAngleBase + (startAngle * 360) + currentAngleGap;
        float angleSweep = (sweepAngle * 360) - (currentAngleGap * 2.0f);

        float radius = (getHeight() - textSize*2.0f) / 2;
        float lp = getWidth() / 2 - (radius - strokeWidth / 2);
        float rp = getWidth() / 2 + (radius - strokeWidth / 2);
        float tp = getHeight() / 2 - (radius - strokeWidth / 2);
        float bp = getHeight() / 2 + (radius - strokeWidth / 2);
        mOval.set(lp, tp, rp, bp);
        canvas.drawArc(mOval, angleStart, angleSweep, false, activePaint);

        angleStart = -mAngleBase + (startAngle * 360) + (sweepAngle * 360);
        angleSweep = 360 - (sweepAngle * 360);
        mOval.set(lp, tp, rp, bp);
        canvas.drawArc(mOval, angleStart, angleSweep, false, inactivePaint);
    }

    private void drawLabel(Canvas canvas, float startAngle, float sweepAngle) {
        if (sweepAngle < 0.f)
            sweepAngle = 0.f;
        else if (sweepAngle > 1.f)
            sweepAngle = 1.f;

        float currentAngleGap = (sweepAngle == 1.0f || sweepAngle == 0.f) ? 0.f : angleGap;

        double radStart = Math.toRadians(startAngle * 360.0 + currentAngleGap);
        double radEnd = Math.toRadians((startAngle + sweepAngle) * 360.0 - currentAngleGap);

        double radius = (getHeight() - textSize*2.0) / 2.0;

        double xo = getWidth() / 2;
        double yo = getHeight() / 2;
        double x1 = xo + radius*Math.sin(radStart);
        double y1 = yo - radius*Math.cos(radStart);
        double x2 = xo + radius*Math.sin(radEnd);
        double y2 = yo - radius*Math.cos(radEnd);

        double x1_ = x1;
        double y1_ = y1;
        double x2_ = x2;
        double y2_ = y2;

        if (x1 > xo && x2 > xo) {
            x1_ = x1 + textSize;
            x2_ = x2 + textSize;
            if (y1 + textSize > y2) {
                if (y1 <= yo) {
                    y1_ = y2 - textSize;
                } else {
                    y2_ = y1 + textSize;
                }
            }
        } else if (x1 < xo && x2 < xo) {
            x1_ = x1 - textSize;
            x2_ = x2 - textSize;
            if (y2 + textSize > y1) {
                if (y2 <= yo) {
                    y2_ = y1 - textSize;
                } else {
                    y1_ = y2 + textSize;
                }
            }
        } else {
            x1_ = x1 + textSize;
            x2_ = x2 - textSize;
        }

        canvas.drawLine((float)x1, (float)y1, (float)x1_, (float)y1_, linePaint);
        canvas.drawLine((float)x2, (float)y2, (float)x2_, (float)y2_, linePaint);

        if (x1_ >= xo) {
            labelPaint.setTextAlign(Paint.Align.LEFT);
        } else {
            labelPaint.setTextAlign(Paint.Align.RIGHT);
        }
        canvas.drawText("" + (int)progressValueLow, (float)x1_ + 10.f, (float)y1_ + textSize*0.8f/2.0f, labelPaint);

        if (x2_ >= xo) {
            labelPaint.setTextAlign(Paint.Align.LEFT);
        } else {
            labelPaint.setTextAlign(Paint.Align.RIGHT);
        }
        canvas.drawText("" + (int)progressValueHigh, (float)x2_ + 10.f, (float)y2_ + textSize*0.8f/2.0f, labelPaint);
    }

    private void drawGauge(Canvas canvas, float curValue) {
        float val = (curValue - progressValueMin) / (progressValueMax - progressValueMin);
        float radVal = (float) Math.toRadians(val * 360.0);
        float r_in = (getHeight() - textSize*2.0f) / 2.0f - strokeWidth - textSize/4.0f;
        float r_out = (getHeight() - textSize*2.0f) / 2.0f - strokeWidth/3.0f;

        float xo = getWidth() / 2;
        float yo = getHeight() / 2;
        float x_in = xo + (float)(r_in*Math.sin(radVal));
        float y_in = yo - (float)(r_in*Math.cos(radVal));
        float x_out = xo + (float)(r_out*Math.sin(radVal));
        float y_out = yo - (float)(r_out*Math.cos(radVal));

        canvas.drawLine(x_in, y_in, x_out, y_out, gaugePaint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float sweepAngle = mSweepAngle;
        //setProgressColor(div.getSweepColor());
        //setTextColor(div.getTextColor());

        String text1 = null;
        int text1Color = 0;
        String text2 = null;
        int text2Color = 0;
        if (charSeqText != null && charSeqText.length() > 0) {
            if (charSeqUnit != null) {
                text1 = charSeqText.toString();
                text1Color = textColor;
                text2 = charSeqUnit.toString();
                text2Color = Color.rgb(192, 195, 197);
            } else {
                text1 = charSeqText.toString();
                text1Color = textColor;
            }
        }

        if (mEnabled) {
            drawGraph(canvas, mStartAngle, sweepAngle); //mSweepAngle
            drawLabel(canvas, mStartAngle, sweepAngle);
            drawGauge(canvas, progressValue);
        } else {
            drawGraph(canvas, mStartAngle, 0.0f);

            text1 = "  -  ";
            text1Color = inactiveColor;
            text2Color = inactiveColor;
        }

        if (mTextEnabled) {
            if (text1 != null) {
                if (text2 != null) {
                    drawTextWithUnit(canvas, textPaint, text1, text1Color, text2, text2Color);
                } else {
                    setTextColor(text1Color);
                    drawText(canvas, textPaint, text1);
                }
            }
        }

        if(icon != null)
            canvas.drawBitmap(icon, canvas.getWidth() / 2 - icon.getWidth() / 2, strokeWidth + (canvas.getHeight() / 15), null);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    private void drawText(Canvas canvas, Paint paint, String text) {
        //Rect bounds = new Rect();
        //paint.getTextBounds(text, 0, text.length(), bounds);
        //float x = (canvas.getWidth() / 2) - (bounds.width() / 2);
        //float y = (canvas.getHeight() / 2) + (bounds.height() / 2);
        //canvas.drawText(text, x, y, paint);

        paint.setTextAlign(Paint.Align.CENTER);

        float y = canvas.getHeight()/2;
        if (gravityText == Gravity.BOTTOM) {
            y = canvas.getHeight() - textSize - strokeWidth - textSize;
        } else if (gravityText == Gravity.CENTER_VERTICAL) {
            y += textSize / 2.0f;
        }
        canvas.drawText(text, canvas.getWidth()/2, y, paint);
    }

    private void drawTextWithUnit(Canvas canvas, Paint paint, String text, int color, String unit, int unitColor) {
        setTextColor(unitColor);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(unit, canvas.getWidth()/2, canvas.getHeight()/2 + textSize*1.2f, paint);

        setTextColor(color);
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(text, canvas.getWidth()/2, canvas.getHeight()/2 + textSize*1.2f, paint);
    }

    public void setEnable(boolean bEnable) {
        mEnabled = bEnable;
    }

    public void setText(CharSequence str) {
        charSeqText = str;
    }

    public void setEnableText(boolean bEnable) {
        mTextEnabled = bEnable;
    }

    public void setTextColor(int color) {
        textPaint.setColor(color);
    }

    public void setActiveColor(int color) {
        activePaint.setColor(color);
    }

    public void setInactvieColor(int color) {
        inactivePaint.setColor(color);
    }

    public void setTextGravity(int gravity) {
        gravityText = gravity;
        this.invalidate();
    }

    //---------------------------------------------------
    private void _setRangeRate(float low, float high) {
        mAngleBase = 90;
        mStartAngle = low;
        mEndAngle = high;
        this.invalidate();
    }


    public void setMinMax(float min, float max) {
        this.progressValueMin = min;
        this.progressValueMax = max;

        this.progressValueLow = 0.f;
        this.progressValueHigh = 0.f;
    }

    public void setRange(float low, float high) {
        progressValueLow = (low < progressValueMin) ? progressValueMin : low;
        progressValueHigh = (high > progressValueMax) ? progressValueMax : high;

        // 0.f ~ 1.f
        float start = (progressValueLow - progressValueMin) / (progressValueMax - progressValueMin);
        float progress = (progressValueHigh - progressValueLow) / (progressValueMax - progressValueMin);

        _setRangeRate(start, start + progress);
    }

    public void setProgress(float low, float value) {
        setRange(low, low + value);
    }

    private void setRangeRate(float low, float high) {
        if (low > 1.0f || low < 0.f || high > 1.0f || high < 0.f || low > high) {
            throw new RuntimeException("Value must be between 0 and 1: " + low + "-" + high);
        }

        progressValueLow = low * (progressValueMax - progressValueMin) + progressValueMin;
        progressValueHigh = high * (progressValueMax - progressValueMin) + progressValueMin;

        _setRangeRate(low, high);
    }

    public void setProgressRate(float start, float progress) {
        setRangeRate(start, start + progress);
    }

    public void setValue(float value, boolean bRedraw) {
        if (value < this.progressValueMin)
            value = this.progressValueMin;
        if (value > this.progressValueMax)
            value = this.progressValueMax;

        this.progressValue = value;

        if (bRedraw) {
            this.invalidate();
        }
    }

    public void sweepProgress() {
        mSweepAngle = mEndAngle - mStartAngle;
        this.invalidate();
    }

    public void startAnimation() {
        ValueAnimator anim = ValueAnimator.ofFloat(mStartAngle, mEndAngle);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                ProgressGaugeCircle.this.mSweepAngle = (Float) valueAnimator.getAnimatedValue();
                ProgressGaugeCircle.this.invalidate();
            }
        });
        anim.setDuration(500);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }
}
