package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.ColorInt;

import ky.labsource.R;
import ky.labsource.common.ViewLayer;
import ky.labsource.common.ViewLayerIface;
import ky.labsource.common.ViewLayerManager;


public class GraphView extends SurfaceView implements SurfaceHolder.Callback {
    private static final String TAG = "GraphView";

    private Context mContext;
    private GraphDrawThread mGraphDrawThread = null;

    // layer
    private ViewLayerManager mViewLayerMgr = new ViewLayerManager();

	private gvAxis mAxisLayer = new gvAxis();
	private gvGuideline mGuidelineLayer = new gvGuideline();
    private gvGraph mGraphLayer = new gvGraph();

	// plot area size
	private int mWidth = 478;
	private int mHeight = 240;

	private float mMaxValue = (float) Short.MAX_VALUE;
	private float mMinValue = (float) Short.MIN_VALUE;

	private boolean mEnabled = true;



	//--- Constructor ---------------------------------
	public GraphView(Context context) {
		super(context);

		mContext = context;

		initGraphView();
	}

	public GraphView(Context context, AttributeSet attrs)
	{
		super(context, attrs);

		mContext = context;

		initAttrs(attrs, 0);
		initGraphView();
	}

	public GraphView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		mContext = context;

		initAttrs(attrs, defStyle);
		initGraphView();
	}

    private void initAttrs(AttributeSet attrs, int defStyle) {
        TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.GraphView, 0, 0);
        try {
            int chartMode = ta.getInt(R.styleable.GraphView_graphViewChartMode, 0);
        } finally {
            ta.recycle();
        }
    }

    private void initGraphView() {
		initGdiObject();

		setZOrderOnTop(true);
		getHolder().setFormat(PixelFormat.TRANSPARENT);
		getHolder().addCallback(this);
    }

    @Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
	{
		mWidth = width;
		mHeight = height;
		Log.v(TAG, "surfaceChanged() [" + mszTitle + "]: W=" + mWidth + ", H=" + mHeight);

		recalcLayout();

        mViewLayerMgr.createObjects();
        //createResources(mWidth, mHeight);
	}

	@Override
	public void surfaceCreated(SurfaceHolder holder)
	{
		Log.v(TAG, "surfaceCreated() [" + mszTitle + "]");

        if (mGraphDrawThread == null) {
            mGraphDrawThread = new GraphDrawThread(getHolder(), this);
            mGraphDrawThread.start();
        }
	}

	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{
		Log.v(TAG, "surfaceDestroyed()");

        if (mGraphDrawThread != null) {
            boolean retry = true;
            mGraphDrawThread.stopGraphDraw();
            //mGraphDrawThread.interrupt();

            while (retry){
                try{
                    mGraphDrawThread.join();
                    retry = false;
                }catch(InterruptedException e){

                }
            }
            mGraphDrawThread = null;
        }
        mViewLayerMgr.destroyObjects();
		//destroyResources();
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);

		//int width = (int)getDip(10);
		//int height = (int)getDip(10);
		int width = mWidth;
		int height = mHeight;

		switch (widthMode) {
			case MeasureSpec.UNSPECIFIED: // unspecified
				width = widthMeasureSpec;
				break;
			case MeasureSpec.AT_MOST:  // wrap_content
				break;
			case MeasureSpec.EXACTLY:  // match_parent
				width = MeasureSpec.getSize(widthMeasureSpec);
				break;
		}

		switch (heightMode) {
			case MeasureSpec.UNSPECIFIED: // unspecified
				height = heightMeasureSpec;
				break;
			case MeasureSpec.AT_MOST:  // wrap_content
				break;
			case MeasureSpec.EXACTLY:  // match_parent
				height = MeasureSpec.getSize(heightMeasureSpec);
				break;
		}

		setMeasuredDimension(width, height);

		mWidth = width;
		mHeight = height;
	}

	@Override
	public void onDraw(Canvas canvas) {
		super.onDraw(canvas);

/*
		Paint paint = new Paint();
		paint.setColor(Color.RED);
		paint.setTextSize(24);
		canvas.drawText("Hello", 200, 200, paint);
*/
	}


    public void doDraw(Canvas canvas) {
        mViewLayerMgr.drawTo(canvas);
    }

    private void recalcLayout() {
		float paddingLeft = getPaddingLeft();
		float paddingTop = getPaddingTop();
		float paddingRight = getPaddingRight();
		float paddingBottom = getPaddingBottom();

		float contentWidth = getWidth() - paddingLeft - paddingRight;
		float contentHeight = getHeight() - paddingTop - paddingBottom;

		RectF rcBase = new RectF(paddingLeft, paddingTop, paddingLeft + contentWidth, paddingTop + contentHeight);
        mViewLayerMgr.create(rcBase);

		RectF rcLayer = new RectF(0, 0, contentWidth, contentHeight);
        mAxisLayer.create(rcLayer, false);
        mAxisLayer.setOnLayerDrawListener(mAxisLayer.mAxisLayerDrawListener);
        mGuidelineLayer.create(rcLayer, false);
        mGuidelineLayer.setOnLayerDrawListener(mGuidelineLayer.mGuidelineLayerDrawListener);

        RectF rcGraph = new RectF(rcLayer);
        mGraphLayer.create(rcGraph, true);
        mGraphLayer.setOnLayerDrawListener(mGraphLayer.mGraphLayerDrawListener);

        mViewLayerMgr.addLayer(mAxisLayer);
		mViewLayerMgr.addLayer(mGraphLayer);
        mViewLayerMgr.addLayer(mGuidelineLayer);
	}

	public void enableGuideline(boolean bEnable) {
		mGuidelineLayer.setEnabled(bEnable);
	}

	public void enableAxis(boolean bEnable) {
		mAxisLayer.setEnabled(bEnable);
	}


    //-------------------------------------------------------
    class gvAxis extends ViewLayer {

        ViewLayerIface.OnLayerDrawListener mAxisLayerDrawListener = new ViewLayerIface.OnLayerDrawListener() {
            @Override
            public boolean onDraw(ViewLayer layer, Canvas canvas) {
                drawAxis(canvas);
                return false;
            }
        };


        public void drawAxis(Canvas canvas) {
			Rect rc = new Rect(0, 0, (int)WidthF(), (int)HeightF());
            DrawGrid(canvas, rc);
        }

        @Override
        public boolean createObjects() {

            return false;
        }

        @Override
        public void destroyObjects() {

        }
    }

    //-------------------------------------------------------
	class gvGuideline extends ViewLayer {

        ViewLayerIface.OnLayerDrawListener mGuidelineLayerDrawListener = new ViewLayerIface.OnLayerDrawListener() {
            @Override
            public boolean onDraw(ViewLayer layer, Canvas canvas) {
                drawGuideline(canvas);
                return false;
            }
        };

        public void drawGuideline(Canvas canvas) {
        	Rect rc = new Rect(0, 0, (int)WidthF(), (int)HeightF());
			DrawBorder(canvas, rc);
        }

        @Override
        public boolean createObjects() {
            return false;
        }

        @Override
        public void destroyObjects() {

        }
    }




    //-------------------------------------------------------
    class gvGraph extends ViewLayer {

		public float px = 0.f;
		public float py = 0.f;


        ViewLayerIface.OnLayerDrawListener mGraphLayerDrawListener = new ViewLayerIface.OnLayerDrawListener() {
            @Override
            public boolean onDraw(ViewLayer layer, Canvas canvas) {
                drawGraph(canvas, null);
                return false;
            }
        };

		public void clear() {
			this.px = 0.f;
			this.py = 0.f;

			clearBitmap();
		}

        public void drawGraph(Canvas canvas, short[] pdata) {
        	if (pdata == null)
        		return;
        	if (pdata.length == 0)
        		return;

			Rect rc = new Rect(0, 0, (int)WidthF(), (int)HeightF());

			float tx = px + mDrawStep*pdata.length;
			float lastX = rc.width() - 1.0f;
			int scrollX = 0;
			if (tx > lastX) {
				scrollX = (int) (tx) - (int) (lastX) + 1;
				translateBitmap(-scrollX, 0);
				px -= scrollX;
			}

			final Path drwPath = new Path();
			if (px <= 0.f)
				py = CalcYDrawPoint(pdata[0], rc);

			drwPath.moveTo(px, py);

			for (short s : pdata) {
				px += mDrawStep;
				py = CalcYDrawPoint(s, rc);
				drwPath.lineTo(px, py);
			}
			canvas.drawPath(drwPath, mForePaint);
		}

        @Override
        public boolean createObjects() {
            return false;
        }

        @Override
        public void destroyObjects() {

        }
    }


    //========================================================
    private float mDrawStep = 1.0f;
	private int mScrollPos = 0;

	private float mScaleV = 2.0f;

	private Paint grid_paint = new Paint();
	private Paint cross_paint = new Paint();
	private Paint outline_paint = new Paint();

    private Paint mForePaint = new Paint();
    private Paint mEventPaint = new Paint();
    private Paint mClearPaint = new Paint();

    private Paint mOvlTextPaint = new Paint();


    // overlay
    public String mszTitle = "Speech";

    public float mOvlFontSize = 12;




	private void initGdiObject()
	{
		mForePaint.setStyle(Paint.Style.STROKE);
		mForePaint.setStrokeCap(Paint.Cap.ROUND);
        mForePaint.setStrokeWidth(3.f);
        mForePaint.setAntiAlias(true);
        //mForePaint.setColor(Color.rgb(128, 255, 128));
		mForePaint.setColor(Color.rgb(255, 0, 0));

        mEventPaint.setColor(Color.argb(0, 0, 0, 0));
        mEventPaint.setAntiAlias(true);
        
        mClearPaint.setColor(Color.argb(0, 0, 0, 0));
        mClearPaint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
        mClearPaint.setAntiAlias(true);

        // overlay
		mOvlTextPaint.setAntiAlias(true);
		mOvlTextPaint.setColor(Color.WHITE);
		mOvlTextPaint.setTextSize(DisplayUtils.PixelFromDP(mContext, mOvlFontSize));
        //mOvlTextPaint.setStrokeWidth(2.0f);
        //mOvlTextPaint.setStyle(Paint.Style.STROKE);
        //mOvlTextPaint.setShadowLayer(7.0f, 0.0f, 0.0f, Color.WHITE);


		grid_paint.setColor(Color.rgb(255, 197, 222));
		grid_paint.setAntiAlias(true);
		grid_paint.setStrokeWidth(3.f);

		cross_paint.setColor(Color.rgb(70, 100, 70));
		cross_paint.setAntiAlias(true);
		cross_paint.setStrokeWidth(3.f);

		outline_paint.setStyle(Paint.Style.STROKE);
		outline_paint.setColor(Color.GREEN);
		outline_paint.setAntiAlias(true);
		outline_paint.setStrokeWidth(3.f);
	}

	public void setMinMaxValue(float minValue, float maxValue)
	{
		if (maxValue < minValue)
		{
			mMinValue = maxValue;
			mMaxValue = minValue;
		}
		else
		{
			mMinValue = minValue;
			mMaxValue = maxValue;
		}
	}

	public void setGraphStyle(@ColorInt int color, float width) {
		mForePaint.setColor(color);
		mForePaint.setStrokeWidth(width);
	}

	public void setGraphEnable(boolean bEnable) {
		mEnabled = bEnable;
	}

	/*
    private boolean createResources(int width, int height)
    {
    	mWaveBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    	mWaveCanvas = new Canvas();
    	mWaveCanvas.setBitmap(mWaveBitmap);

    	mOverlayBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    	mOverlayCanvas = new Canvas();
    	mOverlayCanvas.setBitmap(mOverlayBitmap);

    	// draw initial overlay
		//drawTextToOverlay(mszLead + " " + mLeadNumber + "        5 mm/Div.", new Rect(10, 10, 0, 0), mOvlTextPaint);
		return true;
    }
    
    private void destroyResources()
    {
		mWaveBitmap = null;
		mWaveCanvas = null;

		mOverlayBitmap = null;
		mOverlayCanvas = null;
    }
	*/




	private boolean mUpdating = false;

	public void clearWaveform() {
		if  (mGraphDrawThread == null)
			return;

		mGraphDrawThread.sendGraphData(null);
	}

	public void updateWaveform(short[] updateData)
	{
		if  (mGraphDrawThread == null)
			return;

        mGraphDrawThread.sendGraphData(updateData);
	    /*
		if (mUpdating)
			return;
		mUpdating = true;

		mGraphLayer.drawGraph(mGraphLayer, updateData);
        mGraphLayer.invalidate(true, false);

		Canvas c = null;
		SurfaceHolder surfaceHolder = getHolder();
		try{
			c = surfaceHolder.lockCanvas(null);
			synchronized (surfaceHolder) {
				DrawWaveform(c);
			}
		} finally {
			if(c!=null){
				surfaceHolder.unlockCanvasAndPost(c);
			}
		}

		mUpdating = false;
		*/
	}

	public void setOverlayTextSize(float size)
	{
		mOvlFontSize = size;
		mOvlTextPaint.setTextSize(mOvlFontSize);
	}

	/*
	public void drawTextToOverlay(String text, Rect rcDraw, Paint drwPaint)
	{
		if (mOverlayCanvas == null)
			return;

		if (drwPaint == null)
			drwPaint = mOvlTextPaint;

		Rect rcBound = new Rect();
		mOvlTextPaint.getTextBounds(text, 0, text.length(), rcBound);
		rcDraw.set(rcDraw.left, rcDraw.top, rcDraw.left + rcBound.left + rcBound.width(), rcDraw.top + rcBound.height());

		Rect rcErase = new Rect();
		rcErase.set(rcDraw.left - 10, rcDraw.top - 10, rcDraw.right + 10, rcDraw.bottom + 10);
		mOverlayCanvas.drawRect(rcErase, mClearPaint);

		mOverlayCanvas.drawText(text, rcDraw.left, rcDraw.top - rcBound.top, drwPaint);
	}

	public void DrawSpeechInfo(int sampleRate, long duration)
	{
		float h = DisplayUtils.PixelFromDP(mContext, mOvlFontSize);

		drawTextToOverlay("SampleRate: " + sampleRate, new Rect(10, 10, 0, 0), null);

		int totalMilliSec = (int)(duration / 1000);
		int totalSec = (int)(totalMilliSec / 1000);
		int min = (int) totalSec / 60;
		int sec = totalSec % 60;
		int milliSec = totalMilliSec % 1000;
		drawTextToOverlay("Duration: " + String.format("%02d:%02d", min, sec) + "." + milliSec, new Rect(10, 10 + (int) h + 8, 0, 0), null);
	}
*/
	private void DrawWaveform(Canvas canvas)
	{
		if (canvas == null)
			return;

		// clear screen
		canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);

		doDraw(canvas);
	}

	private void DrawGrid(Canvas canvas, Rect rcBorder)
	{
		int width = rcBorder.width();
		int height = rcBorder.height();

		float value = 0.f;
		float yc = CalcYDrawPoint(value, rcBorder);
		canvas.drawLine(1, yc, width+1, yc, grid_paint);

		float step = 1000.f;
		float uValue = value + step;
		float lValue = value - step;
		boolean bReachTop = false;
		boolean bReachBottom = false;
		while (!bReachTop || !bReachBottom) {
			float yu = CalcYDrawPoint(uValue, rcBorder);
			if (yu > 0.f) {
				canvas.drawLine(1, yu, width+1, yu, grid_paint);
				uValue += step;
			} else {
				bReachTop = true;
			}

			float yl = CalcYDrawPoint(lValue, rcBorder);
			if (yl < (float)height) {
				canvas.drawLine(1, yl, width+1, yl, grid_paint);
				lValue -= step;
			} else {
				bReachBottom = true;
			}
		}
	}
	
	private void DrawBorder(Canvas canvas, Rect rcBorder)
	{
		canvas.drawRect(rcBorder, outline_paint);
	    // draw outline
 		//canvas.drawLine(0, 0, mWidth-1, 0, outline_paint);	// top
 		//canvas.drawLine(mWidth-1, 0, mWidth-1, mHeight-1, outline_paint); //right
 		//canvas.drawLine(0, mHeight-1, mWidth-1, mHeight-1, outline_paint); // bottom
 		//canvas.drawLine(0, 0, 0, mHeight-1, outline_paint); //left
	}

	private static final int mDrawSpace = 30;

	private float CalcYDrawPoint(float value, Rect r)
	{
		int height = r.height();
		float newValue = (value - mMinValue) * height/(mMaxValue - mMinValue);
		//newValue *= mScaleV;
		//newValue = height/2.0f - newValue;
		return (height - newValue);
		//return newValue;
	}

	public void setupParameter(int samplesCount, Rect r)
	{
		int width = r.width();
		if (samplesCount > width)
			mDrawStep = width/(float)samplesCount;
		else
			mDrawStep = 1.0f;
	}



    // This child thread class has it's own Looper and Handler object.
    private class GraphDrawThread extends Thread{
        private static final int GraphDrawThread_QUIT_LOOPER = 1;
        private static final int MESSAGE_GRAPHDATA = 3;

        private SurfaceHolder _holder;
        private GraphView _view;
        private Handler _handler;

        public GraphDrawThread(SurfaceHolder surfaceHolder, GraphView view){
            this._holder = surfaceHolder;
            this._view = view;
        }

        public void stopGraphDraw() {
            _handler.getLooper().quit();
        }

        public void sendGraphData(short[] gdat) {
            Message m = Message.obtain(_handler, MESSAGE_GRAPHDATA, gdat);
            _handler.sendMessage(m);
        }

        @Override
        public void run() {
            // Prepare child thread Lopper object.
            Looper.prepare();

            // Create child thread Handler.
            _handler = new Handler(Looper.myLooper()){
                @Override
                public void handleMessage(Message msg) {
                    // When child thread handler get message from child thread message queue.
                    //Log.i("CHILD_THREAD", "Receive message from main thread.");

                    if (msg.what == MESSAGE_GRAPHDATA) {
                        short[] pdata = (short[]) msg.obj;
						if (pdata != null) {
							mGraphLayer.drawGraph(mGraphLayer, pdata);
							mGraphLayer.invalidate(true, false);
						} else {
							mGraphLayer.clear();
							mGraphLayer.invalidate(true, false);
						}

                        Canvas c = null;
                        try {
                            c = _holder.lockCanvas(null);
                            synchronized (_holder) {
								if (c != null) {
									c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
									_view.doDraw(c);
								}
                            }
                        } finally {
                            if (c != null) {
                                _holder.unlockCanvasAndPost(c);
                            }
                        }
                    }
                }
            };
            // Loop the child thread message queue.
            Looper.loop();

            // The code after Looper.loop() will not be executed until you call workerThreadHandler.getLooper().quit()
            Log.i("CHILD_THREAD", "This log is printed after Looper.loop() method. Only when this thread loop quit can this log be printed.");
        }
    }
}
