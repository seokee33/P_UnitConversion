package kr.claud.synesper.media;


import static java.lang.System.arraycopy;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

import kr.claud.synesper.R;


public class SmdFilePlayer extends SmdFileReader {
    private static final String TAG = "SmdFilePlayer";

    private Thread mReadThread = null;
    private PCMPlayer mPcmPlayer = null;
    private boolean bPlaying = false;

    public interface OnSmdFilePlayerListener {
        void onPlay(SmdFilePlayer player, Header header);
        void onRead(SmdFilePlayer player, Chunk chunk);
        void onStop(SmdFilePlayer player);
        void onDone(SmdFilePlayer player, boolean bSuccess);
    }
    private OnSmdFilePlayerListener mListener = null;
    public void setOnSmdFilePlayerListener(OnSmdFilePlayerListener l) {
        mListener = l;
    }

    //---------------------------------------------------
    public SmdFilePlayer(PCMPlayer player) {
        this.mPcmPlayer = player;
    }

    public boolean isPlaying() {
        return bPlaying;
    }


    // kim -> 재생시 여기로 3 : 저장판 파일 재생
    public boolean play(String filePath) {
        if (!open(filePath)) {
            if (mListener != null) {
                mListener.onDone(SmdFilePlayer.this, false);
                Log.i("kim_play","mListener.onDone(SmdFilePlayer.this, false);");
            }
            return false;
        }

        mReadThread = new Thread(new Runnable() {
            @Override
            public void run() {
                Header header = readHeader();
                if (mListener != null) {
                    mListener.onPlay(SmdFilePlayer.this, header);
                }

                byte type = SmdFile.ChunkType.PCG.getIndex();

                bPlaying = true;
                while(bPlaying) {
                    Chunk chunk = readChunk();

                    if (chunk == null) {
                        break;
                    }
                    //Log.i("kim","Chunk - readData"+Arrays.toString(chunk.getData()));
                    if (chunk.type == type) {
                        if (mListener != null) {
                            mListener.onRead(SmdFilePlayer.this, chunk);
                        }
                    }
                    Log.i("kim_play","while(bPlaying) {");
                }

                if (mListener != null && bPlaying) {
                    mListener.onDone(SmdFilePlayer.this, true);
                    Log.i("kim_play","mListener.onDone(SmdFilePlayer.this, true);");
                }
                bPlaying = false;
            }
        });
        mReadThread.start();
        return true;
    }

    public void stop() {
        if (bPlaying) {
            bPlaying = false;

            if (mReadThread != null) {
                try {
                    mReadThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if (mListener != null) {
                    mListener.onStop(SmdFilePlayer.this);
                }
            }
            mReadThread = null;
        }

        close();
    }
}