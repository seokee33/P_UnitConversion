package kr.claud.synesper.ui.register;

public class RegisteredInUserView {
    private String name;
    //... other data fields that may be accessible to the UI

    public RegisteredInUserView(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return name;
    }
}
