package kr.claud.synesper.media;


import static java.lang.System.arraycopy;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;


/*
  C:\Users\pysik\AppData\Local\Google\AndroidStudio2021.2\device-explorer\pixel_5_-_api_31 [emulator-5554]\sdcard\Android\data\kr.claud.synesper\files


<<< Synesper Media Data(smd) >>>

  File format
-------------------------------------------------
Identity:
  (16)'SMD File' + EOF

Header:
  (4)length
  (4)created date : Year - short(2), Month - byte(1), Day - byte(1)
  (32)user name
  (2)week
  (4)delivery date

Chunk:
  (4)length
  (1)type - pcg(voice) or ppg
  (1)bpm
  (4)sequence
  (4)timestamp (msec)

  signal data
*/
public class SmdFileReader extends SmdFile {
    public static final String TAG = "SmdFileReader";

    private FileInputStream mFileInputStream = null;
    private String mFileName = null;
    private String mFilePath = null;


    public SmdFileReader() {
    }

    public boolean isOpened() {
        return (mFileInputStream != null);
    }

    public String getFileName() {
        return mFileName;
    }

    public String getFilePath() {
        return mFilePath;
    }


    protected boolean _open(File file) {
        try {
            mFileInputStream = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            mFileInputStream = null;
            e.printStackTrace();
            //kim (지워야하는거)
            //Log.d("kim", "SMD FILE READ ERROR(_open) : " + e.toString());
            return false;
        }

        //(16)'SMD File' + EOF
        if (mFileInputStream != null) {
            try {
                byte[] rbuff = new byte[16];
                int len = mFileInputStream.read(rbuff);

                if (len == 16) {
                    byte[] wbuff = new byte[16];
                    byte[] str = _idStr.getBytes(StandardCharsets.UTF_8);
                    arraycopy(str, 0, wbuff, 0, str.length);
                    wbuff[str.length] = 0x1A;
                    //Log.d("kim", "SMD FILE READ((16)'SMD File' + EOF) : " + Arrays.toString(wbuff));
                    if (Arrays.equals(rbuff, wbuff)) {
                        return true;
                    }
                }
            } catch (IOException e) {
                //kim (지워야하는거)
                //Log.d("kim", "SMD FILE READ ERROR(_open) : " + e.toString());
                e.printStackTrace();
            }

            close();
        }
        return false;
    }

    //ctx.getFilesDir();             : "/data/data/kr.claud.synesper/files/"
    //ctx.getExternalCacheDir();     :
    //ctx.getExternalFilesDir(null); : "/Android/data/kr.claud.synesper/files/"
    public boolean open(File fileDir, String fileName) {
        File ofile = new File(fileDir, fileName);
        if (!ofile.exists()) {
            return false;
        }

        this.mFileName = fileName;
        this.mFilePath = ofile.getAbsolutePath();
        Log.d(TAG, "FilePath=" + mFilePath);

        return _open(ofile);
    }

    public boolean open(Context ctx, String fileName) {
        File smdFilesDir = getSmdFilesDir(ctx);
        return open(smdFilesDir, fileName);
    }

    public boolean open(String filePath) {
        File smdFile = new File(filePath);
        if (!smdFile.exists()) {
            return false;
        }

        this.mFileName = smdFile.getName();
        this.mFilePath = smdFile.getAbsolutePath();
        Log.d(TAG, "FileName=" + mFileName);
        Log.d(TAG, "FilePath=" + mFilePath);

        return _open(smdFile);
    }

    public boolean close() {
        if (mFileInputStream != null) {
            try {
                mFileInputStream.close();
            } catch (IOException e) {
                //kim (지워야하는거)
                //Log.d("kim", "SMD FILE READ ERROR(close) : " + e.toString());
                e.printStackTrace();
                return false;
            }
            mFileInputStream = null;
            return true;
        }
        return false;
    }

    public void clear() {
        mFileName = null;
        mFilePath = null;
    }

    public Header readHeader() {
        if (mFileInputStream != null) {
            try {
                byte[] rbuff = new byte[Header.header_length];
                int len = mFileInputStream.read(rbuff);
                if (len == Header.header_length) {
                    Log.d(TAG, "read header: length = " + len);
                    //kim (지워야하는거)
                    //Log.d("kim", "readHeader : " + Arrays.toString(rbuff));
                    Header header = new Header(rbuff);
                    return header;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public Chunk readChunk() {
        if (mFileInputStream != null) {
            try {
                byte[] rbuff = new byte[Chunk.chunk_info_length];
                int len = mFileInputStream.read(rbuff);
                if (len == Chunk.chunk_info_length) {
                    int dataLength = Chunk.calcDataLength(rbuff) - Chunk.chunk_info_length;
                    //Log.d(TAG, "read data: length = " + dataLength);
                    byte[] dataBuff = new byte[dataLength];
                    //kim (지워야하는거)
                    //Log.d("kim", "readChunk : " + Arrays.toString(dataBuff));
                    if (mFileInputStream.read(dataBuff) == dataLength) {
                       Chunk chunk = new Chunk(rbuff, dataBuff);
                       return chunk;
                    }
                }
            } catch (IOException e) {
                //kim (지워야하는거)
                //Log.d("kim", "SMD FILE READ ERROR(readChunk) : " + e.toString());
                e.printStackTrace();
            }
        }
        return null;
    }
}