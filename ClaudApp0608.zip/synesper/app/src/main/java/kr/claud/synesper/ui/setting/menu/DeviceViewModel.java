package kr.claud.synesper.ui.setting.menu;

import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import kr.claud.synesper.device.SynesperAdapter;

public class DeviceViewModel extends ViewModel {

    private static ArrayList<SynesperAdapter.SynesperItem> mArrayList;
    static {
        mArrayList = new ArrayList<>();
    }

    private SynesperAdapter mSynesperAdapter;
    //private int count = 0;

    public DeviceViewModel() {
        mSynesperAdapter = new SynesperAdapter(null, mArrayList);
    }

    public void setAdapterItemClickListener(SynesperAdapter.OnItemClickListener l) {
        mSynesperAdapter.setOnItemClickListener(l);
    }

    public ArrayList<SynesperAdapter.SynesperItem> getArrayList() {
        return mArrayList;
    }

    //20230224
    public void removeDevice(int pos) {
        mArrayList.remove(pos);
        mSynesperAdapter.notifyItemRemoved(pos);
    }

    public void clearArrayList() {
        mArrayList.clear();
        mSynesperAdapter.notifyDataSetChanged();
    }

    public SynesperAdapter getAdapter() {
        return mSynesperAdapter;
    }

    public boolean addSynesper(String name, String address, int rssi) {
        return mSynesperAdapter.addSynesper(name, address, rssi);
    }
}