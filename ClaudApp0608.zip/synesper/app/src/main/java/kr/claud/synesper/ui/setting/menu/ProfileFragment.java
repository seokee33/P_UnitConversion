package kr.claud.synesper.ui.setting.menu;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONException;

import java.util.Date;

import kr.claud.libs.api.RetrofitClient;
import com.ms.api.changeuser.ChangeAccount;
import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.databinding.FragmentProfileBinding;
import kr.claud.synesper.dialog.DeliveryPickerDialog;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.dialog.ProfilePhotoDialog;
import kr.claud.synesper.media.ProfileImage;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {

    private ProfileViewModel profileViewModel;

    private FragmentProfileBinding binding;
    private ImageView imageViewPhoto;

    private Bitmap bitmapPhoto = null;

    private Date deliveryDate = null;

    private boolean photoChanged = false;
    private boolean nameChanged = false;
    private boolean deliveryChanged = false;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initDeliveryWidgets();
        initButton();
        initTextView();

        //final TextView textView = binding.textProfile;
        //profileViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    private void initButton() {
        AppData ad = AppData.I();
        imageViewPhoto = binding.imageViewPhoto;
        ProfileImage pi = ad.mUserData.mProfileImage;
        if (pi.getImage() != null) {
            binding.imageViewPhoto.setImageBitmap(pi.getImage());
        }
        imageViewPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtil.showProfilePhoto(getContext(), new ProfilePhotoDialog.ProfilePhotoDialogListener() {
                    @Override
                    public void onPositiveClicked(String result) {
                        MainActivity macty = (MainActivity) getActivity();
                        macty.clickProfilePhotoByProfileFragment(result);
                    }

                    @Override
                    public void onNegativeClicked() {

                    }
                });
            }
        });

        binding.buttonApply.setEnabled(false);
        binding.buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = null;
                Date date = null;
                if (photoChanged) {
                    pi.setImage(bitmapPhoto);
                    photoChanged = false;
                }

                if (nameChanged) {
                    userName = binding.editTextName.getText().toString();
                    nameChanged = false;
                }

                if (deliveryChanged) {
                    date = deliveryDate;
                    deliveryChanged = false;
                }

                updateApplyButtonUi();

                try {
                    if(userName == null){
                        userName = binding.editTextName.getText().toString();
                    }
                    changeAccountUserInfo(userName,date);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }


                deliveryDate = null;
            }
        });
    }

    private void changeAccountUserInfo(String userName, Date date) throws JSONException {
        ChangeAccount.account(userName, DBHelper.stringFromDate(date), new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if(response.isSuccessful()){
                    if(response.code() == 200){
                        //success
                        MainActivity macty = (MainActivity) getActivity();
                        macty.clickApplyByProfileFragment(userName, date);
                        Toast.makeText(getContext(),"회원정보 수정 성공",Toast.LENGTH_LONG).show();
                    }else{
                        Toast.makeText(getContext(),"회원정보 수정 실패",Toast.LENGTH_LONG).show();
                    }
                }else{
                    Toast.makeText(getContext(),"회원정보 수정 실패",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("changeAccountUserInfo",call.toString());
                Toast.makeText(getContext(),"회원정보 수정 실패",Toast.LENGTH_LONG).show();
            }
        });

    }

    private void initTextView() {
        UserData ud = AppData.I().mUserData;
        binding.editTextName.setText(ud.userName());
        binding.editTextDelivery.setText(ud.userDelivery());
        String szWeek = UserData.weeksPregnantFromDelivery(new Date(), ud.userDelivery()) + " " + getContext().getString(R.string.signup_n_week);
        binding.textViewWeek.setText(szWeek);

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                nameChanged = true;
                updateApplyButtonUi();
            }
        };
        binding.editTextName.addTextChangedListener(afterTextChangedListener);
    }

    private void initDeliveryWidgets() {
        final ImageView deliveryImageView = binding.imageViewCalendar;
        deliveryImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtil.showDeliveryPicker(getContext(), new DeliveryPickerDialog.DeliveryPickerDialogListener() {
                    @Override
                    public void onClearClicked() {
                        String szDelivery = "";
                        String szWeek = "- " + getContext().getString(R.string.signup_n_week);

                        binding.editTextDelivery.setText(szDelivery);
                        binding.textViewWeek.setText(szWeek);

                        deliveryChanged = true;
                        updateApplyButtonUi();
                    }

                    @Override
                    public void onPositiveClicked(int year, int month, int day) {
                        String szDelivery = DBHelper.stringDateFrom(year, month, day);
                        String szWeek = UserData.weeksPregnantFromDelivery(new Date(), year, month, day) + " " + getContext().getString(R.string.signup_n_week);
                        binding.editTextDelivery.setText(szDelivery);
                        binding.textViewWeek.setText(szWeek);

                        deliveryDate = DateUtil.dateFrom(year, month, day);
                        deliveryChanged = true;

                        updateApplyButtonUi();
                    }

                    @Override
                    public void onNegativeClicked() {

                    }
                });
            }
        });
    }

    public void updateApplyButtonUi() {
        if (photoChanged || nameChanged || deliveryChanged) {
            binding.buttonApply.setEnabled(true);
        } else {
            binding.buttonApply.setEnabled(false);
        }
    }

    public void updateProfilePhoto(Bitmap bitmap) {
        if (bitmap != null) {
            binding.imageViewPhoto.setImageBitmap(bitmap);
            photoChanged = true;
        } else {
            binding.imageViewPhoto.setImageResource(R.drawable.profile_app_bar_icon1);

            if (bitmapPhoto != null)
                photoChanged = true;
        }

        bitmapPhoto = bitmap;
        updateApplyButtonUi();
    }
}