package kr.claud.synesper.ui.setting.menu;

import android.util.Log;

import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import kr.claud.synesper.R;
import kr.claud.synesper.ui.register.RegisterFormState;
import kr.claud.synesper.ui.register.RegisterResult;

public class AccountViewModel extends ViewModel {

    private MutableLiveData<AccountFormState> accountFormState = new MutableLiveData<>();
    private MutableLiveData<AccountResult> accountResult = new MutableLiveData<>();

    public LiveData<AccountFormState> getAccountFormState() {
        return accountFormState;
    }

    public LiveData<AccountResult> getAccountResult() {
        return accountResult;
    }


    public AccountViewModel() {
    }

    public void registerDataChanged(String username, String password, String passwordNew, String passwordConfirm) {
        Integer usernameError = null;
        Integer passwordError = null;
        Integer passwordNewError = null;
        Integer passwordConfirmError = null;
        boolean bOccur = false;
        if (!isUserNameValid(username)) {
            usernameError = R.string.invalid_username;
            bOccur = true;
        }
        if (!isPasswordValid(password)) {
            passwordError = R.string.invalid_password;
            bOccur = true;
        }
        if (!isPasswordValid(passwordNew)) {
            passwordNewError = R.string.invalid_password;
            bOccur = true;
        }
        if (!isPasswordValid(passwordConfirm)) {
            passwordConfirmError = R.string.invalid_password;
            bOccur = true;
        }

        if (bOccur) {
            accountFormState.setValue(new AccountFormState(usernameError, passwordError, passwordNewError, passwordConfirmError));
        } else {
            accountFormState.setValue(new AccountFormState(true));
        }
    }


    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        return username.matches("^[a-zA-Z0-9]*$");
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        if (password == null || password.length() == 0)
            return true;
        return password.trim().length() > 3 && password.trim().length() < 13;
    }
}