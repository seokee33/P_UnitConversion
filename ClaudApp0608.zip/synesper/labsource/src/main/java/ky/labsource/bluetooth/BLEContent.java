/*
BLE Device Manage: Scan
*/
package ky.labsource.bluetooth;

import static ky.labsource.bluetooth.BLEContent.OnScanListener.*;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothAdapter.LeScanCallback;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

import ky.labsource.LsBluetooth;

public class BLEContent {
    public static final String TAG = "BLEContent";

    private static BLEContent _bleContent;

    static {
        _bleContent = null;
    }

    public static BLEContent IGet() {
        return _bleContent;
    }

    public static boolean isBLESupported(Context ctx) {
        return ctx.getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE);
    }

    public static boolean isBluetoothSupported() {
        if (_bleContent == null)
            return false;

        if (_bleContent.mBTAdapter == null)
            return false;

        return true;
    }

    public static BLEContent createInstance(Context ctx) {
        if (_bleContent == null) {
            _bleContent = new BLEContent();
            if (!_bleContent._createBLEContent(ctx))
                _bleContent = null;
        }
        return _bleContent;
    }


    private BluetoothAdapter mBTAdapter = null;

    private boolean mScanning = false;

    /* An array of BLE device items. */
    public List<DeviceItem> ITEMS = new ArrayList<DeviceItem>();
    //public Map<String, Integer> devRssiValues;

    public DeviceItem getLEDevice(int pos) {
        return ITEMS.get(pos);
    }

    public int countLEDevice() {
        return ITEMS.size();
    }

    public interface OnScanListener {
        void onScan(BluetoothDevice device, int rssi, byte[] scanRecord);
    }
    protected OnScanListener mScanListener = null;
    public void setOnScanListener(OnScanListener l) { mScanListener = l; }

    protected android.bluetooth.le.ScanCallback mScanCallback = null;
    protected BluetoothAdapter.LeScanCallback mLeScanCallback = null;

    void setScanCallback()
    {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            // Device scan callback.
            mScanCallback = new android.bluetooth.le.ScanCallback() {

                @Override
                public void onScanResult(int callbackType, ScanResult result) {
                    if (mScanListener != null) {
                        ScanRecord scanRecord = result.getScanRecord();
                        mScanListener.onScan(result.getDevice(), result.getRssi(), scanRecord.getBytes());
                    }
                }
            };
        } else {
            mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

                @Override
                public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
                    if (mScanListener != null) {
                        mScanListener.onScan(device, rssi, scanRecord);
                    }
                }
            };
        }
    }

    private boolean _createBLEContent(Context ctx) {
        final BluetoothManager bluetoothManager = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        mBTAdapter = bluetoothManager.getAdapter();
        if (mBTAdapter == null)
            return false;
        setScanCallback();
        return true;
    }


    public BluetoothAdapter getBluetoothAdapter() {
        return mBTAdapter;
    }

    public boolean isBluetoothEnabled() {
        if (mBTAdapter == null)
            return false;

        return mBTAdapter.isEnabled();
    }

    public boolean isScanning() {
        return mScanning;
    }

    @SuppressLint("MissingPermission")
    public void startLEScan(OnScanListener l) {
        mScanning = true;
        setOnScanListener(l);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BluetoothLeScanner bleScanner = mBTAdapter.getBluetoothLeScanner();
            bleScanner.startScan(mScanCallback);
        } else {
            mBTAdapter.startLeScan(mLeScanCallback);
        }
    }

    @SuppressLint("MissingPermission")
    public void stopLEScan(OnScanListener l) {
        mScanning = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            BluetoothLeScanner bleScanner = mBTAdapter.getBluetoothLeScanner();
            bleScanner.stopScan(mScanCallback);
        } else {
            mBTAdapter.stopLeScan(mLeScanCallback);
        }
        setOnScanListener(null);
    }

    public boolean addLEDevice(BluetoothDevice device, int rssi) {
        boolean deviceFound = false;

        for (DeviceItem di : ITEMS) {
            if (di.ADDRESS().equals(device.getAddress())) {
                deviceFound = true;
                di.setRssi(rssi);
                break;
            }
        }

        if (!deviceFound) {
            ITEMS.add(new DeviceItem(device, rssi));
        }

        return !deviceFound;
    }

    public void clearLEDeviceAll() {
        ITEMS.clear();
    }

    public BluetoothDevice getLERemoteDevice(String address) {
        return mBTAdapter.getRemoteDevice(address);
    }

    /**
     * A device item representing a piece of content.
     */
    public class DeviceItem {
        public final BluetoothDevice devLE;
        public int rssi;

        public DeviceItem(BluetoothDevice devLE, int rssi) {
            this.devLE = devLE;
            this.rssi = rssi;
        }

        public void setRssi(int rssi) {
            this.rssi = rssi;
        }

        public String RSSI() { return String.valueOf(this.rssi); }
        @SuppressLint("MissingPermission")
        public String NAME() { return this.devLE.getName(); }
        public String ADDRESS() { return this.devLE.getAddress(); }

        @SuppressLint("MissingPermission")
        @Override
        public String toString() {
            return devLE.getName() + '(' + devLE.getAddress() + ')';
        }
    }
}
