package kr.claud.libs.datatype;

import androidx.annotation.NonNull;

public class StringUtil {

    @NonNull
    public static String rShift(@NonNull String s) {
        return s.charAt(s.length()-1) + s.substring(0, s.length()-1);
    }

    @NonNull
    public static String nrShift(@NonNull String s, int n) {
        n = n % s.length();
        if (n == 0)
            return s;
        return s.substring(s.length()-n, s.length()) + s.substring(0, s.length()-n);
    }

    public static String exchange(@NonNull String s, int n1, int n2) {
        if (s.length() == 0)
            return s;
        n1 = n1 % s.length();
        n2 = n2 % s.length();

        char c1 = s.charAt(n1);
        char c2 = s.charAt(n2);

        StringBuilder sb = new StringBuilder(s);
        sb.setCharAt(n1, c2);
        sb.setCharAt(n2, c1);
        return sb.toString();
    }
}
