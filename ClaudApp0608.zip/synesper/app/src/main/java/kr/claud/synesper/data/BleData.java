package kr.claud.synesper.data;

import android.util.Log;

import kr.claud.synesper.dsp.ADPCM;
import kr.claud.synesper.dsp.Filter;
import kr.claud.synesper.dsp.PulseSignal;

public class BleData {
    public static final String TAG = "BleData";

    public static final int PCG_CHANNEL_COUNT = 1;
    public static final int PCG_SAMPLERATE = 16000;

    public static final int PPG_THRESHOLD = 100000;


    private ADPCM.State mAdpcmState;
    private PulseSignal.MovingAverage maPCG;
    private Filter.FilterContext fctxPCG;
    private Filter mFilterPCG;

    private PulseSignal psPPG;

    // Constructor
    public BleData() {
        psPPG = new PulseSignal();
        initPPG();

        mAdpcmState = new ADPCM.State();
        maPCG = new PulseSignal.MovingAverage();

        Filter.BIQUAD[] biquads = new Filter.BIQUAD[2];
        biquads[0] = new Filter.BIQUAD();
        biquads[1] = new Filter.BIQUAD();
        fctxPCG = new Filter.FilterContext(PCG_CHANNEL_COUNT, biquads);
        mFilterPCG = new Filter();

        initPCG();
    }

    public void init() {
        initPPG();
        initPCG();
    }

    private void initPPG() {
        psPPG.init();
    }

    private void initPCG() {
        mAdpcmState.reset();
        maPCG.init();
        psPPG.init();

        //static biquad_t biquads[/*MIC_CHANNELS_MAX*/ 2];
        //static filter_context_t filter = { 1, biquads };
        fctxPCG.setChannelCount(1);
        Filter.FilterParameters fpPCG = new Filter.FilterParameters(Filter.FilterType.HPF, 0, 100, PCG_SAMPLERATE, 2);
        //Filter.FilterParameters fpPCG = new Filter.FilterParameters(Filter.FilterType.BPF, 0, 6000, PCG_SAMPLERATE, 5500);
        mFilterPCG.init(fctxPCG, fpPCG);
    }

    //kim (체크) -> 실제 음성 데이터 : outdata
    public short[] decodeVoice(byte[] encData) {
        short[] outdata = new short[encData.length * 2];
        mAdpcmState.reset();
        ADPCM.adpcm_decoder(encData, outdata, encData.length * 2, mAdpcmState);
        return outdata;
    }

    public short[] filterVoice(short[] voiceData) {
        short[] filteredData = mFilterPCG.filtering(fctxPCG, voiceData, voiceData.length);
        return filteredData;
    }

    public short[] subsampleVoice(short[] adpcmVoice, int divider) {
        if (divider <= 0)
            divider = 1;

        short[] subSample = new short[adpcmVoice.length/divider];
        int k = 0;
        for (int i=0; i<adpcmVoice.length; i++) {
            short val = maPCG.filter(adpcmVoice[i]);
            if ((i%divider) == 0) {
                subSample[k] = val;
                k++;
            }
        }
        return subSample;
    }

    public int[] decodePPG(byte[] txValue) {
        int[] rawPPG = new int[txValue.length/6];
        int i, j;
        for (i=0, j=0 ; i<txValue.length ; i+=6, j++) {
            long val0 = ((txValue[i] - 'A') << 4) | (txValue[i+1] - 'A');
            long val1 = ((txValue[i+2] - 'A') << 4) | (txValue[i+3] - 'A');
            long val2 = ((txValue[i+4] - 'A') << 4) | (txValue[i+5] - 'A');
            int sample = (int) ((val0<<16) + (val1<<8) + val2);
            rawPPG[j] = (sample < PPG_THRESHOLD) ? 0 : sample; //20230224
        }
        return rawPPG;
    }

    public FilteredData filterPPG(int[] rawPPG) {
        short[] fPPG = new short[rawPPG.length];
        int i = 0;
        short min = Short.MAX_VALUE;
        short max = Short.MIN_VALUE;

        for (int sample : rawPPG) {
            float dcrVal = psPPG.dcRemover(sample);
            float lpfVal = psPPG.lpFilter(dcrVal * (-1));
            short sVal = (short) (lpfVal / 4);
            if (sVal < min)
                min = sVal;
            if (sVal > max)
                max = sVal;
            fPPG[i] = sVal;

            //short dcVal = psPPG.dcFilter(sample);
            //short maVal = psPPG.maFilter((short)(dcVal * (-1))); //20230224: x(-1)
            //fPPG[i] = (short) (maVal/8);

            i++;
        }
        return new FilteredData(fPPG, min, max);
    }

    public class FilteredData {
        public short[] ppgs;
        public short min;
        public short max;

        public FilteredData(short[] ppgs, short min, short max) {
            this.ppgs = ppgs;
            this.min = min;
            this.max = max;
        }
    }
}