package ky.labsource.bluetooth;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import java.util.UUID;

import ky.labsource.bluetooth.ble.BleOnService;
import ky.labsource.bluetooth.ble.UUIDGroup;


public class BLEManager {
    private static final String TAG = BLEManager.class.getSimpleName();

    public final static String ACTION_GATT_CONNECTED           = "ky.labsource.BLE.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED        = "ky.labsource.BLE.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = "ky.labsource.BLE.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DESCRIPTOR_WRITE         = "ky.labsource.BLE.ACTION_DESCRIPTOR_WRITE";
    public final static String ACTION_DATA_AVAILABLE           = "ky.labsource.BLE.ACTION_DATA_AVAILABLE";
    public final static String EXTRA_DATA                      = "ky.labsource.BLE.EXTRA_DATA";
    public final static String DEVICE_DOES_NOT_SUPPORT_UART    = "ky.labsource.BLE.DEVICE_DOES_NOT_SUPPORT_UART";
    public final static String DEVICE_DOES_NOT_SUPPORT_VOBLE   = "ky.labsource.BLE.DEVICE_DOES_NOT_SUPPORT_VOBLE";

    public static final int PROFILE_DISCONNECTED = 20;
    public static final int UART_PROFILE_CONNECTED = 21;
    public static final int VOBLE_PROFILE_CONNECTED = 22;


    static {
        _bleMgr = null;
    }

    private static BLEManager _bleMgr;

    public static BLEManager createInstance(Context ctx) {
        if (_bleMgr == null) {
            _bleMgr = new BLEManager();
        }
        return _bleMgr;
    }

    public static BLEManager IGet() {
        return _bleMgr;
    }

    public static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_GATT_CONNECTED);
        intentFilter.addAction(ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(ACTION_DESCRIPTOR_WRITE);
        intentFilter.addAction(ACTION_DATA_AVAILABLE);
        intentFilter.addAction(EXTRA_DATA);
        intentFilter.addAction(DEVICE_DOES_NOT_SUPPORT_UART);
        return intentFilter;
    }

    public static void broadcastUpdate(Context ctx, String action) {
        Log.d(TAG, "broadcastUpdate(): action=" + action);

        final Intent intent = new Intent(action);
        LocalBroadcastManager.getInstance(ctx).sendBroadcast(intent);
    }

    public static void broadcastUpdate(Context ctx, String action, BluetoothGattCharacteristic characteristic) {
        Intent intent = new Intent(action);
        if (characteristic != null) {
            // This is handling for the notification on TX Character of NUS service
            intent.putExtra(EXTRA_DATA, characteristic.getValue());
            LocalBroadcastManager.getInstance(ctx).sendBroadcast(intent);
        }
    }

    public static void broadcastUpdate(Context ctx, String action, BluetoothGattDescriptor descriptor) {
        final Intent intent = new Intent(action);
        intent.putExtra(EXTRA_DATA, descriptor.getValue());
        LocalBroadcastManager.getInstance(ctx).sendBroadcast(intent);
    }

    //---------------------------------------------------------
    private BluetoothManager mBluetoothManager = null;
    private BluetoothAdapter mBluetoothAdapter = null;

    private DeviceGatt mDeviceGatt = null;
    private BleOnService _bleService = null;

    private int mState = PROFILE_DISCONNECTED;


    public interface OnBleServiceListener {
        void onServiceConnected(boolean bInit);
        void onServiceDisconnected();

        DeviceGatt onDeviceCreate(Context ctx, BluetoothDevice device);
        void onDeviceConnected();
        void onDeviceDisconnected();

        void onStatusChangeReceiver(String action);
        void onStatusChangeReceiverData(byte[] txValue);
    }
    public void setOnBleServiceListener(OnBleServiceListener _bleServiceListener) {
        this._bleServiceListener = _bleServiceListener;
    }
    private OnBleServiceListener _bleServiceListener = null;

    //===========================================================================
    public BLEManager() {
    }
/*
    private boolean _initialize(Context ctx) {
        // For API level 18 and above, get a reference to BluetoothAdapter through BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }
        return true;
    }
*/
    private boolean _init_(Context ctx) {
        // For API level 18 and above, get a reference to BluetoothAdapter through BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) ctx.getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        IntentFilter gattUpdateFilter = makeGattUpdateIntentFilter();
        LocalBroadcastManager.getInstance(ctx).registerReceiver(_broadcastReceiver, gattUpdateFilter);
        return true;
    }

    public boolean init(Context ctx) {
        boolean bRet = _init_(ctx);

        if (_bleServiceListener != null) {
            _bleServiceListener.onServiceConnected(bRet);
        }
        return bRet;
    }

    public boolean init(Context ctx, boolean bEnableService) {
        if (bEnableService) {
            Intent bindIntent = new Intent(ctx, BleOnService.class);
            ctx.bindService(bindIntent, _serviceConnection, Context.BIND_AUTO_CREATE);
            Log.d(TAG, "init(): after bindService...");
        } else {
            boolean bRet = init(ctx);
            return bRet;
        }
        return true;
    }

    public void destroy(Context ctx) {
        try {
            LocalBroadcastManager.getInstance(ctx).unregisterReceiver(_broadcastReceiver);
        } catch (Exception ignore) {
            Log.e(TAG, ignore.toString());
        }

        if (_bleService != null) {
            ctx.unbindService(_serviceConnection);

            _bleService.stopSelf();
            _bleService= null;
        } else {
            if (_bleServiceListener != null) {
                _bleServiceListener.onServiceDisconnected();
                _bleServiceListener = null;
            }
        }
    }

    /*
    public void initService(Context ctx) {
        Intent bindIntent = new Intent(ctx, BleOnService.class);
        ctx.bindService(bindIntent, _serviceConnection, Context.BIND_AUTO_CREATE);

        IntentFilter gattUpdateFilter = makeGattUpdateIntentFilter();
        LocalBroadcastManager.getInstance(ctx).registerReceiver(_broadcastReceiver, gattUpdateFilter);
    }

    public void destroyService(Context ctx) {
        try {
            LocalBroadcastManager.getInstance(ctx).unregisterReceiver(_broadcastReceiver);
        } catch (Exception ignore) {
            Log.e(TAG, ignore.toString());
        }

        ctx.unbindService(_serviceConnection);

        if (_bleService != null) {
            _bleService.stopSelf();
            _bleService= null;
        }
    }
     */
    //--------------------------------------------------------

    public boolean connectDevice(Context ctx, String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        boolean bRet = true;
        // Previously connected device.  Try to reconnect.
        if (mDeviceGatt != null) {
            Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
            bRet = mDeviceGatt.connect();
        } else {
            BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
            if (device == null) {
                Log.w(TAG, "Device not found.  Unable to connect.");
                return false;
            }

            mDeviceGatt = null;
            if (_bleServiceListener != null) {
                mDeviceGatt = _bleServiceListener.onDeviceCreate(ctx, device);
            }
            // We want to directly connect to the device, so we are setting the autoConnect parameter to false.
            if (mDeviceGatt == null)
                mDeviceGatt = new DeviceGatt(ctx, device);
        }

        if (_bleServiceListener != null) {
            _bleServiceListener.onDeviceConnected();
        }
        return bRet;
    }

    public void disconnectDevice() {
        if (mBluetoothAdapter == null || mDeviceGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }

        mDeviceGatt.disconnect();
        mDeviceGatt.close();
        mDeviceGatt = null;

        if (_bleServiceListener != null) {
            _bleServiceListener.onDeviceDisconnected();
        }
    }

    public int getState() {
        return mState;
    }

    public void closeDevice() {
        if (mDeviceGatt != null) {
            mDeviceGatt.close();
            mDeviceGatt = null;
        }
    }

    public DeviceGatt getDevice() {
        return mDeviceGatt;
    }

    //===================================================
    // Service
    private ServiceConnection _serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder rawBinder) {
            _bleService = ((BleOnService.LocalBinder) rawBinder).getService();
            Log.d(TAG, "onServiceConnected mService= " + _bleService);

            _bleService.setOnServiceListener(new BleOnService.OnServiceListener() {
                @Override
                public IBinder onBind(Intent intent) {
                    return null;
                }

                @Override
                public void onUnbind(Intent intent) {
                    closeDevice();
                }
            });

            boolean bRes = _init_(_bleService);
            if (!bRes) {
                Log.e(TAG, "Unable to initialize Bluetooth");
            }

            if (_bleServiceListener != null) {
                _bleServiceListener.onServiceConnected(bRes);
            }
        }

        public void onServiceDisconnected(ComponentName classname) {
            ////     mService.disconnect(mDevice);
            if (_bleServiceListener != null) {
                _bleServiceListener.onServiceDisconnected();
                _bleServiceListener = null;
            }
        }
    };


    private final BroadcastReceiver _broadcastReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            if (_bleServiceListener != null) {
                String action = intent.getAction();
                if (action.equals(ACTION_DATA_AVAILABLE)) {
                    final byte[] txValue = intent.getByteArrayExtra(EXTRA_DATA);
                    _bleServiceListener.onStatusChangeReceiverData(txValue);
                } else {
                    if (action.equals(ACTION_GATT_CONNECTED)) {
                        mState = VOBLE_PROFILE_CONNECTED;
                        Log.d(TAG, "ACTION_VOBLE_CONNECTED");
                    } else if (action.equals(ACTION_GATT_DISCONNECTED)) {
                        mState = PROFILE_DISCONNECTED;
                        Log.d(TAG, "ACTION_VOBLE_DISCONNECTED");
                    }
                    _bleServiceListener.onStatusChangeReceiver(action);
                }
            }
        }
    };
}
