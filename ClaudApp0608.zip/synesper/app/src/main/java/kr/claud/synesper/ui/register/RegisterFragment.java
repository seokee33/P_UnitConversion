package kr.claud.synesper.ui.register;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import kr.claud.synesper.R;

public class RegisterFragment extends Fragment {

    public RegisterViewModel mViewModel;
    public RegisterViewModel getViewModel() { return mViewModel; }
    public void setViewModel(RegisterViewModel viewModel) { mViewModel = viewModel; }

    public interface OnFragmentListener {
        void onViewCreated(@NonNull RegisterFragment fragment, View v);
        void onFragmentNext(@NonNull RegisterFragment fragment);
    }
    private OnFragmentListener mOnFragmentListener = null;
    public void setOnFragmentListener(OnFragmentListener l) {
        mOnFragmentListener = l;
    }
    public void frgmentListener_onViewCreated(RegisterFragment fragment, View v) {
        if (mOnFragmentListener != null) {
            mOnFragmentListener.onViewCreated(this, v);
        }
    }
    public void frgmentListener_onFragmentNext() {
        if (mOnFragmentListener != null) {
            mOnFragmentListener.onFragmentNext(this);
        }
    }

    public int mFragmentPage = -1;
    public int getFragmentPage() {
        return mFragmentPage;
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        frgmentListener_onViewCreated(this, view);
    }

}