package ky.labsource;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

public class LsIsEverything {
    private static final String TAG = "Everything";

    public static final String NAME = "LabSource";
    public static final String MAKER = "KYLab";
    public static final String PROGRAMMER = "YoungSik Park";


    public static void getLibInfo(Context ctx) {
        try {
            PackageInfo pInfo = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0);
            int versionCode = pInfo.versionCode;
            String versionName = pInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
    }
}
