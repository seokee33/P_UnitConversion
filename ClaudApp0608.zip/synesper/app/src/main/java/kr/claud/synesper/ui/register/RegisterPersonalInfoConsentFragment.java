package kr.claud.synesper.ui.register;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.ms.api.personalinfoconsent.GetPersonalInfoConsent;

import kr.claud.synesper.databinding.FragmentRegisterPersonalinfoconsentBinding;
import kr.claud.synesper.dialog.DialogUtil;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterPersonalInfoConsentFragment extends RegisterFragment{
    public static final String TAG ="RegisterPersonalInfoConsentFragment";
    private FragmentRegisterPersonalinfoconsentBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mFragmentPage = 0;
        binding = FragmentRegisterPersonalinfoconsentBinding.inflate(inflater,container,false);
        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Activity acty = getActivity();

        GetPersonalInfoConsent.getPersonalInfoConsent(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if(response.isSuccessful()){
                    String text = response.body();
                    binding.tvText.setText(text);
                }else{
                    DialogUtil.showDialogMessage(acty, "서버 접속 오류","다시 실행해주세요.", null);
                    binding.checkBox.setEnabled(false);
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                DialogUtil.showDialogMessage(acty, "서버 접속 오류","다시 실행해주세요.", null);
                binding.checkBox.setEnabled(false);
            }
        });
        binding.checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    binding.buttonNext.setEnabled(true);
                }else{
                    binding.buttonNext.setEnabled(false);
                }
            }
        });

        binding.buttonNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                frgmentListener_onFragmentNext();
            }
        });
    }
}
