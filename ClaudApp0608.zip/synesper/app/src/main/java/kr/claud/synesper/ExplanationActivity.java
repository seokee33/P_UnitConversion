package kr.claud.synesper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import kr.claud.synesper.common.OnSwipeTouchListener;


public class ExplanationActivity extends AppCompatActivity {

    private ImageView mivGraphic = null;
    private ImageView mivText = null;
    private ImageView mivPage = null;

    private enum ExplanationPage {
        PAGE1(R.drawable.signup_3_graphic1, R.drawable.signup_3_text1, R.drawable.signup_3_page_icon1),
        PAGE2(R.drawable.signup_3_graphic2, R.drawable.signup_3_text2, R.drawable.signup_3_page_icon2),
        PAGE3(R.drawable.signup_3_graphic3, R.drawable.signup_3_text3, R.drawable.signup_3_page_icon3),
        PAGE4(R.drawable.signup_3_graphic4, R.drawable.signup_3_text4, R.drawable.signup_3_page_icon4);

        private int ridGraphic;
        private int ridText;
        private int ridPage;

        ExplanationPage(int ridGraphic, int ridText, int ridPage) {
            this.ridGraphic = ridGraphic;
            this.ridText = ridText;
            this.ridPage = ridPage;
        }

        public int getGraphic() { return ridGraphic; }
        public int getText() { return ridText; }
        public int getPage() { return ridPage; }


        public ExplanationPage prev() {
            if (this == ExplanationPage.PAGE2)
                return ExplanationPage.PAGE1;
            else if (this == ExplanationPage.PAGE3)
                return ExplanationPage.PAGE2;
            else if (this == ExplanationPage.PAGE4)
                return ExplanationPage.PAGE3;
            return this;
        }

        public ExplanationPage next() {
            if (this == ExplanationPage.PAGE1)
                return ExplanationPage.PAGE2;
            else  if (this == ExplanationPage.PAGE2)
                return ExplanationPage.PAGE3;
            else if (this == ExplanationPage.PAGE3)
                return ExplanationPage.PAGE4;
            return this;
        }
    }

    private ExplanationPage mCurPage = ExplanationPage.PAGE1;


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explanation);

        ((FrameLayout) findViewById(R.id.frameLayoutExplanation)).setOnTouchListener(new OnSwipeTouchListener(ExplanationActivity.this) {
            public void onSwipeTop() {
                //Toast.makeText(ExplanationActivity.this, "top", Toast.LENGTH_SHORT).show();
            }
            public void onSwipeRight() {
                //Toast.makeText(ExplanationActivity.this, "right", Toast.LENGTH_SHORT).show();
                setPagePrev();
            }
            public void onSwipeLeft() {
                //Toast.makeText(ExplanationActivity.this, "left", Toast.LENGTH_SHORT).show();

                if (mCurPage == ExplanationPage.PAGE4) {
                    startMainActivity();
                } else {
                    setPageNext();
                }
            }
            public void onSwipeBottom() {
                //Toast.makeText(ExplanationActivity.this, "bottom", Toast.LENGTH_SHORT).show();
            }
        });

        //TODO: 자동으로 설명 화면 넘기기
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
            }
        }, 3000);


        ImageButton ib = (ImageButton) findViewById(R.id.imageButtonSkip);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startMainActivity();
            }
        });

        mivGraphic = (ImageView) findViewById(R.id.imageViewGraphic);
        mivText = (ImageView) findViewById(R.id.imageViewText);
        mivPage = (ImageView) findViewById(R.id.imageViewPage);
    }

    private void startMainActivity() {
        Intent intent = new Intent(ExplanationActivity.this, MainActivity.class);
        startActivity(intent);

        finish();
    }

    private void setPagePrev() {
        mCurPage = mCurPage.prev();

        mivGraphic.setImageResource(mCurPage.getGraphic());
        mivText.setImageResource(mCurPage.getText());
        mivPage.setImageResource(mCurPage.getPage());
    }

    private void setPageNext() {
        mCurPage = mCurPage.next();

        mivGraphic.setImageResource(mCurPage.getGraphic());
        mivText.setImageResource(mCurPage.getText());
        mivPage.setImageResource(mCurPage.getPage());
    }
}