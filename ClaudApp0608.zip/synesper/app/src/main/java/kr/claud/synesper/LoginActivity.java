package kr.claud.synesper;

import static kr.claud.libs.api.OkHttpClientProvider.cookieJar;
import static kr.claud.libs.api.RetrofitBuilderProvider.web;
import static kr.claud.synesper.UserActivity.RESULT_REGISTER_START;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.ms.api.login.Login;
import kr.claud.libs.crypto.AES256Chiper;
import kr.claud.libs.enums.KeySize;
import kr.claud.synesper.data.LoginRepository;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.ui.login.LoggedInUserView;
import kr.claud.synesper.ui.login.LoginFormState;
import kr.claud.synesper.ui.login.LoginResult;
import kr.claud.synesper.ui.login.LoginViewModel;
import kr.claud.synesper.ui.login.LoginViewModelFactory;
import kr.claud.synesper.databinding.ActivityLoginBinding;
import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    public static final String TAG = "LoginActivity";

    private LoginViewModel loginViewModel;
    private LoginRepository loginRepository;
    private ActivityLoginBinding binding;

    View.OnClickListener autoLoginClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            loginRepository.setAutoLogin(!loginRepository.isAutoLogin());
            updateAutoLoginState();
        }
    };
    View.OnClickListener rememberIDClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            loginRepository.setRememberID(!loginRepository.isRememberID());
            updateRememberIdState();
        }
    };
    View.OnClickListener signinClick = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            setResult(RESULT_REGISTER_START);
            finish();
        }
    };
    View.OnClickListener findIDAndPW = new View.OnClickListener() {
        @Override
        public void onClick(View view) {

        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory()).get(LoginViewModel.class);
        loginRepository = loginViewModel.getLoginRepository();

        AppData ad = AppData.I();
        loginRepository.setAutoLogin(ad.mAutoLogin);
        loginRepository.setRememberID(ad.mRememberId);

        binding.imageViewAutoLoginCheck.setOnClickListener(autoLoginClick);
        binding.imageViewAutoLoginText.setOnClickListener(autoLoginClick);
        binding.imageViewRememberIDCheck.setOnClickListener(rememberIDClick);
        binding.imageViewRememberIDText.setOnClickListener(rememberIDClick);
        binding.imageViewFindIDAndPW.setOnClickListener(findIDAndPW);
        binding.imageViewSignin.setOnClickListener(signinClick);

        updateAutoLoginState();
        updateRememberIdState();

        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final Button loginButton = binding.login;
        final ProgressBar loadingProgressBar = binding.loading;

        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    changeEditBoxAlertColor();
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    LoggedInUserView success = loginResult.getSuccess();
                    updateUiWithUser(success);

                    if (loginRepository.isRememberID()) {
                        AppData ad = AppData.I();
                        ad.mPrefUserName = usernameEditText.getText().toString();
                        ad.mPrefPasswd = passwordEditText.getText().toString();
                    }

                    // TEST
                    //ad.setLoginUser(usernameEditText.getText().toString(), passwordEditText.getText().toString());
                    //ad.setLoginUser("synesper1", "111111");
                }

                //Complete and destroy login activity once successful
                setResult(UserActivity.RESULT_LOGIN_OK);
                finish();
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(usernameEditText.getText().toString(), passwordEditText.getText().toString());
            }
        };

        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    login();
                }
                return false;
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                login();
                loadingProgressBar.setVisibility(View.GONE);
            }
        });

        if(ad.mRememberId){
            usernameEditText.setText(ad.mPrefUserName);
        }

        loginViewModel.loginDataChanged(usernameEditText.getText().toString(), passwordEditText.getText().toString());
    }

    @Override
    protected void onStop() {
        super.onStop();

        AppData ad = AppData.I();
        if (ad != null) {
            ad.mAutoLogin = loginRepository.isAutoLogin();
            ad.mRememberId = loginRepository.isRememberID();
        }
        AppData.storePreferences(this);
    }

    /**
     * login()
     * Attempt to log in to the server
     * */
    private void login(){
        AppData ad = AppData.I();
        int stateNetwork = ad.getNetworkInfo(LoginActivity.this);
        if(stateNetwork >=3){
            DialogUtil.showDialogMessage(LoginActivity.this, "인터넷 연결 문제", "데이터 및 와이파이를 확인해주세요", null);
            return;
        }
        String userName = binding.username.getText().toString();
        String passwd = binding.password.getText().toString();
        String passwdAES;
        AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
        try{
            passwdAES = aes.AES_Encode(passwd);
        } catch (UnsupportedEncodingException | NoSuchPaddingException | IllegalBlockSizeException |
                 NoSuchAlgorithmException | BadPaddingException | InvalidKeyException |
                 InvalidAlgorithmParameterException e) {
            throw new RuntimeException(e);
        }
        Login.login(userName, passwd, new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if(response.isSuccessful()){
                    if(response.code() == 200){
                        try {
                            //kim cookie 수정 필요할듯
                            List<Cookie> cookies = new ArrayList<>();
                            List<String> cookieHeaders = response.headers().values("Set-Cookie");
                            for (String cookieHeader : cookieHeaders) {
                                Cookie cookie = Cookie.parse(HttpUrl.parse(web), cookieHeader);
                                cookies.add(cookie);
                            }
                            cookieJar.saveFromResponse(HttpUrl.parse(web), cookies);

                            String jsonString = response.body().string();
                            JSONObject jsonObject = new JSONObject(jsonString);
                            String num = jsonObject.get("accountId").toString();
                            String name = jsonObject.get("name").toString();
                            String email = jsonObject.get("email").toString();
                            String delivery = jsonObject.get("delivery").toString();
                            AppData ad = AppData.I();

                            // Update user information to DB in SQLite
                            ad.mSqliteDB.changeLoginUserUpdate(num,userName,passwdAES,name,delivery,email);

                            // Attempt to login with information from the internal DB ==> Need to be removed later, and modified to login to the server
                            loginViewModel.login(userName,passwdAES);


                            // Remember when auto-login is selected
                            if (loginRepository.isAutoLogin()){
                                ad.mPrefUserName = userName;
                                ad.mPrefPasswd = passwdAES;
                                ad.storePreferences(AppData.getPrefs(getApplicationContext())); //
                            }

                            // Remember when selecting the ID memory button
                            if (loginRepository.isRememberID()) {
                                ad.mPrefUserName = userName;
                                ad.mPrefPasswd = passwdAES;
                                ad.storePreferences(AppData.getPrefs(getApplicationContext()));
                            }

                            if (ad.mPrefDeviceName != null){
                                Login.updateDeviceSerialNumber(ad.mPrefDeviceName, new Callback<ResponseBody>() {
                                    @Override
                                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                        if(response.isSuccessful()){
                                            Log.i("kimmmmmmmm","성공");
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                                        Toast.makeText(getApplication(),"기기등록을 실패했습니다.\n설정에서 기기를 다시 등록해주세요.",Toast.LENGTH_SHORT);
                                    }
                                });
                            }
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        } catch (JSONException e) {
                            throw new RuntimeException(e);
                        }
                    }else{
                        Log.i("kim(LoginAtivity code)","400번");
                        DialogUtil.showDialogMessage(LoginActivity.this, "아이디 및 비밀번호 입력오류","아이디 및 비밀번호를 확인해주세요", null);
                    }
                }else{
                    if(response.code() == 401){
                        Log.i("kim(LoginAtivity code)","400번");
                        DialogUtil.showDialogMessage(LoginActivity.this, "아이디 및 비밀번호 입력오류","아이디 및 비밀번호를 확인해주세요", null);
                    }else{
                        Log.i("kim(LoginAtivity code)",response.code()+"번");
                        DialogUtil.showDialogMessage(LoginActivity.this, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.i("kim(LoginAtivity code)","error - "+call.toString());
                DialogUtil.showDialogMessage(LoginActivity.this, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
            }
        });
    }

    private void updateUiWithUser(LoggedInUserView model) {
        //String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        //Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }

    private void updateAutoLoginState() {
        ImageView autoLoginCheckImageView = binding.imageViewAutoLoginCheck;
        if (loginRepository.isAutoLogin()) {
            autoLoginCheckImageView.setImageResource(R.drawable.login_1_button_1);
        } else {
            autoLoginCheckImageView.setImageResource(R.drawable.login_1);
        }
    }

    private void updateRememberIdState() {
        ImageView rememberIDCheckImageView = binding.imageViewRememberIDCheck;
        if (loginRepository.isRememberID()) {
            rememberIDCheckImageView.setImageResource(R.drawable.login_1_button_1);
        } else {
            rememberIDCheckImageView.setImageResource(R.drawable.login_1);
        }
    }

    private void changeEditBoxAlertColor() {
        EditText usernameEditText = binding.username;
        EditText passwordEditText = binding.password;
        usernameEditText.setBackgroundResource(R.drawable.editbox_border_alert);
        passwordEditText.setBackgroundResource(R.drawable.editbox_border_alert);
    }

    private void changeEditBoxNormalColor() {
        EditText usernameEditText = binding.username;
        EditText passwordEditText = binding.password;
        usernameEditText.setBackgroundResource(R.drawable.editbox_border);
        passwordEditText.setBackgroundResource(R.drawable.editbox_border);
    }

    private void startExplanationActivity() {
        Intent intent = new Intent(LoginActivity.this, ExplanationActivity.class);
        startActivity(intent);

        finish();
    }
}