package kr.claud.synesper.ui.chart;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import kr.claud.synesper.AppData;
import kr.claud.synesper.adapter.HcalDataAdapter;
import kr.claud.synesper.adapter.HcalDataDetailAdapter;


public class ChartViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    public LiveData<String> getText() {
        return mText;
    }

    private static ArrayList<HcalDataAdapter.HcalDataItem> mArrayListHcalData;
    private static ArrayList<HcalDataDetailAdapter.HcalDataDetailItem> mArrayListHcalDataDetail;
    static {
        mArrayListHcalData = new ArrayList<>();
        mArrayListHcalDataDetail = new ArrayList<>();
    }

    private HcalDataAdapter mHcalDataAdapter;
    private HcalDataDetailAdapter mHcalDataDetailAdapter;

    public ChartViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is chart fragment");
    }

    public void createAdapter(Context context) {
        mHcalDataAdapter = new HcalDataAdapter(mArrayListHcalData);
        mHcalDataDetailAdapter = new HcalDataDetailAdapter(context, mArrayListHcalDataDetail);
    }

    //---------------------------------------------------------
    public void setAdapterListener(HcalDataAdapter.OnAdapterListener l) {
        mHcalDataAdapter.setOnAdapterListener(l);
    }

    public ArrayList<HcalDataAdapter.HcalDataItem> getArrayList() {
        return mArrayListHcalData;
    }

    public void clearArrayList() {
        mArrayListHcalData.clear();
        mHcalDataAdapter.notifyDataSetChanged();
    }

    public HcalDataAdapter getAdapter() {
        return mHcalDataAdapter;
    }

    //---------------------------------------------------------
    public void setAdapterDetailListener(HcalDataDetailAdapter.OnAdapterListener l) {
        mHcalDataDetailAdapter.setOnAdapterListener(l);
    }

    public ArrayList<HcalDataDetailAdapter.HcalDataDetailItem> getArrayListDetail() {
        return mArrayListHcalDataDetail;
    }

    public void clearArrayListDetail() {
        mArrayListHcalDataDetail.clear();
        mHcalDataDetailAdapter.notifyDataSetChanged();
    }

    public HcalDataDetailAdapter getAdapterDetail() {
        return mHcalDataDetailAdapter;
    }
}