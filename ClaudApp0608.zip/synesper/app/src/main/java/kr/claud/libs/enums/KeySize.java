package kr.claud.libs.enums;

public enum KeySize {
    KEYSIZE16(16), KEYSIZE24(24), KEYSIZE32(32);

    private int size;

    KeySize(int size) {
        this.size = size;
    }

    public int value() {
        return this.size;
    }
}
