package kr.claud.synesper.dsp;

/*
#define DEFAULT_FILTER
    {
        HPF,  //** Default filter type
        0,    //** Default gain
        100,  //** Default frequency
        8000, //** Default sampling rate
        2,    //** Default bandwidth in octaves
    }

    filter_parameters_t fp = DEFAULT_FILTER;
    fp.srate = SR2FS(voice_config.sampleRate);
    filter.ch_count = voice_config.channels;
    fil_init(&filter, &fp);

  for (uint8_t ch = 0; ch < ctx->ch_count; ch++) {
    for (uint32_t i = 0; i < n_frames; i++) {
      idx = (i * ctx->ch_count) + ch;
      // Convert sample to unsigned data
      sample = (sample_t)((uint16_t)(((int32_t)in[idx]) - SHRT_MIN));
      out[idx] = (int16_t)compute(sample, &ctx->biquad_list[ch]);
    }
  }
 */

//FilterParameters fpHPF = new FilterParameters(FilterType.HPF, 0, 100, 8000, 2);

public class Filter {

    public static final double M_LN2 = 0.69314718055994530942;

    public static final int FILTER_STATUS_OK = 0x0000;
    public static final int FILTER_STATUS_INVALID_PARAMETER = 0x0021;
    public static final int FILTER_STATUS_NULL_POINTER = 0x0022;


    public int init(FilterContext ctx, FilterParameters fpar) {
        Coefficients coef = new Coefficients();

        if ((ctx == null) || (fpar == null) || (ctx.biquad_list == null)) {
            return FILTER_STATUS_NULL_POINTER;
        }

        if (ctx.ch_count == 0) {
            return FILTER_STATUS_INVALID_PARAMETER;
        }

        // Setup input parameters.
        coef.A = Math.pow(10, fpar.db_gain / 40);
        coef.omega = 2 * Math.PI * fpar.freq / fpar.srate;
        coef.sn = Math.sin(coef.omega);
        coef.cs = Math.cos(coef.omega);
        coef.alpha = coef.sn * Math.sinh(M_LN2 / 2 * fpar.bandwidth * coef.omega / coef.sn);
        coef.beta = Math.sqrt(coef.A + coef.A);

        switch (fpar.type) {
            case LPF:   lpfParameters(coef);   break;
            case HPF:   hpfParameters(coef);   break;
            case BPF:   bpfParameters(coef);   break;
            case NOTCH: notchParameters(coef); break;
            case PEQ:   peqParameters(coef);   break;
            case LSH:   lshParameters(coef);   break;
            case HSH:   hshParameters(coef);   break;
            default:
                return FILTER_STATUS_INVALID_PARAMETER;
        }

        for (int ch = 0; ch < ctx.ch_count; ch++) {
            BIQUAD b = ctx.biquad_list[ch];

            // Pre-computed coefficients.
            b.a0 = coef.b0 / coef.a0;
            b.a1 = coef.b1 / coef.a0;
            b.a2 = coef.b2 / coef.a0;
            b.a3 = coef.a1 / coef.a0;
            b.a4 = coef.a2 / coef.a0;

            // Clean samples.
            b.x1 = b.x2 = 0;
            b.y1 = b.y2 = 0;
        }

        return FILTER_STATUS_OK;
    }

    private double compute(double sample, BIQUAD b)
    {
        double result;
        // Compute result.
        result = b.a0 * sample + b.a1 * b.x1 + b.a2 * b.x2 - b.a3 * b.y1 - b.a4 * b.y2;

        // Shift x1 to x2, sample to x1.
        b.x2 = b.x1;
        b.x1 = sample;

        // Shift y1 to y2, result to y1.
        b.y2 = b.y1;
        b.y1 = result;

        return result;
    }

    public short[] filtering(FilterContext ctx, short[] in, int nFrames) {
        short[] out = new short[in.length];
        for (int ch = 0; ch<ctx.ch_count ; ch++) {
            int idx = ch;
            for (int i=0 ; i<nFrames ; i++) {
                double sample = (double)((int)(in[idx]) - (int)(Short.MIN_VALUE));
                out[idx] = (short) compute(sample, ctx.biquad_list[ch]);
                idx += ctx.ch_count;
            }
        }
        return out;
    }

    // -----------------------------------------------------------------------------
    // Private function definitions
    public void lpfParameters(Coefficients c)
    {
        c.b0 = (1 - c.cs) / 2;
        c.b1 = 1 - c.cs;
        c.b2 = (1 - c.cs) / 2;
        c.a0 = 1 + c.alpha;
        c.a1 = -2 * c.cs;
        c.a2 = 1 - c.alpha;
    }

    public void hpfParameters(Coefficients c)
    {
        c.b0 = (1 + c.cs) / 2;
        c.b1 = -(1 + c.cs);
        c.b2 = (1 + c.cs) / 2;
        c.a0 = 1 + c.alpha;
        c.a1 = -2 * c.cs;
        c.a2 = 1 - c.alpha;
    }

    public void bpfParameters(Coefficients c)
    {
        c.b0 = c.alpha;
        c.b1 = 0;
        c.b2 = -c.alpha;
        c.a0 = 1 + c.alpha;
        c.a1 = -2 * c.cs;
        c.a2 = 1 - c.alpha;
    }

    public void notchParameters(Coefficients c)
    {
        c.b0 = 1;
        c.b1 = -2 * c.cs;
        c.b2 = 1;
        c.a0 = 1 + c.alpha;
        c.a1 = -2 * c.cs;
        c.a2 = 1 - c.alpha;
    }

    public void peqParameters(Coefficients c)
    {
        c.b0 = 1 + (c.alpha * c.A);
        c.b1 = -2 * c.cs;
        c.b2 = 1 - (c.alpha * c.A);
        c.a0 = 1 + (c.alpha / c.A);
        c.a1 = -2 * c.cs;
        c.a2 = 1 - (c.alpha / c.A);
    }

    public void lshParameters(Coefficients c)
    {
        c.b0 = c.A * ((c.A + 1) - (c.A - 1) * c.cs + c.beta * c.sn);
        c.b1 = 2 * c.A * ((c.A - 1) - (c.A + 1) * c.cs);
        c.b2 = c.A * ((c.A + 1) - (c.A - 1) * c.cs - c.beta * c.sn);
        c.a0 = (c.A + 1) + (c.A - 1) * c.cs + c.beta * c.sn;
        c.a1 = -2 * ((c.A - 1) + (c.A + 1) * c.cs);
        c.a2 = (c.A + 1) + (c.A - 1) * c.cs - c.beta * c.sn;
    }

    public void hshParameters(Coefficients c)
    {
        c.b0 = c.A * ((c.A + 1) + (c.A - 1) * c.cs + c.beta * c.sn);
        c.b1 = -2 * c.A * ((c.A - 1) + (c.A + 1) * c.cs);
        c.b2 = c.A * ((c.A + 1) + (c.A - 1) * c.cs - c.beta * c.sn);
        c.a0 = (c.A + 1) - (c.A - 1) * c.cs + c.beta * c.sn;
        c.a1 = 2 * ((c.A - 1) - (c.A + 1) * c.cs);
        c.a2 = (c.A + 1) - (c.A - 1) * c.cs - c.beta * c.sn;
    }

    //-----------------------------------------------------------
    public enum FilterType {
        LPF,    // Low Pass Filter
        HPF,    // High Pass Filter
        BPF,    // Band Pass Filter
        NOTCH,  // Notch Filter
        PEQ,    // Peaking Band EQ Filter
        LSH,    // Low Shelf Filter
        HSH;    // High Shelf Filter
    }

    private class Coefficients {
        // Input parameters
        private double A;
        private double omega;
        private double sn;
        private double cs;
        private double alpha;
        private double beta;

        // Calculated parameters
        private double a0, a1, a2;
        private double b0, b1, b2;
    }


    public static class FilterContext {
        private int ch_count;
        private BIQUAD[] biquad_list;

        public FilterContext(int chCnt, BIQUAD[] biquads) {
            this.ch_count = chCnt;
            this.biquad_list = biquads;
        }

        public void setChannelCount(int count) {
            this.ch_count = count;
        }
    }

    public static class FilterParameters {
        private FilterType type;       /**< Filter type */
        private double db_gain;        /**< Gain of filter */
        private double freq;           /**< Center frequency */
        private double srate;          /**< Sampling rate */
        private double bandwidth;      /**< Bandwidth in octaves */

        public FilterParameters(FilterType type, double dbGain, double freq, double srate, double bw) {
            this.type = type;
            this.db_gain = dbGain;
            this.freq = freq;
            this.srate = srate;
            this.bandwidth = bw;
        }
    }

    public static class BIQUAD {
        private double a0, a1, a2, a3, a4;
        private double x1, x2, y1, y2;
    }
}