package kr.claud.synesper.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import kr.claud.synesper.R;

public class ProfilePhotoDialog extends Dialog implements View.OnClickListener {

    public static final String RESULT_CAMERA = "Camera";
    public static final String RESULT_GALLERY = "Gallery";

    private Button btnTake;
    private Button btnGallery;
    private ImageButton ibCancel;

    public interface ProfilePhotoDialogListener {
        void onPositiveClicked(String result);
        void onNegativeClicked();
    }
    private ProfilePhotoDialogListener mProfilePhotoDialogListener;
    public void setDialogListener(ProfilePhotoDialogListener l) {
        this.mProfilePhotoDialogListener = l;
    }

    public ProfilePhotoDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    public ProfilePhotoDialog(@NonNull Context context) {
        super(context);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_profile_photo);

        btnTake = (Button) findViewById(R.id.buttonTake);
        btnGallery = (Button) findViewById(R.id.buttonGallery);
        ibCancel = (ImageButton) findViewById(R.id.imageButtonCancel);

        btnTake.setOnClickListener(this);
        btnGallery.setOnClickListener(this);
        ibCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.buttonTake:
                if (mProfilePhotoDialogListener != null) {
                    mProfilePhotoDialogListener.onPositiveClicked(RESULT_CAMERA);
                }
                dismiss();
                break;

            case R.id.buttonGallery:
                if (mProfilePhotoDialogListener != null) {
                    mProfilePhotoDialogListener.onPositiveClicked(RESULT_GALLERY);
                }
                dismiss();
                break;

            case R.id.imageButtonCancel:
                if (mProfilePhotoDialogListener != null) {
                    mProfilePhotoDialogListener.onNegativeClicked();
                }
                dismiss();
                break;
        }
    }
}
