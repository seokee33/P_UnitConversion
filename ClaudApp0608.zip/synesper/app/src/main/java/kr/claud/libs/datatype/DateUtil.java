package kr.claud.libs.datatype;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String TIME_FORMAT = "hh:mm:ss";


    public static boolean isSameDay(Date date1, Date date2) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd");
        return (sdf.format(date1) == sdf.format(date2));
    }

    public static boolean isSameWeek(Date date1, Date date2) {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        int year1 = c.get(Calendar.YEAR);
        int month1 = c.get(Calendar.MONTH);
        int weekOfYear1 = c.get(Calendar.WEEK_OF_YEAR);

        c.setTime(date2);
        int year2 = c.get(Calendar.YEAR);
        int month2 = c.get(Calendar.MONTH);
        int weekOfYear2 = c.get(Calendar.WEEK_OF_YEAR);

        boolean bSame = false;
        if (year1 == year2 && month1 == month2 && weekOfYear1 == weekOfYear2) {
            bSame = true;
        } else if (year1 + 1 == year2 && month1 == Calendar.DECEMBER && weekOfYear1 == weekOfYear2) {
            bSame = true;
        } else if (year2 + 1 == year1 && month2 == Calendar.DECEMBER && weekOfYear1 == weekOfYear2) {
            bSame = true;
        }
        return bSame;
    }

    public static boolean isSameMonth(Date date1, Date date2) {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        int year1 = c.get(Calendar.YEAR);
        int month1 = c.get(Calendar.MONTH);

        c.setTime(date2);
        int year2 = c.get(Calendar.YEAR);
        int month2 = c.get(Calendar.MONTH);

        return (year1 == year2 && month1 == month2);
    }


    public static int yearFromDate(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.YEAR);
    }

    public static int monthFromDate(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.MONTH) + 1;
    }

    public static int dayFromDate(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.DAY_OF_MONTH);
    }

    // 1(SUNDAY), 2, ..., 7(SATURDAY)
    public static int weekdayFromDate(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return c.get(Calendar.DAY_OF_WEEK);
    }

    public static boolean compareDate(Date date1, Date date2) {
        Calendar c = Calendar.getInstance();
        c.setTime(date1);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);

        c.setTime(date2);
        int tYear = c.get(Calendar.YEAR);
        int tMonth = c.get(Calendar.MONTH) + 1;
        int tDay = c.get(Calendar.DAY_OF_MONTH);

        return (year == tYear && month == tMonth && day == tDay);
    }


    public static String stringDateFrom(int year, int month, int day, String fmt) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        if (fmt == null)
            fmt = DATE_FORMAT;
        return new SimpleDateFormat(fmt).format(c.getTime());
    }

    public static String stringFromDate(Date date, String fmt) {
        if (fmt == null)
            fmt = DATE_FORMAT;
        return new SimpleDateFormat(fmt).format(date);
    }

    public static String stringTimeFromDate(Date date, String fmt) {
        if (fmt == null)
            fmt = TIME_FORMAT;
        return new SimpleDateFormat(fmt).format(date);
    }

    public static Date dateFrom(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        return c.getTime();
    }

    public static Date dateFromString(String str, String fmt) {
        if (str == null || str.length() == 0)
            return null;

        if (fmt == null) {
            fmt = DATE_FORMAT;
        }

        SimpleDateFormat formatter = new SimpleDateFormat(fmt);
        try {
            Date date = formatter.parse(str);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }
}
