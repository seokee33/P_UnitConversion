package com.ms.api.personalinfoconsent;

import com.ms.api.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;

public class GetPersonalInfoConsent {
    public static void getPersonalInfoConsent(Callback<String> callback) {
        Call<String> call = RetrofitClient.getPersonalInfoConsentService().getPersonalInfoConsent();
        call.enqueue(callback);
    }
}
