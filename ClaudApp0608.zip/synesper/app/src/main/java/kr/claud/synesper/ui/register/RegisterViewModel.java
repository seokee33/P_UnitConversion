package kr.claud.synesper.ui.register;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import kr.claud.synesper.R;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.device.SynesperAdapter;


public class RegisterViewModel extends ViewModel {
    public static final String TAG = "RegisterViewModel";

    private MutableLiveData<RegisterFormState> registerFormState = new MutableLiveData<>();
    private MutableLiveData<RegisterResult> registerResult = new MutableLiveData<>();

    public LiveData<RegisterFormState> getRegisterFormState() {
        return registerFormState;
    }

    public LiveData<RegisterResult> getRegisterResult() {
        return registerResult;
    }

    public UserData mUserRegister = null;


    public RegisterViewModel() {
        //_initAdapter();
    }

    public RegisterViewModel init(Context ctx) {
        mUserRegister = new UserData(ctx);
        return this;
    }

    //---------------------------------------------------
    private ArrayList<SynesperAdapter.SynesperItem> mArrayList;
    private SynesperAdapter mSynesperAdapter;

    private void _initAdapter() {
        mArrayList = new ArrayList<>();
        mSynesperAdapter = new SynesperAdapter(null, mArrayList);
    }

    public void initSynesperAdapter(RecyclerView recyclerView, SynesperAdapter.OnItemClickListener l, Context ctx) {
        _initAdapter();

        mSynesperAdapter.setOnItemClickListener(l);

        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(ctx);
        recyclerView.setLayoutManager(mLinearLayoutManager);
        recyclerView.setAdapter(mSynesperAdapter);

        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), mLinearLayoutManager.getOrientation());
        //recyclerView.addItemDecoration(dividerItemDecoration);
    }


    public ArrayList<SynesperAdapter.SynesperItem> getArrayList() {
        return mArrayList;
    }

    public void clearArrayList() {
        mArrayList.clear();
        mSynesperAdapter.setConnected(null, false);

        mSynesperAdapter.notifyDataSetChanged();
    }

    public void setConnected(String connected) {
        mSynesperAdapter.setConnected(connected, true);
    }

    public boolean addSynesper(String name, String address, int rssi) {
        return mSynesperAdapter.addSynesper(name, address, rssi);
    }
    //--------------------------------------------------

    public void next(RegisterResult regResult) {
        registerResult.setValue(regResult);
    }

    public void register(UserData userData) {
/*
        // can be launched in a separate asynchronous job
        Result<LoggedInUser> result = loginRepository.login(username, password);

        if (result instanceof Result.Success) {
            LoggedInUser data = ((Result.Success<LoggedInUser>) result).getData();
            registerResult.setValue(new RegisterResult(new LoggedInUserView(data.getDisplayName())));
        } else {
            registerResult.setValue(new RegisterResult(R.string.login_failed));
        }
 */
        registerResult.setValue(new RegisterResult(new RegisteredInUserView(userData.userName())));
    }

    public void registerDataChanged(String username, String password, String passwordConfirm) {
        Integer usernameError = null;
        Integer passwordError = null;
        Integer passwordConfirmError = null;
        boolean bOccur = false;
        if (!isUserNameValid(username)) {
            usernameError = R.string.invalid_username;
            bOccur = true;
        } else if (!isPasswordValid(password)) {
            passwordError = R.string.invalid_password;
            bOccur = true;
        } else if (!isPasswordValid(passwordConfirm)) {
            passwordConfirmError = R.string.invalid_password;
            bOccur = true;
        }

        if (bOccur) {
            registerFormState.setValue(new RegisterFormState(usernameError, passwordError, passwordConfirmError));
        } else {
            registerFormState.setValue(new RegisterFormState(true));
        }
    }


    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }

        return username.matches("^[a-zA-Z0-9]*$");
        //if (username.contains("@")) {
        //    return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        //} else {
        //return !username.trim().isEmpty();
        //}
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 3 && password.trim().length() < 13;
    }
}
