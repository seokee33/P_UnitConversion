package com.ms.api.login;

import org.json.JSONException;
import org.json.JSONObject;

import com.ms.api.RetrofitClient;
import okhttp3.FormBody;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;

public class Login {
    public static void login(String id, String passwd ,Callback<ResponseBody> callback) {
        RequestBody logInRequestBody = new FormBody.Builder()
                .add("userId", id)
                .add("password", passwd)
                .build();

        Call<ResponseBody> call = RetrofitClient.getLoginService().login(logInRequestBody);
        call.enqueue(callback);
    }

    public static void join(String userId, String userEmail, String userName, String password, String delivery, Callback<ResponseBody> callback) throws JSONException {
        JSONObject user = new JSONObject();
        user.put("userId",userId);
        user.put("userEmail",userEmail);
        user.put("userName",userName);
        user.put("password",password);
        user.put("delivery",delivery);

        RequestBody body = RequestBody.create(MediaType.parse("application/json"),user.toString());

        Call<ResponseBody> call = RetrofitClient.getJoinService().join(body);
        call.enqueue(callback);
    }


    public static void checkId(String id, Callback<ResponseBody> callback){
        Call<ResponseBody> call = RetrofitClient.getJoinService().checkId(id);
        call.enqueue(callback);
    }

    public static void account(String password, Callback<ResponseBody> callback) throws JSONException{
        JSONObject data = new JSONObject();
        data.put("password",password);
        RequestBody body = RequestBody.create(MediaType.parse("application/json"), data.toString());

        Call<ResponseBody> call = RetrofitClient.getLoginService().account(body);
        call.enqueue(callback);
    }

    public static void updateDeviceSerialNumber(String serialNum, Callback<ResponseBody> callback) throws JSONException {
        JSONObject data = new JSONObject();
        data.put("deviceSerialNumber",serialNum);
        RequestBody body = RequestBody.create(MediaType.parse("application/json"),data.toString());

        Call<ResponseBody> call = RetrofitClient.getLoginService().updateDeviceSerialNumber(body);
        call.enqueue(callback);
    }
}
