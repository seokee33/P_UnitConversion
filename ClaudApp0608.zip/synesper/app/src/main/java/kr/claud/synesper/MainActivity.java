package kr.claud.synesper;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import kr.claud.libs.framework.fragment.FragmentUtil;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.SynesperSupport;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.databinding.ActivityMainBinding;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.dialog.ProfilePhotoDialog;
import kr.claud.synesper.media.PCMPlayer;
import kr.claud.synesper.media.ProfileImage;
import kr.claud.synesper.ui.chart.ChartFragment;
import kr.claud.synesper.ui.measurement.MeasurementFragment;
import kr.claud.synesper.ui.notice.NoticeFragment;
import kr.claud.synesper.ui.setting.SettingFragment;
import kr.claud.synesper.ui.setting.menu.ProfileFragment;


public class MainActivity extends AppCompatActivity {
    public static final String TAG = "MainActivity";

    private AppData mAppData;
    private SynesperSupport mSynesperSupport;

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;

    private DrawerLayout drawer;
    private NavigationView navigationView;
    private BottomNavigationView bottomNavigationView;

    private NavController navController;

    private Boolean bActionBarShow = false;
    private CharSequence mTitle = "";

    public enum NAVISRC {
        NAVISRC_UNDEF,
        NAVISRC_DRAWER,
        NAVISRC_PROFILE,
        NAVISRC_BOTTOMBAR,
        NAVISRC_FRAGMENT;
    }

    private NAVISRC mNaviSrc = NAVISRC.NAVISRC_UNDEF;


    public enum ProfileViewObject {
        PVO_UNKNOWN,
        PVO_USERNAME,
        PVO_DELIVERY,
        PVO_USERID,
        PVO_EMAIL,
        PVO_DEVICE;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mAppData = AppData.I();
        initSynesperSupport();

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        setSupportActionBar(binding.appBarMain.toolbar);
        //getSupportActionBar().setDisplayUseLogoEnabled(true);

        drawer = binding.drawerLayout;
        navigationView = binding.navView;
        bottomNavigationView = binding.appBarMain.contentMain.bottomNavView;

        //------------------------------------
        //NavigationMenuView navMenuView = (NavigationMenuView) navigationView.getChildAt(0);
        //navMenuView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        // app:itemBackground="@drawable/drawer_item_bg"

        navigationView.setItemIconTintList(null);

        getSupportFragmentManager().registerFragmentLifecycleCallbacks(new FragmentManager.FragmentLifecycleCallbacks() {
            @Override
            public void onFragmentCreated(@NonNull FragmentManager fm, @NonNull Fragment f, @Nullable Bundle savedInstanceState) {
                super.onFragmentCreated(fm, f, savedInstanceState);
                Log.d(TAG, "FragmentLifecycle::onFragmentCreated()");
            }

            @Override
            public void onFragmentStopped(@NonNull FragmentManager fm, @NonNull Fragment f) {
                super.onFragmentStopped(fm, f);

                if (f instanceof MeasurementFragment) {
                    Log.d(TAG, "FragmentLifecycle::onFragmentStopped()");

                    mSynesperSupport.measurementStop();
                }
            }
        }, true);
        //------------------------------------
        initNavigation();
        initListener();
        initView();
        initProfileView();
        initPcmPlayer();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {
        DialogUtil.showFinishApp(this, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
                if (which == DialogInterface.BUTTON_POSITIVE) {
                    finishSynesperApp();
                }
            }
        });

        //super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        closeSynesperSupport();
        Log.d(TAG+"kim", "onDestroy()");

        super.onDestroy();
    }

    @Override
    protected void onResume() {
        Log.d(TAG+"kim", "onResume()");

        super.onResume();

        mSynesperSupport.resume();
    }

    @Override
    protected void onStop() {
        Log.d(TAG+"kim", "onStop()");

        mSynesperSupport.stop();

        super.onStop();
        AppData.storePreferences(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    public void destroyChildFragment(Class cls) {
        if (cls.equals(MeasurementFragment.class)) {
            Log.d(TAG, "destroyChildFragment() - MeasurementFragment");
        } else if (cls.equals(ChartFragment.class)) {
            Log.d(TAG, "destroyChildFragment() - ChartFragment");
            mSynesperSupport.smdFilePlayerStop();
        } else if (cls.equals(NoticeFragment.class)) {
            Log.d(TAG, "destroyChildFragment() - NoticeFragment");
        } else if (cls.equals(SettingFragment.class)) {
            Log.d(TAG, "destroyChildFragment() - SettingFragment");
        }
    }

    private void initNavigation() {
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(R.id.nav_measurement, R.id.nav_chart, R.id.nav_notice, R.id.nav_setting)
                .setOpenableLayout(drawer)
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        //NavigationUI.setupWithNavController(navigationView, navController);

        navController.addOnDestinationChangedListener(new NavController.OnDestinationChangedListener() {
            @Override
            public void onDestinationChanged(@NonNull NavController navController, @NonNull NavDestination navDestination, @Nullable Bundle bundle) {
                int destId = navDestination.getId();
                Log.d(TAG, "onDestinationChanged() id=" + destId);
                switch (destId) {
                    case R.id.nav_measurement:
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.showToolbar(true);
                        }

                        if (mNaviSrc == NAVISRC.NAVISRC_PROFILE)
                            showProfileOverlay(true, View.GONE, 5);
                        break;
                    case R.id.nav_chart:
                    case R.id.nav_notice:
                    case R.id.nav_setting:
                        if (mNaviSrc == NAVISRC.NAVISRC_PROFILE)
                            showProfileOverlay(true, View.GONE, 5);
                        else
                            findViewById(R.id.imageToolProfile).setVisibility(View.VISIBLE);
                        break;
                    //-----------------------------------------
                    case R.id.nav_profile:
                        break;
                    case R.id.nav_account:
                        break;
                    case R.id.nav_device:
                        break;
                    case R.id.nav_pulse:
                        break;
                    case R.id.nav_usage:
                        break;
                    case R.id.nav_contact:
                        break;
                    case R.id.nav_datareset:
                        break;
                }

                if (destId == R.id.nav_measurement) {
                    bActionBarShow = false;
                    if (mNaviSrc != NAVISRC.NAVISRC_PROFILE)
                        getSupportActionBar().hide();
                    else
                        getSupportActionBar().show();
                } else {
                    bActionBarShow = true;
                    getSupportActionBar().show();
                }
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                boolean bRet = NavigateFragment(NAVISRC.NAVISRC_DRAWER, item.getItemId(), true);
                drawer.close();
                return bRet;
            }
        });

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemIdx = -1;
                switch (item.getItemId()) {
                    case R.id.navigation_measurement:
                        itemIdx = R.id.nav_measurement;
                        break;
                    case R.id.navigation_chart:
                        itemIdx = R.id.nav_chart;
                        break;
                    case R.id.navigation_notice:
                        itemIdx = R.id.nav_notice;
                        break;
                    case R.id.navigation_setting:
                        itemIdx = R.id.nav_setting;
                        break;
                }
                if (itemIdx != -1) {
                    NavigateFragment(NAVISRC.NAVISRC_BOTTOMBAR, itemIdx, false);
                }
                return false;
            }
        });

        drawer.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View drawerView, float slideOffset) {
            }

            @Override
            public void onDrawerOpened(@NonNull View drawerView) {
            }

            @Override
            public void onDrawerClosed(@NonNull View drawerView) {
            }

            @Override
            public void onDrawerStateChanged(int newState) {
                if (newState == DrawerLayout.STATE_SETTLING) {
                    // drawer visible: false --> true
                    changeMeasurementGraphState(!drawer.isDrawerVisible(GravityCompat.START));
                }
            }
        });
        //toggle.syncState();

        //drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        //drawer.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    }

    private void initListener() {
        ImageView ivToolProfile = (ImageView) findViewById(R.id.imageToolProfile);
        ivToolProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                if (measFrag == null) {
                    Log.d(TAG, "measurement fragment null");
                }

                showProfileOverlay(true, View.GONE, 0);
            }
        });

        ImageButton ibLogout = (ImageButton) findViewById(R.id.imageButtonLogout);
        ibLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                profileLogout();
            }
        });


        View.OnClickListener profileClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = view.getId();
                Log.d(TAG, "profileClick: id=" + id);
                switch (id) {
                    case R.id.imageViewProfilePhoto:
                    case R.id.profileUser:
                        NavigateFragment(NAVISRC.NAVISRC_PROFILE, R.id.nav_profile, false);
                        break;

                    case R.id.imageViewAccountArrow:
                        NavigateFragment(NAVISRC.NAVISRC_PROFILE, R.id.nav_account, false);
                        break;

                    case R.id.imageViewDeviceArrow:
                        NavigateFragment(NAVISRC.NAVISRC_PROFILE, R.id.nav_device, false);
                        break;
                }
            }
        };
        findViewById(R.id.imageViewProfilePhoto).setOnClickListener(profileClickListener);
        findViewById(R.id.profileUser).setOnClickListener(profileClickListener);
        findViewById(R.id.imageViewAccountArrow).setOnClickListener(profileClickListener);
        findViewById(R.id.imageViewDeviceArrow).setOnClickListener(profileClickListener);

        Button closeButton = (Button) findViewById(R.id.buttonClose);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // kim(수정)
                AppData ad = AppData.I();
                MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                if(measFrag != null){
                    boolean result = ad.changeBLE_RECEIVE_STATE_Profile(measFrag);
                    Log.i("imageToolProfile","click");
                    Log.i("imageToolProfile","결과 : "+result);
                }
                if (bActionBarShow) {
                    getSupportActionBar().setTitle(mTitle);
                    if (!getSupportActionBar().isShowing()) {
                        getSupportActionBar().show();
                    }
                } else {
                    if (getSupportActionBar().isShowing())
                        getSupportActionBar().hide();
                }

                showProfileOverlay(false, View.VISIBLE, 0);
            }
        });
    }

    private void initView() {
        //binding.appBarMain.appBarLayout.setVisibility(View.GONE);

        bActionBarShow = false;
        getSupportActionBar().hide();
        showProfileOverlay(false, View.VISIBLE, 0);
    }

    private void initProfileView() {
        TextView tvUserName = (TextView) findViewById(R.id.textViewUserName);
        TextView tvWeek = (TextView) findViewById(R.id.textViewProfileWeek);
        TextView tvDelivery = (TextView) findViewById(R.id.textViewProfileDate);
        TextView tvUserID = (TextView) findViewById(R.id.textViewUserID);
        TextView tvUserEmail = (TextView) findViewById(R.id.textViewUserEmail);
        TextView tvModelName = (TextView) findViewById(R.id.textViewModelName);
        TextView tvDeviceAddr = (TextView) findViewById(R.id.textViewDeviceAddr);

        tvUserName.setText(mAppData.mUserData.userName());

        int weeks = mAppData.mUserData.userWeek();
        String szWeeks = ((weeks <= 0) ? "-" : weeks) + " " + getString(R.string.signup_n_week);
        tvWeek.setTextColor((weeks >= 40) ? Color.RED : Color.WHITE);
        tvWeek.setText(szWeeks);

        tvDelivery.setText(mAppData.mUserData.userDelivery());
        tvUserID.setText(mAppData.mUserData.userId());
        tvUserEmail.setText(mAppData.mUserData.userEmail());
        tvModelName.setText(mAppData.mPrefDeviceName);
        tvDeviceAddr.setText(mAppData.mPrefDeviceAddr);

        updateProfilePhoto();
    }

    public void updateDeviceInfo(){
        TextView tvModelName = (TextView) findViewById(R.id.textViewModelName);
        TextView tvDeviceAddr = (TextView) findViewById(R.id.textViewDeviceAddr);

        tvModelName.setText(mAppData.mPrefDeviceName);
        tvDeviceAddr.setText(mAppData.mPrefDeviceAddr);
    }

    private void initPcmPlayer() {
        mSynesperSupport.pcmPlayerStart(PCMPlayer.PlayerMode.PLAYER_STREAM);
    }

    private void updateProfileView(@NonNull ProfileViewObject... pvos) {
        for (ProfileViewObject pvo : pvos) {
            switch (pvo) {
                case PVO_USERNAME:
                    TextView tvUserName = (TextView) findViewById(R.id.textViewUserName);
                    tvUserName.setText(mAppData.mUserData.userName());
                    break;

                case PVO_DELIVERY:
                    TextView tvWeek = (TextView) findViewById(R.id.textViewProfileWeek);
                    TextView tvDelivery = (TextView) findViewById(R.id.textViewProfileDate);
                    int weeks = mAppData.mUserData.userWeek(); //kim : 임신주기 수정
                    String szWeeks = ((weeks <= 0) ? "0" : weeks) + " " + getString(R.string.signup_n_week);
                    tvWeek.setTextColor((weeks >= 40) ? Color.RED : Color.WHITE);
                    tvWeek.setText(szWeeks);
                    tvDelivery.setText(mAppData.mUserData.userDelivery());
                    break;

                case PVO_USERID:
                    TextView tvUserID = (TextView) findViewById(R.id.textViewUserID);
                    tvUserID.setText(mAppData.mUserData.userId());
                    break;

                case PVO_EMAIL:
                    TextView tvUserEmail = (TextView) findViewById(R.id.textViewUserEmail);
                    tvUserEmail.setText(mAppData.mUserData.userEmail());
                    break;

                case PVO_DEVICE:
                    TextView tvModelName = (TextView) findViewById(R.id.textViewModelName);
                    TextView tvDeviceAddr = (TextView) findViewById(R.id.textViewDeviceAddr);
                    tvModelName.setText(mAppData.mPrefDeviceName);
                    tvDeviceAddr.setText(mAppData.mPrefDeviceAddr);
                    break;
            }
        }
    }

    public boolean NavigateFragment(NAVISRC naviSrc, int destId, boolean bMove) {
        AppData ad = AppData.I();
        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
        int itemIdx = -1;
        switch (destId) {
            case R.id.nav_measurement:  // R.id.navigation_measuremnt;
                if(ad.BLE_RECEIVE_STATE_Profile){
                    if (measFrag != null) {
                        ad.changeBLE_RECEIVE_STATE_Profile(measFrag);
                    }

                }
                itemIdx = 0;
                break;

            case R.id.nav_chart:  // R.id.navigation_chart;
                itemIdx = 1;
                break;

            case R.id.nav_notice:  // R.id.navigation_notice;
                itemIdx = 2;
                break;

            case R.id.nav_setting:  //  R.id.navigation_setting;
                itemIdx = 3;
                break;

            //-----------------------------------------
            case R.id.nav_profile:
                itemIdx = 4;
                break;
            case R.id.nav_account:
                itemIdx = 5;
                break;
            case R.id.nav_device:
                itemIdx = 6;
                break;
            case R.id.nav_pulse:
                itemIdx = 7;
                break;
            case R.id.nav_usage:
                itemIdx = 8;
                break;
            case R.id.nav_contact:
                itemIdx = 9;
                break;
            case R.id.nav_datareset:
                //itemIdx = 10;
                settingDataReset();
                break;
        }

        if (itemIdx != -1) {
            if (itemIdx < 4) {
                MenuItem bnItem = bottomNavigationView.getMenu().getItem(itemIdx);
                bnItem.setChecked(true);
            } else if (bMove) {
                navController.navigate(navigationView.getMenu().getItem(3).getItemId());
                MenuItem bnItem = bottomNavigationView.getMenu().getItem(3);
                bnItem.setChecked(true);
            }

            Log.d(TAG, "NavigateFragment(): dest=" + destId + ", naviSrc=" + naviSrc);
            mNaviSrc = naviSrc;
            showProfileOverlay(false, (itemIdx < 4) ? View.VISIBLE : View.GONE);
            if (measFrag != null) {
                measFrag.showToolbar(false);
            }
            navController.navigate(destId);
            //showProfileOverlay(false, (itemIdx < 4) ? View.VISIBLE : View.GONE, 0);
            return true;
        }
        return false;
    }

    public void clickDrawerMenuByMeasurementFragment() {
        drawer.open();
    }

    public void clickProfileToolByMeasurementFragment() {
        getSupportActionBar().show();
        showProfileOverlay(true, View.GONE, 0);
    }

    public void clickUsageByMeasurementFragment(boolean bMove) {
        NavigateFragment(NAVISRC.NAVISRC_FRAGMENT, R.id.nav_usage, bMove);
    }

    public void clickVolumeByMeasurementFragment() {
        mAppData.setVolume(!mAppData.mPrefVolumeOn);

        if (mAppData.mPrefVolumeOn) {
            mSynesperSupport.pcmPlayerStart(PCMPlayer.PlayerMode.PLAYER_STREAM);
        } else {
            mSynesperSupport.pcmPlayerStop(PCMPlayer.PlayerMode.PLAYER_STREAM);
        }
    }


    public void clickMeasureByMeasurementFragment() {
        mSynesperSupport.measurementStartOrStop();
    }

    public void clickSaveByMeasurementFragment() {
        mSynesperSupport.measurementSave();
    }

    //kim -> 재생버튼 클릭시
    public void clickPlaySoundByChartFragment(String filePath, boolean bPlay, int pos) {
        //Log.d(TAG, "clickPlaySoundByChartFragment - " + bPlay);

        if (bPlay) {
            mSynesperSupport.smdFilePlayerStart(filePath, pos);
            Log.i("kim_play","mSynesperSupport.smdFilePlayerStart(filePath, pos);");
        } else {
            mSynesperSupport.smdFilePlayerStop();
            Log.i("kim_play","mSynesperSupport.smdFilePlayerStop();");
        }
    }
    public void clickBleDeviceByDeviceFragment(String address) {
        mSynesperSupport.bleDisconnectDevice();
        mSynesperSupport.bleConnectDevice(address);

        //{{ 20230224
        navController.popBackStack();
        //}} 20230224
    }


    ActivityResultLauncher<Intent> cameraActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                    if (data != null && result.getResultCode() == RESULT_OK) {
                        Bitmap bitmap = ProfileImage.bitmapFromCamera(data);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateProfileFragmentPhoto(bitmap);
                            }
                        });
                    } else if (result.getResultCode() == RESULT_CANCELED) {

                    }
                }
            });

    ActivityResultLauncher<Intent> galleryActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                    if (data != null && result.getResultCode() == RESULT_OK) {
                        Bitmap bitmap = ProfileImage.isBitmapCropped(data) ?
                                ProfileImage.cropBitmapFromGallery(data) :
                                ProfileImage.bitmapFromGallery(data, MainActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateProfileFragmentPhoto(bitmap);
                            }
                        });
                    } else if (result.getResultCode() == RESULT_CANCELED) {
                        Toast.makeText(MainActivity.this, "사진 선택 취소", Toast.LENGTH_LONG).show();
                    }
                }
            });

    public void clickProfilePhotoByProfileFragment(String result) {
        switch (result) {
            case ProfilePhotoDialog.RESULT_CAMERA:
                Intent imageTakeIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                //-----------------------------
                imageTakeIntent.putExtra("crop", "true");
                imageTakeIntent.putExtra("outputX", 200);
                imageTakeIntent.putExtra("outputY", 200);
                imageTakeIntent.putExtra("aspectX", 1);
                imageTakeIntent.putExtra("aspectY", 1);
                imageTakeIntent.putExtra("scale", true);
                imageTakeIntent.putExtra("return-data", true);
                //imageTakeIntent.putExtra(MediaStore.EXTRA_OUTPUT, uriWhereToStore);
                //imageTakeIntent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
                //-----------------------------
                if (imageTakeIntent.resolveActivity(getPackageManager()) != null) {
                    cameraActivityResultLauncher.launch(imageTakeIntent);
                }
                break;

            case ProfilePhotoDialog.RESULT_GALLERY:
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                //-----------------------------
                i.setType("image/*");
                i.putExtra("crop", "true");
                i.putExtra("outputX", 200);
                i.putExtra("outputY", 200);
                i.putExtra("aspectX", 1);
                i.putExtra("aspectY", 1);
                i.putExtra("scale", true);
                //i.putExtra("noFaceDetection", true);
                i.putExtra("return-data", true);
                //i.putExtra(MediaStore.EXTRA_OUTPUT, uriWhereToStore);
                //i.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
                //-----------------------------
                galleryActivityResultLauncher.launch(i);
                break;
        }
    }

    public void clickApplyByProfileFragment(String userName, Date date) {
        AppData ad = AppData.I();
        UserData ud = ad.mUserData;
        ud.mProfileImage.saveToJpeg(ud.userId());
        updateProfilePhoto();

        boolean bUpdate = false;
        ProfileViewObject pvoUsername = ProfileViewObject.PVO_UNKNOWN;
        ProfileViewObject pvoDelivery = ProfileViewObject.PVO_UNKNOWN;
        DBHelper.UserItem ui = ud.mUser;
        if (userName != null && userName.length() > 0) {
            ui.name = userName;
            pvoUsername = ProfileViewObject.PVO_USERNAME;
            bUpdate = true;
        }
        if (date != null) {
            String szDelivery = DBHelper.stringFromDate(date);
            ui.delivery = szDelivery;
            pvoDelivery = ProfileViewObject.PVO_DELIVERY;
            bUpdate = true;
        }

        if (bUpdate) {
            ad.updateUser(ui);
            updateProfileView(pvoUsername, pvoDelivery);
        }
    }

    public void clickApplyByAccountFragment(String userName, String passwd, String email) {
        AppData ad = AppData.I();
        UserData ud = ad.mUserData;
        DBHelper.UserItem ui = ud.mUser;
        boolean bUpdate = false;
        ProfileViewObject pvoEmail = ProfileViewObject.PVO_UNKNOWN;
        if (userName != null && userName.length() > 0) {
            ui.id = userName;
            bUpdate = true;
        }
        if (passwd != null && passwd.length() > 0) {
            ui.passwd = passwd;
            bUpdate = true;
        }
        if (email != null && email.length() > 0) {
            ui.email = email;
            pvoEmail = ProfileViewObject.PVO_EMAIL;
            bUpdate = true;
        }

        if (bUpdate) {
            ad.updateUser(ui);
            updateProfileView(pvoEmail);
        }
    }

    public void updateProfileFragmentPhoto(Bitmap bitmap) {
        ProfileFragment pfilFrag = (ProfileFragment) getFragment(ProfileFragment.class);
        if (pfilFrag != null) {
            pfilFrag.updateProfilePhoto(bitmap);
        }
    }

    public void updateProfilePhoto() {
        ProfileImage pi = AppData.I().mUserData.mProfileImage;
        ImageView ivTool = (ImageView) findViewById(R.id.imageToolProfile);
        ImageView ivPhoto = (ImageView) findViewById(R.id.imageViewProfilePhoto);
        Bitmap bm = pi.getImage();
        if (bm != null) {
            ivTool.setImageBitmap(bm);
            ivPhoto.setImageBitmap(bm);
        } else {
            ivTool.setImageResource(R.drawable.profile_app_bar_icon1);
            ivPhoto.setImageResource(R.drawable.profile_app_bar_icon1);
        }
/*
        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
        if (measFrag != null) {
            measFrag.updateProfilePhoto(pi.getImage());
        }
        ProfileFragment pfilFrag = (ProfileFragment) getFragment(ProfileFragment.class);
        if (pfilFrag != null) {
            pfilFrag.updateProfilePhoto(pi.getImage());
        }
 */
    }

    private void showProfileOverlay(boolean bShow, int profileToolVisibility) {
        ConstraintLayout profileAppBarLayout = (ConstraintLayout) findViewById(R.id.profileAppBarLayout);
        ConstraintLayout profileContentLayout = (ConstraintLayout) findViewById(R.id.profileContentLayout);
        ImageView ivToolProfile = (ImageView) findViewById(R.id.imageToolProfile);

        Log.d(TAG, "showProfileOverlay() - " + bShow + ", profileToolVisibility=" + profileToolVisibility);

        if (bShow) {
            profileAppBarLayout.setVisibility(View.VISIBLE);
            profileContentLayout.setVisibility(View.VISIBLE);

            ivToolProfile.setVisibility(profileToolVisibility);

            mTitle = getSupportActionBar().getTitle();
            getSupportActionBar().setTitle(R.string.menu_profile);
            //getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_24);

            findViewById(R.id.content_main).setVisibility(View.GONE);
        } else {
            ivToolProfile.setVisibility(profileToolVisibility);

            profileAppBarLayout.setVisibility(View.GONE);
            profileContentLayout.setVisibility(View.GONE);

            findViewById(R.id.content_main).setVisibility(View.VISIBLE);
        }
    }

    public void showProfileOverlay(boolean bShow, int profileToolVisibility, long delayMillis) {
        changeMeasurementGraphState(bShow);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                showProfileOverlay(bShow, profileToolVisibility);
            }
        }, delayMillis);
    }

    public void toggleProfileOverlay() {
        ConstraintLayout profileAppBarLayout = (ConstraintLayout) findViewById(R.id.profileAppBarLayout);
        if (profileAppBarLayout.getVisibility() == View.VISIBLE) {
            showProfileOverlay(false, View.VISIBLE, 0);
        } else {
            showProfileOverlay(true, View.GONE, 0);
        }
    }

    public void profileLogout() {
        DialogUtil.showProfileLogout(this, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
    }

    public void settingDataReset() {
        DialogUtil.showDataReset(this, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int which) {
            }
        });
    }

    public void changeMeasurementGraphState(boolean bGone) {
        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
        if (measFrag != null) {
            measFrag.changeGraphState(!bGone);
        }
    }

    //---------------------------------------------------
    private void initSynesperSupport() {
        mSynesperSupport = new SynesperSupport(this) {
            @Override
            protected void onBleServiceConnected() {

            }

            //            @Override
//            protected void onBleTimerExpire() {
//                //Log.d(TAG, "onBleTimerExpire() .................");
//                int state = mSynesperSupport.bleGetGattState();
//                if (state == SynesperSupport.BLE_DISCONNECTED) {
//                    AppData ad = AppData.I();
//                    mSynesperSupport.bleConnectDevice(ad.mPrefDeviceAddr);
//                }
//            }
            // kim (수정) : ble
            @Override
            protected void onBleTimerExpire() {
                Log.d(TAG, "onBleTimerExpire() .................");
                int state = mSynesperSupport.bleGetGattState();
                Log.d("onBleTimerExpire1", String.valueOf(state));
                AppData ad = AppData.I();
                if (ad.mPrefDeviceAddr != null) {
                    mSynesperSupport.bleConnectDevice(ad.mPrefDeviceAddr);
                }
                state = mSynesperSupport.bleGetGattState();
                Log.d("onBleTimerExpire2", String.valueOf(state));

                if (state == SynesperSupport.BLE_DISCONNECTED) {
                    mSynesperSupport.bleConnectDevice(ad.mPrefDeviceAddr);
                }
            }

            @Override
            protected void onBleDeviceConnected() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.updateBleState(true);
                        }
                    }
                });
            }

            @Override
            protected void onBleDeviceDisconnected() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.updateBleState(false);
                        }
                    }
                });
            }

            // kim(수정) 멈추기 step1
            @Override
            protected boolean onReceiverPcg(short[] pcgData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            if (!drawer.isDrawerVisible(GravityCompat.START)) {
                                short[] subsampleVoice = pcgSubsampling(pcgData);
                                measFrag.updateGraph(subsampleVoice);
                            } else {
                            }
                            measFrag.updateMeasuringUi(getPCGBpm(), -1);
                        }
                    }
                });
                return true;
            }

            @Override
            protected boolean onReceiverPpg(short[] ppgData, short ppgMin, short ppgMax) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            if (!drawer.isDrawerVisible(GravityCompat.START)) {
                                //-------------------------------------------
                                // TODO: ?????
                                if (ppgMin < -450 || ppgMax > 450) {
                                    for (int i = 0; i < ppgData.length; i++) {
                                        ppgData[i] = 0;
                                    }
                                }
                                //-------------------------------------------
                                measFrag.updatePPGGraph(ppgData, ppgMin, ppgMax);
                            } else {
                            }
                            measFrag.updatePPGUi(getPPGBpm(), getPPGMin(), getPPGMax());
                        }
                    }
                });
                return true;
            }

            @Override
            protected void onMeasurementStateChanged(boolean bMeasurement) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.MeasurementManager_StateChanged(bMeasurement);
                        }
                    }
                });
            }

            @Override
            protected void onMeasurementTimeLapse(int timeLapse) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.MeasurementManager_TimeLapse(timeLapse);
                        }
                    }
                });
            }

            @Override
            protected void onMeasurementBeatDetected(int type) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MeasurementFragment measFrag = (MeasurementFragment) getFragment(MeasurementFragment.class);
                        if (measFrag != null) {
                            measFrag.MeasurementManager_BeatDetected(type);
                        }
                    }
                });
            }

            @Override
            protected void onSmdFilePlayerChanged(int state, int par) {
                ChartFragment chartFrag = (ChartFragment) getFragment(ChartFragment.class);
                switch (state) {
                    case SynesperSupport.SMDFILEPLAYER_PLAY:
                        if (chartFrag != null) {
                            chartFrag.SmdFilePlayer_Play();
                        }
                        break;

                    case SynesperSupport.SMDFILEPLAYER_READ:
                        break;

                    case SynesperSupport.SMDFILEPLAYER_STOP:
                        if (chartFrag != null) {
                            chartFrag.SmdFilePlayer_Stop(par);
                        }
                        break;

                    case SynesperSupport.SMDFILEPLAYER_DONE:
                        break;
                }
            }

            @Override
            protected void onError(int errCode) {
                if (errCode == SynesperSupport.ERROR_BLUETOOTH_UNAVAILABLE) {
                    closeSynesperSupport();
                    finish();
                }
            }
        };

        mSynesperSupport.init(this);
    }

    private void closeSynesperSupport() {
        mSynesperSupport.destroy();
    }

    //---------------------------------------------------
    private Fragment getFragment(Class cls) {
        return FragmentUtil.getChildFragment(getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main), cls);
    }

    private void finishSynesperApp() {
        final int buildTarget = BuildConfig.BUILD_TARGET;
        //AppData.storePreferences(this);

        //ActivityCompat.finishAffinity(this);
        //System.runFinalization();
        //System.exit(0);

        finish();
    }
}