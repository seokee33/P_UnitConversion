package ky.labsource.common;

import android.graphics.Canvas;
import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

public class ViewLayerManager extends ViewLayer implements ViewLayerIface.OnLayerInvalidListener, ViewLayerIface.OnLayerDrawListener {

    // layer
    private List<ViewLayer> mLayers = new ArrayList<>();

    //--- Constructor ---------------------------------
    public ViewLayerManager() {
        setOnLayerDrawListener(this);
    }


    @Override
    public void onInvalidate(ViewLayer layer, boolean bInvalid) {
        if (bInvalid) {
            _bInvalid = true;
            _bRedraw = true;
        }
    }

    @Override
    public boolean onDraw(ViewLayer layer, Canvas canvas) {
        doDraw(canvas);
        return false;
    }


    @Override
    public boolean createObjects() {
        boolean bRet = true;
        for (ViewLayerIface.IResources r : mLayers) {
            if (!r.createObjects())
                bRet = false;
        }
        return bRet;
    }

    @Override
    public void destroyObjects() {
        for (ViewLayerIface.IResources r : mLayers) {
            r.destroyObjects();
        }
    }

    //---------------------------------------------------
    public boolean create(RectF r) {
        return super.create(r, true, UNDEF_ID);
    }

    public boolean create(RectF r, int id) {
        return super.create(r, true, id);
    }

    public boolean addLayer(ViewLayer layer) {
        layer.setOnLayerInvalidListener(this);
        return mLayers.add(layer);
    }

    public void removeLayerAll() {
        mLayers.clear();
    }

    private void doDraw(Canvas canvas) {
        for (ViewLayer layer : mLayers) {
            if (layer.isEnabled()) {
                layer.drawTo(this);
            }
        }
    }
}
