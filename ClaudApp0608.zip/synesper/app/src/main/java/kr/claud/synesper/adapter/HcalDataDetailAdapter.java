package kr.claud.synesper.adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.UserData;
import ky.labsource.widget.ProgressCircle;
import ky.labsource.widget.ProgressRangeCircle;

public class HcalDataDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final String TAG = "HcalDataDetailAdapter";

    public static final String DATE_FMT = "yyyy.MM.dd";

    private static final int VIEWTYPE_EMPTY = 0;
    private static final int VIEWTYPE_DETAIL = 1;

    private Context mContext;
    private Date mDate;
    private ArrayList<HcalDataDetailItem> mList;

    public interface OnAdapterListener {
        void onItemClick(View v, HcalDataDetailItem item, int pos);
        void onItemChanged(HcalDataDetailAdapter adapter, int firstPos, int lastPos);
        void onDelete(HcalDataDetailAdapter adapter, int pos);
        void onPlaySound(HcalDataDetailAdapter adapter, int pos, View view);
    }
    private OnAdapterListener mOnAdapterListener = null;
    public void setOnAdapterListener(OnAdapterListener l) {
        mOnAdapterListener = l;
    }


    public HcalDataDetailAdapter(Context context, ArrayList<HcalDataDetailItem> list) {
        this.mContext = context;

        this.mDate = null;
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        if (viewType == VIEWTYPE_DETAIL) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_data_detail_item, parent, false);
            viewHolder = new HcalDataDetailViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_data_detail_item_empty, parent, false);
            viewHolder = new HcalDataEmptyViewHolder(view);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HcalDataDetailViewHolder) {
            populateHcalDataDetail((HcalDataDetailViewHolder) holder, position);
        } else if (holder instanceof  HcalDataEmptyViewHolder) {
            HcalDataEmptyViewHolder emptyViewHolder = (HcalDataEmptyViewHolder) holder;
            if (this.mDate != null) {
                emptyViewHolder.tvDate.setText(DateUtil.stringFromDate(this.mDate, mContext.getString(R.string.chart_datefmt_for_no_data)));
            } else {
                emptyViewHolder.tvDate.setText("---");
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mList == null || mList.size() == 0)
            return VIEWTYPE_EMPTY;
        return VIEWTYPE_DETAIL;
        //return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        if (mList == null || mList.size() == 0)
            return 1;
        return mList.size();
        //return (null != mList ? mList.size() : 0);
    }

    public HcalDataDetailItem getItem(int index) {
        if (index >= 0 && index < mList.size()) {
            return mList.get(index);
        }
        return null;
    }

    public void updateImage(HcalDataDetailViewHolder holder) {
        holder.ivPlayBaby.setImageResource(R.drawable.ic_baseline_headphones_play);
    }

    public boolean addHcalDataDetail(HcalDataDetailItem item, boolean bNotify) {
        boolean bRet = mList.add(item);
        if (bNotify) {
            notifyDataSetChanged();
        }
        return bRet;
    }

    public boolean addHcalDataDetail(String date, String time, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String filePath, boolean bNotify) {
        HcalDataDetailItem item = new HcalDataDetailItem(date, time, bMin, bMax, bAvg, mMin, mMax, mAvg);
        item.setFileName(filePath);
        return addHcalDataDetail(item, bNotify);
    }

    public boolean removeHcalDataDetail(int pos) {
        HcalDataDetailItem item = mList.remove(pos);
        notifyItemRemoved(pos);
        return true;
    }

    public void setDate(Date date) {
        this.mDate = date;
    }

    //------------------------------------------------------------------------
    // scroll listener
    public RecyclerView.OnScrollListener mOnScrollListener = new RecyclerView.OnScrollListener() {
        private int scrollState = RecyclerView.SCROLL_STATE_IDLE;

        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            scrollState = newState;
        }

        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
        }
    };

    //------------------------------------------------------------------------
    public static class HcalDataDetailItem {
        //private String tag;
        private String date;
        private String time;
        private int babyMin;
        private int babyMax;
        private int babyAvg;
        private int momMin;
        private int momMax;
        private int momAvg;

        private String filePath;
        private String fileName;

        public HcalDataDetailItem(String date, String time, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg) {
            //this.tag = tag;
            this.date = date;
            this.time = time;
            this.babyMin = bMin;
            this.babyMax = bMax;
            this.babyAvg = bAvg;
            this.momMin = mMin;
            this.momMax = mMax;
            this.momAvg = mAvg;

            this.filePath = null;
            this.fileName = null;
        }

        public void setFileName(String filePath) {
            this.filePath = filePath;
            File f = new File(filePath);
            this.fileName = f.getName();
        }

        public String getFilePath() {
            return this.filePath;
        }

        public String getFileName() {
            return this.fileName;
        }

        public String dateToString() {
            return this.date + " " + this.time;
        }

        public Date getDate() {
            String fmt = HcalDataDetailAdapter.DATE_FMT + " " + DBHelper.DB_TIME_FORMAT;
            return DBHelper.dateFromString2(this.date, this.time, fmt);
        }
    }


    //----------------------------------------------------
    public class HcalDataEmptyViewHolder extends RecyclerView.ViewHolder {

        protected TextView tvDate;

        public HcalDataEmptyViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvDate = (TextView) itemView.findViewById(R.id.textViewDate);
        }
    }


    public class HcalDataDetailViewHolder extends RecyclerView.ViewHolder {

        protected TextView tvTag;
        protected TextView tvDate;
        protected TextView tvTime;
        protected TextView tvWeek;
        //protected ProgressCircle pcBaby;
        protected ProgressRangeCircle pcMom;
        protected ImageView ivPlayBaby;

        public HcalDataDetailViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvTag = (TextView) itemView.findViewById(R.id.textViewPage);
            this.tvDate = (TextView) itemView.findViewById(R.id.textViewPageTitle);
            this.tvTime = (TextView) itemView.findViewById(R.id.textViewTime);
            this.tvWeek = (TextView) itemView.findViewById(R.id.textViewWeek);

            //this.pcBaby = (ProgressCircle) itemView.findViewById(R.id.progressCircleBaby);
            this.pcMom = (ProgressRangeCircle) itemView.findViewById(R.id.progressCircleMom);
            this.ivPlayBaby = (ImageView) itemView.findViewById(R.id.imageViewPlayBaby);
            this.ivPlayBaby.setImageResource(R.drawable.ic_baseline_headphones_play);
            //kim -> 재생
            //kim (체크) -> pos는 왜 필요한건지.....
            this.ivPlayBaby.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            mOnAdapterListener.onPlaySound(HcalDataDetailAdapter.this, pos, view);
                        }
                    }
                }
            });

            ImageButton ibDelete = (ImageButton) itemView.findViewById(R.id.imageButtonDelete);
            ibDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            mOnAdapterListener.onDelete(HcalDataDetailAdapter.this, pos);
                        }
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            //mOnAdapterListener.onItemClick(view, mList.get(pos), pos);
                        }
                    }
                }
            });
        }
    }

    private void populateHcalDataDetail(HcalDataDetailViewHolder holder, int position) {
        HcalDataDetailItem item = mList.get(position);
        holder.tvTag.setText(String.format("No.%3d", position+1));
        holder.tvDate.setText(item.date);
        holder.tvTime.setText(item.time);
        holder.ivPlayBaby.setImageResource(R.drawable.ic_baseline_headphones_play);
        String filePath = item.getFilePath();
        if (filePath == null) {
            //holder.ivPlayBaby.setColorFilter(Color.LTGRAY);
        }

        Date date = DBHelper.dateFromString(item.date, DATE_FMT);
        String szWeek = "---";
        if (date != null) {
            UserData ud = AppData.I().mUserData;
            int nWeek = UserData.weeksPregnantFromDelivery(date, ud.userDelivery());
            if (nWeek > 0 && nWeek <= 40)
                szWeek = "" + nWeek;
        }
        holder.tvWeek.setText(szWeek);
        //updateProgressCircle(holder.pcBaby, MeasurementDecision.BAD);
        updateProgressRangeCircle(holder.pcMom, item.momMin, item.momMax, item.momAvg, MeasurementDecision.VERY_GOOD);
    }

    private void updateProgressCircle(ProgressCircle pc, MeasurementDecision measDecision) {
        //float fMin = min / 250.f;
        //float fMax = max / 250.f;

        pc.setEnable(true);
        pc.setProgressRate(0.0f, measDecision.getProgress());
        pc.setProgressColor(ContextCompat.getColor(mContext, measDecision.getColor()));
        //pc.setRange(fMin, fMax);
        pc.sweepProgress();
    }

    private void updateProgressRangeCircle(ProgressRangeCircle pc, float low, float high, float avg, MeasurementDecision measDecision) {
        //float fMin = min / 250.f;
        //float fMax = max / 250.f;

        pc.setMinMax(0.f, 250.f);
        pc.setRange(low, high);
        pc.setText("" + (int)avg);

        pc.setEnable(true);
        //pc.setProgressRate(0.1f, 0.05f);
        pc.setActiveColor(ContextCompat.getColor(mContext, measDecision.getColor()));
        //pc.setRange(fMin, fMax);
        pc.sweepProgress();
    }

    public enum MeasurementDecision {
        VERY_BAD (0.25f, R.color.measure_bad,  "Very Bad"),
        BAD      (0.5f,  R.color.measure_bad,  "Bad"),
        GOOD     (0.75f, R.color.measure_good, "Good"),
        VERY_GOOD(1.0f,  R.color.measure_good, "Very Good");

        private float progress;
        private int color;
        private String text;

        MeasurementDecision(float progress, int color, String text) {
            this.progress = progress;
            this.color = color;
            this.text = text;
        }

        public float getProgress() {
            return this.progress;
        }

        public int getColor() {
            return this.color;
        }

        public String getText() {
            return this.text;
        }
    }
}