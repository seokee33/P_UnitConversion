package kr.claud.synesper.ui.notice;

public enum NoticeConstant {
    BABY_BASE    (  0, "baby"),
    BBPM_HIGH    (  1, "high"),
    BBPM_LOW     (  2, "low"),
    BBPM_LOWHIGH (  3, "low"),
    MOM_BASE     (100, "mom"),
    MBPM_HIGH    (101, "high"),
    MBPM_LOW     (102, "low"),
    MBPM_LOWHIGH (103, "high and low"),
    DEVICE_BASE  (200, "device");


    private int code;
    private String msg;

    NoticeConstant(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}

