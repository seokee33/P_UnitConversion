package kr.claud.synesper.ui.setting.menu;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONException;

import com.ms.api.login.Login;
import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.databinding.FragmentDeviceBinding;
import kr.claud.synesper.device.SynesperAdapter;
import ky.labsource.LsBluetooth;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DeviceFragment extends Fragment {
    public static final String TAG = "DeviceFragment";

    private DeviceViewModel deviceViewModel;
    private FragmentDeviceBinding binding;
    private RecyclerView mSynesperView;
    private TextView mDeviceTextView;
    private ImageView mImageViewConnectedClear;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        deviceViewModel = new ViewModelProvider(this).get(DeviceViewModel.class);

        binding = FragmentDeviceBinding.inflate(inflater, container, false);
        mDeviceTextView = binding.textViewConnectedDeviceName;
        mImageViewConnectedClear = binding.imageViewConnectedClear;

        AppData ad = AppData.I();
        updateDeviceName(ad.mPrefDeviceName);

        View root = binding.getRoot();

        //final TextView textView = binding.textDevice;
        //deviceViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        initDeviceManager(root);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        scanStopLeDevice();

        binding = null;

        Log.d(TAG, "onDestroyView()");
    }


    //---------------------------------------------------
    // BLE Device
    private ImageView mImageViewScan;
    private boolean mScanButtonClicked = false;
    private boolean mScanning = false;
    private Handler mHandler;

    private void updateDeviceName(String devName) {
        if (devName == null || devName.length() == 0) {
            mDeviceTextView.setText(R.string.signup_no_device_connected_);
            //setStateStartButton(false);
        } else {
            mDeviceTextView.setText(devName);
            //setStateStartButton(true);
        }
    }

    private void changeDeviceName(String devName, String devAddr) {
        AppData ad = AppData.I();
        ad.setDevice(devName, devAddr);
        try{
            Login.updateDeviceSerialNumber(ad.mPrefDeviceName, new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if(response.isSuccessful()){
                        Log.i("kimmmmmmmm","성공");
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Toast.makeText(getActivity(),"기기등록을 실패했습니다.\n설정에서 기기를 다시 등록해주세요.",Toast.LENGTH_SHORT);
                }
            });
        }catch (JSONException e) {
            throw new RuntimeException(e);
        }

        updateDeviceName(devName);
    }


    private SynesperAdapter.OnItemClickListener mOnItemClickListener = new SynesperAdapter.OnItemClickListener() {
        @Override
        public void onItemClick(View v, SynesperAdapter.SynesperItem item, int pos) {
            Log.d(TAG, "onItemClick: bt addr=[" + item.getAddress() + "] selected!!!");

            changeDeviceName(item.getName(), item.getAddress());

            if (mScanning) {
                scanStopLeDevice();
            }

            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    MainActivity macty = (MainActivity) getActivity();
                    macty.clickBleDeviceByDeviceFragment(item.getAddress());
                }
            }, 100);
        }
    };

    private void initDeviceManager(View root) {
        deviceViewModel.setAdapterItemClickListener(mOnItemClickListener);

        //final RecyclerView mSynesperView = (RecyclerView) root.findViewById(R.id.recyclerViewDevices);
        mSynesperView = binding.recyclerViewDevices;
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mSynesperView.setLayoutManager(mLinearLayoutManager);

        mSynesperView.setAdapter(deviceViewModel.getAdapter());
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mSynesperView.getContext(), mLinearLayoutManager.getOrientation());
        mSynesperView.addItemDecoration(dividerItemDecoration);

        //20230224
        deviceViewModel.clearArrayList();

        mScanButtonClicked = false;
        mScanning = false;
        mHandler = new Handler();

        mImageViewScan = (ImageView) root.findViewById(R.id.imageViewDevice);
        mImageViewScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "Scan Click!!!");

                if (mScanButtonClicked)
                    return;
                mScanButtonClicked = true;

                mImageViewScan.setEnabled(false);

                if (!mScanning) {
                    scanStartLeDevice();
                } else {
                    scanStopLeDevice();
                }
            }
        });

        mImageViewConnectedClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeDeviceName(null, null);
            }
        });

        //20230227: DeviceFragment 시작시  바로 스캔 시작
        mImageViewScan.setEnabled(false);
        scanStartLeDevice();
    }


    private void scanStartLeDevice() {
        LsBluetooth lsBt = LsBluetooth.IGet();

        Runnable scanRunnable = new Runnable() {
            @Override
            public void run() {
                lsBt.ScanStop();
                //mBtnCancel.setText(R.string.scan);

                //mHandler.removeCallbacks(mDisappearRunnable);
                //mHandler.post(mDisappearRunnable);
            }
        };

        deviceViewModel.clearArrayList();

        // Stops scanning after a pre-defined scan period.
        //mHandler.postDelayed(scanRunnable, SCAN_PERIOD);
        lsBt.ScanStartWithInterval(mOnLeScanListener, 5000);

        //mBtnCancel.setText(R.string.cancel);
    }

    private void scanStopLeDevice() {
        LsBluetooth lsBt = LsBluetooth.IGet();
        lsBt.ScanStop();
    }


    LsBluetooth.OnLeScanListener mOnLeScanListener = new LsBluetooth.OnLeScanListener() {
        @Override
        public void onStarted() {
            Log.d(TAG, "[LE] Scan Start ================");
            mScanning = true;
            //mImageViewScan.setText("STOP");
            mImageViewScan.setEnabled(true);
            mScanButtonClicked = false;
        }

        @Override
        public boolean onDone(int itemCount) {
            Log.d(TAG, "[LE] Scan Done -----------------");
            Log.d(TAG, "itemCount=" + itemCount);
            return true;
        }

        @Override
        public void onStopped() {
            Log.d(TAG, "[LE] Scan Stop -----------------");
            mScanning = false;
            //mImageViewScan.setText("SCAN");
            mImageViewScan.setEnabled(true);
            mScanButtonClicked = false;
        }

        @Override
        public boolean onDeviceFound(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
            @SuppressLint("MissingPermission") String devName = device.getName();
            if (devName == null)
                return false;

            try{
                String namePrefix = devName.substring(0, 5);
                Log.i("kimkim",namePrefix);
                if (namePrefix != null && namePrefix.compareTo("VoBLE") == 0)
                    return true;

                namePrefix = devName.substring(0, 3);
                Log.i("kimkim",namePrefix);
                if (namePrefix != null && namePrefix.compareTo("CSY") == 0)
                    return true;

                namePrefix = devName.substring(0, 4);
                Log.i("kimkim",namePrefix);
                if (namePrefix != null && namePrefix.compareTo("SSBN") == 0)
                    return true;
            }catch (StringIndexOutOfBoundsException e){
                Log.e("DeviceScanError","DeviceName : "+devName+"=>"+ e.toString());
            }
            return false;
        }

        @Override
        public void onDeviceAdded(final BluetoothDevice device, final int rssi) {
            getActivity().runOnUiThread(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    deviceViewModel.addSynesper(device.getName(), device.getAddress(),   rssi);
                    Log.d(TAG, "[LE] Scan: Addr=" + device.getAddress() + ", rssi=" + rssi);
                }
            });
        }

        @Override
        public void onDeviceUpdated(BluetoothDevice device, int rssi) {

        }
    };
}