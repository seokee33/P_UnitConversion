package com.ms.api;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class RetrofitBuilderProvider {
    public static String web = "https://synesper.clairaudience.co.kr/api/";

    public static Retrofit.Builder getRetrofitPersonalBuilder() {
        return new Retrofit.Builder()
                .baseUrl(web)
                .addConverterFactory(ScalarsConverterFactory.create());
    }

    public static Retrofit.Builder getRetrofitLoginBuilder() {
        return new Retrofit.Builder()
                .baseUrl(web)
                .client(OkHttpClientProvider.getLoginOkHttpClient())
                .addConverterFactory(GsonConverterFactory.create());
    }

    public static Retrofit.Builder getRetrofitJoinBuilder(){
        return new Retrofit.Builder()
                .baseUrl(web)
                .addConverterFactory(GsonConverterFactory.create());
    }

    public static Retrofit.Builder getFileUploadBuilder(){
        return new Retrofit.Builder()
                .baseUrl(web)
                .addConverterFactory(GsonConverterFactory.create())
                .client(OkHttpClientProvider.getFileUploadOkHttpClient());
    }
    public static Retrofit.Builder getAccountBuilder(){
        return new Retrofit.Builder()
                .baseUrl(web)
                .addConverterFactory(GsonConverterFactory.create())
                .client(OkHttpClientProvider.getAccountOkHttpClient());
    }
}
