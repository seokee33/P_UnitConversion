package ky.labsource.net;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpServer extends Handler {
    private static final String TAG = "HttpServer";

    private static final int WHAT_WRITE = 0;
    private static final int WHAT_WRITEBYTES = 1;

    private static final String lineEnd = "\r\n";
    private static final String twoHyphens = "--";
    private static final String boundary = "*****";

    private HttpURLConnection mHttpConn = null;
    private DataOutputStream mDataOutputStream = null;


    public interface OnHttpServerListener {
        boolean onConnected(HttpServer server, HttpURLConnection conn);
        boolean onDisconnected(HttpServer server, HttpURLConnection conn);
        void onTransfer(HttpServer server);
        void onError(HttpServer server, String errMsg);
    }
    private OnHttpServerListener mOnHttpServerListener;
    public void setOnHttpServerListener(OnHttpServerListener l) {
        this.mOnHttpServerListener = l;
    }

    //---- Constructor ----------------------------------
    public HttpServer(OnHttpServerListener l) {
        mOnHttpServerListener = l;
    }

    @Override
    public void handleMessage(@NonNull Message msg) {
        super.handleMessage(msg);

        switch (msg.what) {
            case WHAT_WRITE:
                _write((byte[])msg.obj, msg.arg1, msg.arg2);
                break;

            case WHAT_WRITEBYTES:
                _writeBytes((String)msg.obj);
                break;
        }
    }


    private void _write(byte[] b, int off, int len) {
        if (mDataOutputStream == null)
            return;

        try {
            mDataOutputStream.write(b, off, len);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void _writeBytes(String s) {
        if (mDataOutputStream == null)
            return;

        try {
            mDataOutputStream.writeBytes(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public boolean connect(String httpServer, String fileName) {
        boolean bRet = true;

        try {
            URL url = new URL(httpServer);
            mHttpConn = (HttpURLConnection) url.openConnection();

            boolean bConn = false;
            if (mOnHttpServerListener != null) {
                bConn = mOnHttpServerListener.onConnected(this, mHttpConn);
            }

            if (!bConn) {
                mHttpConn.setDoInput(true);
                mHttpConn.setDoOutput(true);
                mHttpConn.setUseCaches(false);
                mHttpConn.setRequestMethod("POST");
                mHttpConn.setRequestProperty("Connection", "Keep-Alive");
                mHttpConn.setRequestProperty("ENCTYPE", "multipart/form-data");
                mHttpConn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                mHttpConn.setRequestProperty("uploaded_file", fileName);
            }

            mDataOutputStream = new DataOutputStream(mHttpConn.getOutputStream());
            mDataOutputStream.writeBytes(twoHyphens + boundary + lineEnd);
            //dos.writeUTF("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);
            mDataOutputStream.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);
            mDataOutputStream.writeBytes(lineEnd);
        } catch (MalformedURLException malformex) {
            bRet = false;
            malformex.printStackTrace();

            if (mOnHttpServerListener != null) {
                mOnHttpServerListener.onError(this, malformex.getMessage());
            }
        } catch (IOException ioe) {
            bRet = false;
            ioe.printStackTrace();

            if (mOnHttpServerListener != null) {
                mOnHttpServerListener.onError(this, ioe.getMessage());
            }
        }
        return bRet;
    }

    public void disconnect() {
        if (mDataOutputStream == null)
            return;

        int rspCode = 0;
        try {
            mDataOutputStream.writeBytes(lineEnd);
            mDataOutputStream.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

            boolean bDisconn = false;
            if (mOnHttpServerListener != null) {
                bDisconn = mOnHttpServerListener.onDisconnected(this, mHttpConn);
            }

            if (!bDisconn) {
                rspCode = mHttpConn.getResponseCode();
                String rspMessage = mHttpConn.getResponseMessage();

                if (rspCode == 200) {
                    if (mOnHttpServerListener != null) {
                        mOnHttpServerListener.onError(this, "HTTP Response(" + rspCode + "):" + rspMessage);
                    }
                }
            }

            mDataOutputStream.flush();
            mDataOutputStream.close();
            mDataOutputStream = null;

            mHttpConn.disconnect();
            mHttpConn = null;
        } catch (IOException e) {
            e.printStackTrace();

            if (mOnHttpServerListener != null) {
                mOnHttpServerListener.onError(this, e.getMessage());
            }
        }
    }

    public void write(byte[] b, int off, int len) {
        Message msg = obtainMessage(WHAT_WRITE, off, len, b);
        sendMessage(msg);
    }

    public void wrtieBytes(String s) {
        Message msg = obtainMessage(WHAT_WRITEBYTES, s);
        sendMessage(msg);
    }
}