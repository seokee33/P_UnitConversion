package kr.claud.synesper.ui.notice;

import android.content.Context;
import android.os.Handler;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import kr.claud.synesper.adapter.HcalDataDetailAdapter;
import kr.claud.synesper.adapter.HcalNoticeAdapter;
import kr.claud.synesper.adapter.HcalNoticeDetailAdapter;

public class NoticeViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    public LiveData<String> getText() {
        return mText;
    }
    private static ArrayList<HcalNoticeAdapter.HcalNoticeItem> mArrayListHcalNotice;
    private static ArrayList<HcalNoticeDetailAdapter.HcalNoticeDetailItem> mArrayListHcalNoticeDetail;
    static {
        mArrayListHcalNotice = new ArrayList<>();
        mArrayListHcalNoticeDetail = new ArrayList<>();
    }

    private HcalNoticeAdapter mHcalNoticeAdapter;
    private HcalNoticeDetailAdapter mHcalNoticeDetailAdapter;

    public NoticeViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is notice fragment");

    }

    public void createAdapter(Context context) {
        mHcalNoticeAdapter = new HcalNoticeAdapter(mArrayListHcalNotice);
        mHcalNoticeDetailAdapter = new HcalNoticeDetailAdapter(context, mArrayListHcalNoticeDetail);
    }

//---------------------------------------------------------
    public void setAdapterListener(HcalNoticeAdapter.OnAdapterListener l) {
        mHcalNoticeAdapter.setOnAdapterListener(l);
    }

    public ArrayList<HcalNoticeAdapter.HcalNoticeItem> getArrayList() {
        return mArrayListHcalNotice;
    }

    public void clearArrayList() {
        mArrayListHcalNotice.clear();
        mHcalNoticeAdapter.notifyDataSetChanged();
    }

    public HcalNoticeAdapter getAdapter() {
        return mHcalNoticeAdapter;
    }

    //---------------------------------------------------------
    public void setAdapterDetailListener(HcalNoticeDetailAdapter.OnAdapterListener l) {
        mHcalNoticeDetailAdapter.setOnAdapterListener(l);
    }

    public ArrayList<HcalNoticeDetailAdapter.HcalNoticeDetailItem> getArrayListDetail() {
        return mArrayListHcalNoticeDetail;
    }

    public void clearArrayListDetail() {
        mArrayListHcalNoticeDetail.clear();
        mHcalNoticeDetailAdapter.notifyDataSetChanged();
    }

    public HcalNoticeDetailAdapter getAdapterDetail() {
        return mHcalNoticeDetailAdapter;
    }
}