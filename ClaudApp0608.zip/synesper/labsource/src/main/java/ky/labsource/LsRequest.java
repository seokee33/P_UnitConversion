package ky.labsource;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.util.Log;

import androidx.annotation.IntRange;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class LsRequest {

    public static final String ACTION_REQUEST_SETTINGS_LOCATION_SOURCE = "android.settings.LOCATION_SOURCE_SETTINGS";
    public static final String ACTION_REQUEST_BLUETOOTH_ENABLE         = "android.bluetooth.adapter.action.REQUEST_ENABLE";


    public static final int PERMISSION_REQUEST_UNDEF = 0;


    //---------------------------------------------------------------------------------------------
    public static Intent intentFor(String action) {
        return new Intent(action);
    }

    public static void startActivityForResult(Activity a, String action, int reqCode) {
        Intent i = LsRequest.intentFor(action);
        a.startActivityForResult(i, reqCode);
    }

    public static class Action {

        public static void SETTINGS_LOCATION_SOURCE(Activity a, int reqCode) {
            LsRequest.startActivityForResult(a, ACTION_REQUEST_SETTINGS_LOCATION_SOURCE, reqCode);
        }

    }

    //---------------------------------------------------------------------------------------------
    // Check
    public static boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED)) {
            return true;
        }
        return false;
    }

    public static boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED) || state.equals(Environment.MEDIA_MOUNTED_READ_ONLY)) {
            return true;
        }
        return false;
    }

    //---------------------------------------------------------------------------------------------
/*
    public class RequestItem {
        public String permission;
        public int reqCode;
        public boolean stopOnFail;  // true : 퍼미션을 획득에 실패하면 중지, false : 실패해도 다음 퍼미션 획득 진행
    }

    public interface RequestCallback {
        void onResult(String permission);
    }

    public static void startRequests(@NonNull RequestCallback cb, RequestItem[] requests) {
        if (requests.length == 0) {
            cb.onResult(null);
            return;
        }

        requests[0].
    }


    public static boolean doActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        return false;
    }
*/
    //---------------------------------------------------------------------------------------------
    // final @NonNull String[] permissions,   Manifest.permission.ACCESS_FINE_LOCATION
    // reqCode 가  0 과 같으면 퍼미션을 요청하지 않고 퍼미션 체크만 수행
    public static boolean permissionIf(final @NonNull Activity a, @NonNull String permission, final @IntRange(from = 0) int reqCode) {
        boolean bRet = true;
        if (ActivityCompat.checkSelfPermission(a, permission) != PackageManager.PERMISSION_GRANTED) {
            if (reqCode > PERMISSION_REQUEST_UNDEF) {
                ActivityCompat.requestPermissions(a, new String[]{permission}, reqCode);
            }
            bRet = false;
        }
        return bRet;
    }

    public static boolean permissionsIf(final @NonNull Activity a, @NonNull String[] permissions, final @IntRange(from = 0) int reqCode) {
        ArrayList<String> checkPermissions = new ArrayList<String>();
        for (String szPermission : permissions) {
            if (ActivityCompat.checkSelfPermission(a, szPermission) != PackageManager.PERMISSION_GRANTED) {
                checkPermissions.add(szPermission);
            }
        }
        if (checkPermissions.size() == 0)
            return true;

        if (reqCode > PERMISSION_REQUEST_UNDEF) {
            ActivityCompat.requestPermissions(a, checkPermissions.toArray(new String[checkPermissions.size()]), reqCode);
        }
        return false;
    }

    public static class Permission {

        public static String[] permissions;

        static {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissions = new String[]{
                        Manifest.permission.BLUETOOTH_SCAN,
                        Manifest.permission.BLUETOOTH_ADVERTISE,
                        Manifest.permission.BLUETOOTH_CONNECT };
            } else if  (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                permissions = new String[]{ Manifest.permission.BLUETOOTH };
            } else {
                permissions = null;
            }
        };

        public static boolean ACCESS_FINE_LOCATION_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            return LsRequest.permissionIf(a, Manifest.permission.ACCESS_FINE_LOCATION, reqCode);
        }

        public static boolean CAMERA_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            boolean bRet = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                bRet = LsRequest.permissionIf(a, Manifest.permission.CAMERA, reqCode);
            }
            return bRet;
        }

        public static boolean EXTERNAL_STORAGE_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            boolean bRet = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                bRet = LsRequest.permissionsIf(a, new String[]{ Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE }, reqCode);
            }
            return bRet;
        }

        //------------------------------------------------------------------
        public static String[] BLUETOOTH_ALL_PERMISSIONS() {
            return permissions;
        }

        public static boolean BLUETOOTH_ALL_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            boolean bRet = true;
            Log.d("LsRequest.Permission", "------------------------ Build.VERSION.SDK_INT=" + Build.VERSION.SDK_INT);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Log.d("LsRequest.Permission", "SDK_INT>=Build.VERSION_CODES.S");
                bRet = LsRequest.permissionsIf(a, permissions, reqCode);
            } else if  (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Log.d("LsRequest.Permission", "SDK_INT>=Build.VERSION_CODES.M");
                bRet = LsRequest.permissionsIf(a, permissions, reqCode);
            }
            return bRet;
        }

        public static boolean BLUETOOTH_CONNECT_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            return LsRequest.permissionIf(a, Manifest.permission.BLUETOOTH_CONNECT, reqCode);
        }

        public static boolean BLUETOOTH_SCAN_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            return LsRequest.permissionIf(a, Manifest.permission.BLUETOOTH_SCAN, reqCode);
        }

        public static boolean BLUETOOTH_ADVERTISE_IF(final @NonNull Activity a, final @IntRange(from = 0) int reqCode) {
            return LsRequest.permissionIf(a, Manifest.permission.BLUETOOTH_ADVERTISE, reqCode);
        }

    }
}
