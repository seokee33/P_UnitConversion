package kr.claud.synesper.media;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ProfileImage {
    public static final String TAG = "ProfileImage";

    private File _filesDir;
    private Bitmap _bitmap;

    public static String stringFileName(String name) {
        String fileName = "profile_" + name + ".jpg";
        return fileName;
    }

    public static Bitmap bitmapFromCamera(Intent data) {
        Bundle extras = data.getExtras();
        return (Bitmap) extras.get("data");
    }

    public static Bitmap bitmapFromGallery(Intent data, Context ctx) {
        Uri selectedImage = data.getData();
        Bitmap bitmap = null;
        if (selectedImage != null) {
            try {
                if (Build.VERSION.SDK_INT < 28) {
                    bitmap = MediaStore.Images.Media.getBitmap(ctx.getContentResolver(), selectedImage);
                } else {
                    ImageDecoder.Source source = ImageDecoder.createSource(ctx.getContentResolver(), selectedImage);
                    bitmap = ImageDecoder.decodeBitmap(source);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
/*
        Uri selectedImage = data.getData();
        String[] filePathColumn = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        if (cursor == null || cursor.getCount() < 1) {
            return;
        }
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);

        if (columnIndex < 0)
            return;

        //선택한 파일 경로
        String picturePath = cursor.getString(columnIndex);
        _bitmap = BitmapFactory.decodeFile(picturePath);
        cursor.close();
 */
        return bitmap;
    }

    public static boolean isBitmapCropped(Intent data) {
        Bundle extras = data.getExtras();
        if (extras != null) {
            return extras.getBoolean("result_from_crop");
        }
        return false;
    }

    public static Bitmap cropBitmapFromGallery(Intent data) {
        Bundle extras = data.getExtras();
        if (extras != null) {
            if (extras.getBoolean("result_from_crop")) {
                return extras.getParcelable("data");
                //ByteArrayOutputStream stream = new ByteArrayOutputStream();
                //bitmap.compress(Bitmap.CompressFormat.JPEG, 75, stream);
            }
        }
        return null;
    }

    //-----------------------------------
    public ProfileImage(Context ctx) {
        this._filesDir = ctx.getFilesDir();
    }

    public Bitmap getImage() {
        return _bitmap;
    }

    public void clearImage() {
        _bitmap = null;
    }

    public void setImage(String name) {
        String fileName = stringFileName(name);
        File bmFile = new File(_filesDir, fileName);
        if (bmFile.exists()) {
            _bitmap = BitmapFactory.decodeFile(bmFile.getAbsolutePath());
        }
    }

    public void setImage(Bitmap bitmap) {
        _bitmap = bitmap;
    }

    //카메라로 부터 값을 받아와서 Bitmap으로 변환
    public void setImage(Intent data) {
        setImage(bitmapFromCamera(data));
    }

    //Intent data : 겔러리로 부터 받은 경로값을 받아와서 Bitmap으로 변환하여 반환
    public void setImageFromGallery(Intent data, Context ctx) {
        setImage(bitmapFromGallery(data, ctx));
    }


    public void saveToJpeg(String name) {
        if (_bitmap != null) {
            saveBitmapToJpeg(_bitmap, name);
        }
    }

    public void saveBitmapToJpeg(Bitmap bitmap, String name) {
        String fileName = stringFileName(name);
        Log.d(TAG, "Profile=" + fileName);
        File tempFile = new File(_filesDir, fileName);
        if (tempFile.exists()) {
            tempFile.delete();
        }

        try {
            tempFile.createNewFile();
            FileOutputStream out = new FileOutputStream(tempFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "FileNotFoundException : " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "IOException : " + e.getMessage());
            //e.printStackTrace();
        }
    }
}
