package com.ms.api;


import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;


public class SmdToBase64 {

    public static String encodingBase64(File file) {
        try {
            FileInputStream inputStream = new FileInputStream(file);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            byte[] buffer = new byte[1024];
            int length;
            while ((length = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, length);
            }

            String base64 = Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP);

            inputStream.close();
            outputStream.close();

            return base64;
        }catch (IOException e){

        }
        return "";
    }

}
