package com.ms.api.file;

import static com.ms.api.OkHttpClientProvider.cookieJar;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.List;

import com.ms.api.RetrofitBuilderProvider;
import com.ms.api.RetrofitClient;
import com.ms.api.SmdToBase64;
import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;

public class FileUploader {
    public static void uploadFile(int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, File file, Callback<ResponseBody> callback) throws JSONException {
        String data = SmdToBase64.encodingBase64(file);
//        Log.i("FileData", "size = "+data.length()+", Data = "+data);

        JSONObject measure = new JSONObject();
        measure.put("bMin",bMin);
        measure.put("bMax",bMax);
        measure.put("bAvg",bAvg);
        measure.put("mMin",mMin);
        measure.put("mMax",mMax);
        measure.put("mAvg",mAvg);
//        Log.i("RequestBody",measure.toString());

        RequestBody fileBody = RequestBody.create(MediaType.parse("text/plain"), data);
        RequestBody measureBody = RequestBody.create(MediaType.parse("application/json"), String.valueOf(measure));

        MultipartBody multipartBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file",null, fileBody)
                .addFormDataPart("data", null, measureBody)
                .build();

        List<Cookie> cookies = cookieJar.loadForRequest(HttpUrl.parse(RetrofitBuilderProvider.web));
        String header = "";
        for (Cookie cookie : cookies) {
            String cookieString = cookie.name() + "=" + cookie.value();
            header = cookieString;
        }

        Call<ResponseBody> call = RetrofitClient.getFileUploadService().    uploadFile(header, multipartBody);
        call.enqueue(callback);

    }


    public static void checkUpload(Callback<ResponseBody> callback) throws JSONException {
        Call<ResponseBody> call = RetrofitClient.getFileUploadService().checkUpload();
        call.enqueue(callback);
    }


}
