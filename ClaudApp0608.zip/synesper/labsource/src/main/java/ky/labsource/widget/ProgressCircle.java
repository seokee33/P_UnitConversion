package ky.labsource.widget;

/*
    Example 1:
        ArrayList<ProgressCircle.Divider> dividerList = new ArrayList<ProgressCircle.Divider>();
        dividerList.add(new ProgressCircle.Divider(0.25f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.50f, 1.00f, Color.RED, "BAD", Color.RED));
        dividerList.add(new ProgressCircle.Divider(0.75f, 1.00f, Color.GREEN, "GOOD", Color.rgb(255, 167, 38)));
        dividerList.add(new ProgressCircle.Divider(1.00f, 1.00f, Color.GREEN, "GOOD", Color.rgb(81, 196, 203)));

        mProgressCircleResult = binding.progressCircleResult;
        mProgressCircleResult.setDividerList(dividerList);
        mProgressCircleResult.setTextGravity(Gravity.CENTER_VERTICAL);
        mProgressCircleResult.setEnable(false);
        mProgressCircleResult.setEnableText(false);
        //mProgressCircleResult.setBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.ic_heart_border_24));
        mProgressCircleResult.setProgress(0.0f, 0.9f);
        mProgressCircleResult.sweepProgress();

    Example 2:
        mProgressCircleBaby = binding.progressCircleBaby;
        mProgressCircleBaby.setTextGravity(Gravity.BOTTOM);
        mProgressCircleBaby.setEnable(false);
        mProgressCircleBaby.setProgress(0.5f, 0.1f);
        mProgressCircleBaby.sweepProgress();
*/

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import androidx.core.view.GravityCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import ky.labsource.R;


public class ProgressCircle extends View {

    private final RectF mOval = new RectF();
    private int mAngleBase = 90;  // degree
    private int angleGap = 4;  // degree
    private Bitmap icon;

    // 0.0f ~ 1.0f
    private float mSweepAngle = 0.0f;
    private float mStartAngle = 0.0f;
    private float mEndAngle = 1.0f;

    private Paint progressPaint = new Paint();
    private TextPaint textPaint = new TextPaint();
    private Paint incompletePaint = new Paint();
    private Paint percentagePaint = new Paint();

    private int gravityText = Gravity.BOTTOM;
    private ArrayList<Divider> defaultDividerList;
    private ArrayList<Divider> dividerList = null;

    private float strokeWidth = 30.0f;
    private CharSequence charSeqText = null;
    private CharSequence charSeqUnit = null;
    private int textColor;
    private float textSize;

    private int incompleteColor;

    private int progressLowColor;
    private int progressMediumColor;
    private int progressHighColor;

    private float progressValueMin;
    private float progressValueMax;

    private boolean mEnabled = true;
    private boolean mTextEnabled = true;


    @SuppressLint("ResourceAsColor")
    public ProgressCircle(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.ProgressCircle, 0, 0);

        try {
            charSeqText = a.getText(R.styleable.ProgressCircle_android_text);
            textColor = a.getColor(R.styleable.ProgressCircle_android_textColor, android.R.color.holo_red_dark);
            textSize = a.getDimension(R.styleable.ProgressCircle_android_textSize, 100);
            charSeqUnit = a.getText(R.styleable.ProgressCircle_unitText);

            strokeWidth = a.getDimension(R.styleable.ProgressCircle_strokeWidth, 30.0f);

            progressLowColor = a.getColor(R.styleable.ProgressCircle_progressLowColor, Color.RED);
            progressMediumColor = a.getColor(R.styleable.ProgressCircle_progressMediumColor, Color.rgb(255, 167, 38));
            progressHighColor = a.getColor(R.styleable.ProgressCircle_progressHighColor, Color.rgb(81, 196, 203));
            incompleteColor =a.getColor(R.styleable.ProgressCircle_incompleteProgressColor, android.R.color.darker_gray);
        } finally {
            a.recycle();
        }

        defaultDividerList = new ArrayList<Divider>();
        defaultDividerList.add(new Divider(0.25f, 0.25f, progressLowColor, "Very Bad", Color.RED));
        defaultDividerList.add(new Divider(0.50f, 0.50f, progressLowColor, "Bad", Color.RED));
        defaultDividerList.add(new Divider(0.75f, 0.75f, progressHighColor, "Good", Color.rgb(255, 167, 38)));
        defaultDividerList.add(new Divider(1.00f, 1.00f, progressHighColor, "Very Good", Color.rgb(81, 196, 203)));

        progressPaint.setColor(progressHighColor);
        progressPaint.setStrokeWidth(strokeWidth);
        progressPaint.setStyle(Paint.Style.STROKE);
        progressPaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        textPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(textColor);
        textPaint.setTextSize(textSize);
        Typeface tf = Typeface.create("Roboto Condensed Light", Typeface.BOLD);
        textPaint.setTypeface(tf);

        percentagePaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        percentagePaint.setColor(textColor);
        percentagePaint.setTextSize(textSize / 3);

        incompletePaint.setColor(incompleteColor);
        incompletePaint.setStrokeWidth(strokeWidth);
        incompletePaint.setStyle(Paint.Style.STROKE);
        incompletePaint.setFlags(Paint.ANTI_ALIAS_FLAG);


        progressValueMin = 0.f;
        progressValueMax = 100.f;
        //icon = BitmapFactory.decodeResource(getResources(), R.drawable.);

    }

    private void drawGraph(Canvas canvas, float startAngle, float sweepAngle) {
        if (sweepAngle < 0.f)
            sweepAngle = 0.f;
        else if (sweepAngle > 1.f)
            sweepAngle = 1.f;

        float currentAngleGap = (sweepAngle == 1.0f || sweepAngle == 0.f) ? 0.f : angleGap;

        float angleStart = -mAngleBase + (startAngle * 360) + currentAngleGap;
        float angleSweep = (sweepAngle * 360) - currentAngleGap;
        mOval.set(strokeWidth / 2, strokeWidth / 2, getWidth() - (strokeWidth / 2), getWidth() - (strokeWidth / 2));
        canvas.drawArc(mOval, angleStart, angleSweep, false, progressPaint);

        angleStart = (startAngle * 360) + (sweepAngle * 360) - mAngleBase + currentAngleGap;
        angleSweep = 360 - (sweepAngle * 360) - currentAngleGap;
        mOval.set(strokeWidth / 2, strokeWidth / 2, getWidth() - (strokeWidth / 2), getWidth() - (strokeWidth / 2));
        canvas.drawArc(mOval, angleStart, angleSweep, false, incompletePaint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        String gradeText = null;
        float sweepAngle = mSweepAngle;
        if (dividerList != null) {
            for (Divider div : dividerList) {
                if (mSweepAngle <= div.getDivideAngle()) {
                    gradeText = div.getText();
                    sweepAngle = div.getSweepAngle();
                    setProgressColor(div.getSweepColor());
                    setTextColor(div.getTextColor());
                    break;
                }
            }
        }
/*
        if (mSweepAngle <= 0.25f) {
            gradeText = "Very Bad";
            setProgressColor(progressLowColor);
            setTextColor(Color.RED);
        } else if (mSweepAngle <= 0.5f) {
            gradeText = "Bad";
            setProgressColor(progressLowColor);
            setTextColor(Color.RED);
        } else if (mSweepAngle <= 0.75f) {
            gradeText = "Good"; //"Careful";
            //setProgressColor(progressMediumColor);
            setProgressColor(progressHighColor);
            setTextColor(Color.rgb(255, 167, 38));
        } else {
            gradeText = "Very Good";
            setProgressColor(progressHighColor);
            setTextColor(Color.rgb(81, 196, 203));
        }
*/
        String text1 = null;
        int text1Color = 0;
        String text2 = null;
        int text2Color = 0;
        if (charSeqText != null && charSeqText.length() > 0) {
            if (charSeqUnit != null) {
                text1 = charSeqText.toString();
                text1Color = textColor;
                text2 = charSeqUnit.toString();
                text2Color = Color.rgb(192, 195, 197);
            } else {
                text1 = charSeqText.toString();
                text1Color = textColor;
            }
        } else {
            text1 = gradeText;
            text1Color = textColor;
        }

        if (mEnabled) {
            drawGraph(canvas, mStartAngle, sweepAngle); //mSweepAngle
        } else {
            drawGraph(canvas, mStartAngle, 0.0f);

            text1 = "  -  ";
            text1Color = incompleteColor;
            text2Color = incompleteColor;
        }

        if (mTextEnabled) {
            if (text2 != null) {
                drawTextWithUnit(canvas, textPaint, text1, text1Color, text2, text2Color);
            } else {
                setTextColor(text1Color);
                drawText(canvas, textPaint, text1);
            }
        }

        if(icon != null)
            canvas.drawBitmap(icon, canvas.getWidth() / 2 - icon.getWidth() / 2, strokeWidth + (canvas.getHeight() / 15), null);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, widthMeasureSpec);
    }

    private void drawText(Canvas canvas, Paint paint, String text) {
        //Rect bounds = new Rect();
        //paint.getTextBounds(text, 0, text.length(), bounds);
        //float x = (canvas.getWidth() / 2) - (bounds.width() / 2);
        //float y = (canvas.getHeight() / 2) + (bounds.height() / 2);
        //canvas.drawText(text, x, y, paint);

        paint.setTextAlign(Paint.Align.CENTER);

        float yOffset = 0.f;
        if (gravityText == Gravity.BOTTOM) {
            yOffset = textSize*1.5f;
        } else if (gravityText == Gravity.CENTER_VERTICAL) {
            yOffset = textSize / 2.0f;
        }
        canvas.drawText(text, canvas.getWidth()/2, canvas.getHeight()/2 + yOffset, paint);
    }

    private void drawTextWithPercent(Canvas canvas, Paint paint, String text, Paint percentagePaint) {
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);
        Rect percentageBounds = new Rect();
        percentagePaint.getTextBounds("%", 0, 1, percentageBounds);
        int x = (canvas.getWidth() / 2) - (bounds.width() / 2) - (percentageBounds.width() / 2);
        int y = (canvas.getHeight() / 2) + (bounds.height() / 2);
        canvas.drawText(text, x, y, paint);

        canvas.drawText("%", x + bounds.width() + percentageBounds.width() / 2, y - bounds.height() + percentageBounds.height(), percentagePaint);
    }

    private void drawTextWithUnit(Canvas canvas, Paint paint, String text, int color, String unit, int unitColor) {
        setTextColor(unitColor);
        paint.setTextAlign(Paint.Align.LEFT);
        canvas.drawText(unit, canvas.getWidth()/2, canvas.getHeight()/2 + textSize*1.2f, paint);

        setTextColor(color);
        paint.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText(text, canvas.getWidth()/2, canvas.getHeight()/2 + textSize*1.2f, paint);
    }

    public void setEnable(boolean bEnable) {
        mEnabled = bEnable;
    }

    public void setText(CharSequence str) {
        charSeqText = str;
    }

    public void setEnableText(boolean bEnable) {
        mTextEnabled = bEnable;
    }

    public void setTextColor(int color) {
        textPaint.setColor(color);
    }

    public void setProgressColor(int color) {
        progressPaint.setColor(color);
    }

    public void setIncompleteColor(int color) {
        incompletePaint.setColor(color);
    }

    public void setDividerListDefault() {
        dividerList = defaultDividerList;
    }

    public void setDividerList(ArrayList<Divider> list) {
        dividerList = list;
    }

    public void setTextGravity(int gravity) {
        gravityText = gravity;
        this.invalidate();
    }

    public void setMinMax(float min, float max) {
        this.progressValueMin = min;
        this.progressValueMax = max;
        this.invalidate();
    }

    public void setRange(float low, float high) {
        float lowModified = (low < progressValueMin) ? progressValueMin : low;
        float highModified = (high > progressValueMax) ? progressValueMax : high;

        mAngleBase = 90;

        // 0.f ~ 1.f
        float start = (lowModified - progressValueMin) / (progressValueMax - progressValueMin);
        float progress = (highModified - lowModified) / (progressValueMax - progressValueMin);
        mStartAngle = start;
        mEndAngle = start + progress;

        this.invalidate();
    }

    public void setProgress(float low, float value) {
        setRange(low, low + value);
    }

    public void setRangeRate(float low, float high) {
        if (low > 1.0f || low < 0.f || high > 1.0f || high < 0.f || low > high) {
            throw new RuntimeException("Value must be between 0 and 1: " + low + "-" + high);
        }

        mAngleBase = 90;

        mStartAngle = low;
        mEndAngle = high;

        this.invalidate();
    }

    public void setProgressRate(float start, float progress) {
        setRangeRate(start, start + progress);
    }

    public void sweepProgress() {
        mSweepAngle = mEndAngle - mStartAngle;
        this.invalidate();
    }

    public void startAnimation() {
        ValueAnimator anim = ValueAnimator.ofFloat(mStartAngle, mEndAngle);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                ProgressCircle.this.mSweepAngle = (Float) valueAnimator.getAnimatedValue();
                ProgressCircle.this.invalidate();
            }
        });
        anim.setDuration(500);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }


    public static class Divider {
        float divideAngle;
        float sweepAngle;
        int sweepColor;
        String text;
        int textColor;

        public Divider(float divideAngle, float sweepAngle, int sweepColor, String text, int textColor) {
            this.divideAngle = divideAngle;
            this.sweepAngle = sweepAngle;
            this.sweepColor = sweepColor;
            this.text = text;
            this.textColor = textColor;
        }

        public float getDivideAngle() {
            return this.divideAngle;
        }

        public float getSweepAngle() {
            return this.sweepAngle;
        }

        public int getSweepColor() {
            return this.sweepColor;
        }

        public String getText() {
            return this.text;
        }

        public int getTextColor() {
            return this.textColor;
        }
    }
}
