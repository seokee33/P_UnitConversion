package kr.claud.synesper.ui.register;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import kr.claud.synesper.R;
import kr.claud.synesper.databinding.FragmentRegisterCompletedBinding;

public class RegisterCompletedFragment extends RegisterFragment {

    private FragmentRegisterCompletedBinding binding;


    public static RegisterCompletedFragment newInstance() {
        return new RegisterCompletedFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mFragmentPage = 3;
        binding = FragmentRegisterCompletedBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root; //inflater.inflate(R.layout.fragment_register_completed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final Button completedButton = binding.buttonNext;
        completedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewModel.register(mViewModel.mUserRegister);
                frgmentListener_onFragmentNext();
            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}