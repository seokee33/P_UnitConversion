/*
 *  call: LsBluetooth.START()
 *
 */

package ky.labsource;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;

import java.util.List;

import ky.labsource.bluetooth.BLEContent;
import ky.labsource.bluetooth.BLEManager;
import ky.labsource.bluetooth.DeviceGatt;
import ky.labsource.bluetooth.ble.UUIDGroup;


public class LsBluetooth {
    public static final String TAG = "LsBluetooth";

    private static LsBluetooth _lsBluetooth;

    static {
        _lsBluetooth = null;
    }

    public static LsBluetooth IGet() { return _lsBluetooth; }

    /* Helper: BLEContent */
    public static LsBluetooth CREATE(Activity a) {
        if (!BLEContent.isBLESupported(a))
            return null;

        BLEContent.createInstance(a);

        if (!BLEContent.isBluetoothSupported())
            return null;

        if (_lsBluetooth == null)
            _lsBluetooth = new LsBluetooth();

        _lsBluetooth.mBleContent = BLEContent.IGet();
        return _lsBluetooth;
    }

    public static LsBluetooth CREATE(Activity a, boolean bBtEnable, int reqCode) {
        LsBluetooth lsbt = LsBluetooth.CREATE(a);
        if (lsbt == null)
            return null;

        if (bBtEnable)
        {
            lsbt.EnableBluetooth(a, reqCode);
        }
        return lsbt;
    }

    //-----------------------------------------------------------
    public interface OnLeScanListener {
        void onStarted();
        boolean onDone(int itemCount);
        void onStopped();

        // onDeviceFound가 true를 반환해야 디바이스가 목록에 추가됨.
        boolean onDeviceFound(BluetoothDevice device, int rssi, byte[] scanRecord);
        void onDeviceAdded(BluetoothDevice device, int rssi);
        void onDeviceUpdated(BluetoothDevice device, int rssi);
    }
    protected LsBluetooth.OnLeScanListener mLeScanListener = null;
    public void setOnLeScanListener(LsBluetooth.OnLeScanListener l) { mLeScanListener = l; }


    public interface OnLeUartListener {
        void onReceive();
    }

    //-----------------------------------------------------------
    private BLEContent mBleContent = null;
    private BLEManager mBleManager = null;
    private String mDeviceAddress = null;
    private Handler mHandlerScan;

    public LsBluetooth() {
        mHandlerScan = new Handler();
    }

    public boolean EnableBluetooth(Activity a, int reqCode)
    {
        if (mBleContent == null)
            return false;

        if (mBleContent.isBluetoothEnabled())
            return true;

        if (reqCode > 0) {
            LsRequest.startActivityForResult(a, BluetoothAdapter.ACTION_REQUEST_ENABLE, reqCode);
        }
        return false;
    }

    public boolean IsBluetoothEnabled()
    {
        return mBleContent.isBluetoothEnabled();
    }

    public BLEContent GetBleContent() {
        return mBleContent;
    }

    //-------------------------------------------------------------------------
    // Device Scan
    private long mScanIntervalMillis = 0;

    private Runnable mRunnableScanStop = new Runnable() {
        @Override
        public void run() {
            ScanStop();
        }
    };

    private Runnable mRunnableScanInterval = new Runnable() {
        @Override
        public void run() {
            boolean bDone = true;
            if (mLeScanListener != null) {
                bDone = mLeScanListener.onDone(mBleContent.countLEDevice());
            }

            if (bDone) {
                mHandlerScan.post(mRunnableScanStop);
            } else {
                mHandlerScan.postDelayed(mRunnableScanInterval, mScanIntervalMillis);
            }
        }
    };

    public boolean ScanStart(LsBluetooth.OnLeScanListener l) {
        return ScanStart(l, 0);
    }

    public boolean ScanStartWithInterval(LsBluetooth.OnLeScanListener l, long intervalMillis) {
        return ScanStart(l, intervalMillis);
    }

    public boolean ScanStart(LsBluetooth.OnLeScanListener l, long intervalMillis)
    {
        BLEContent bleContent = BLEContent.IGet();
        if (bleContent == null)
            return false;

        if (!bleContent.isBluetoothEnabled()) {
            return false;
        }
        else {
            if (IsScanning())
                return false;

            setOnLeScanListener(l);

            // Stops scanning after a pre-defined scan period.
            mScanIntervalMillis = intervalMillis;
            if (mScanIntervalMillis == 0) {
                mScanIntervalMillis = 10000;
            }
            mHandlerScan.postDelayed(mRunnableScanInterval, mScanIntervalMillis);

            bleContent.clearLEDeviceAll();
            bleContent.startLEScan(mScanLinsener);

            if (mLeScanListener != null) {
                mLeScanListener.onStarted();
            }
        }
        return true;
    }

    public void ScanStop()
    {
        mHandlerScan.removeCallbacks(mRunnableScanInterval);
        mHandlerScan.removeCallbacks(mRunnableScanStop);
        if (mBleContent.isScanning()) {
            mBleContent.stopLEScan(mScanLinsener);

            if (mLeScanListener != null) {
                mLeScanListener.onStopped();
            }
        }
    }

    private BLEContent.OnScanListener mScanLinsener = new BLEContent.OnScanListener() {

        @Override
        public void onScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {

            if (mLeScanListener != null) {
                if (!mLeScanListener.onDeviceFound(device, rssi, scanRecord))
                    return;
            }

            boolean bAdd = mBleContent.addLEDevice(device, rssi);
            if (bAdd) {
                mHandlerScan.removeCallbacks(mRunnableScanInterval);

                if (mLeScanListener != null) {
                    mLeScanListener.onDeviceAdded(device, rssi);
                }

                mHandlerScan.postDelayed(mRunnableScanInterval, mScanIntervalMillis);
            } else {
                if (mLeScanListener != null) {
                    mLeScanListener.onDeviceUpdated(device, rssi);
                }
            }
        }
    };


    //===========================================================================
    public boolean start(Context ctx, BLEManager.OnBleServiceListener listener) {
        mBleManager = BLEManager.createInstance(ctx);
        if (mBleManager == null)
            return false;

        mBleManager.setOnBleServiceListener(listener);
        mBleManager.init(ctx);
        return true;
    }

    public boolean startOnService(Context ctx, BLEManager.OnBleServiceListener listener) {
        mBleManager = BLEManager.createInstance(ctx);
        if (mBleManager == null)
            return false;

        mBleManager.setOnBleServiceListener(listener);
        mBleManager.init(ctx, true);
        return true;
    }

    public void stopOnService(Context ctx) {
        if (mBleManager != null) {
            mBleManager.destroy(ctx);
            mBleManager = null;
        }
    }


    public String getConnectedAddress() {
        return mDeviceAddress;
    }

    public boolean connect(Context ctx, String address) {
        mDeviceAddress = address;
        Log.d(TAG, "connect() ----------------------- address=" + address);
        return mBleManager.connectDevice(ctx, address);
    }

    public void disconnect() {
        mBleManager.disconnectDevice();
        Log.d(TAG, "disconnect() -----------------------");
    }

    public void close() {
        mDeviceAddress = null;
        if (mBleManager != null) {
            mBleManager.closeDevice();
            //20230224  mBleManager = null;
        }
    }

    public int getState() {
        return mBleManager.getState();
    }

    public void enableUartNotification() {
        getDevice().enableNotification(UUIDGroup.UUID_SERVICE_UART, UUIDGroup.UUID_CHAR_TX);
    }

    /*
    public void write(byte[] value) {
        mBleManager.write(value);
    }
    */

    public DeviceGatt getDevice() {
        return mBleManager.getDevice();
    }


    //--- BleContent helper ---------------------------------------------
    public void StartLEScan(BLEContent.OnScanListener l) {
        mBleContent.startLEScan(l);
    }

    public void StopLEScan(BLEContent.OnScanListener l) {
        if (mBleContent.isScanning()) {
            mBleContent.stopLEScan(l);
        }
    }

    public boolean IsScanning()
    {
        return mBleContent.isScanning();
    }

    public void ClearLEDeviceAll() {
        mBleContent.clearLEDeviceAll();
    }

    public List<BLEContent.DeviceItem> GetDeviceList() {
        return mBleContent.ITEMS;
    }

    public BLEContent.DeviceItem GetLEDevice(int pos) {
        return mBleContent.getLEDevice(pos);
    }

    public boolean AddLEDevice(BluetoothDevice device, int rssi) {
        return mBleContent.addLEDevice(device, rssi);
    }
}
