package ky.labsource.common;

/*
    mPhaseAdapter = new PhaseAdapter();
    mPhaseAdapter.setMinDelay(3000);
    mPhaseAdapter.add(mStepRun1, ...);
    mPhaseAdapter.run(this);
*/
import java.util.ArrayList;

public class PhaseAdapter {
    public static final String TAG = "PhaseAdapter";
    private final static long MINDELAY_MS = 10;

    public abstract static class Phase {
        private boolean stepDone = true;

        public boolean isCompleted() { return stepDone; }
        public void uncompleted() { stepDone = false; }
        public void completed() { stepDone = true; }

        public boolean run(PhaseAdapter adapter, Object o) {
            // return: true - go to next phase
            return true;
        }
    }

    private boolean _running = false;
    private Thread _thread = null;
    private ArrayList<Phase> _steps = new ArrayList<>();
    private Phase _phase = null;
    private long _minDelay = MINDELAY_MS;


    public void add(Phase... phs) {
        for (Phase ph : phs) {
            _steps.add(ph);
        }
    }

    public boolean isRunning() {
        return _running;
    }

    public void setMinDelay(long msDelay) {
        if (msDelay > 0)
            _minDelay = msDelay;
    }

    public void completed() {
        if (_phase != null) {
            _phase.completed();
        }
    }

    public void run(Object objPar) {
        _thread = new Thread(new Runnable() {
            @Override
            public void run() {
                if (_steps.size() == 0)
                    return;

                long startTime = 0;
                _running = true;
                while (_running) {
                    if (_phase == null) {
                        synchronized (PhaseAdapter.this) {
                            _phase = _steps.get(0);
                            _steps.remove(0);
                        }

                        startTime = System.currentTimeMillis();
                        if (_phase.run(PhaseAdapter.this, objPar)) {
                            _phase.completed();
                        }
                    } else {
                        try {
                            Thread.sleep(MINDELAY_MS);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }

                    long curTime = System.currentTimeMillis();
                    if (curTime - startTime > _minDelay) {
                        if (_phase.isCompleted()) {
                            _phase = null;
                            if (_steps.size() == 0) {
                                _running = false;
                                break;
                            }
                        }
                    }
                }
            }
        });
        _thread.start();
    }

    public void pause() { }
    public void resume() { }

    public void stop() {
        synchronized (this) {
            _running = false;
            _steps.clear();
        }

        if (_thread != null) {
            try {
                _thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
