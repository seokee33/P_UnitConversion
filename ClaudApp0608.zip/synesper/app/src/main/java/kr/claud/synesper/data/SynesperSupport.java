package kr.claud.synesper.data;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.media.AudioFormat;
import android.util.Log;
import android.widget.Toast;

import androidx.core.view.GravityCompat;

import java.text.DateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.device.SynesperGatt;
import kr.claud.synesper.media.FileManager;
import kr.claud.synesper.media.PCMPlayer;
import kr.claud.synesper.media.SmdFile;
import kr.claud.synesper.media.SmdFilePlayer;
import kr.claud.synesper.ui.measurement.MeasurementFragment;
import kr.claud.synesper.ui.measurement.MeasurementManager;
import ky.labsource.LsBluetooth;
import ky.labsource.bluetooth.BLEManager;
import ky.labsource.bluetooth.DeviceGatt;

public abstract class SynesperSupport {
    public static final String TAG = "SynesperSupport";

    public static final int PCG_PACKET_LENGTH = 224;
    public static final int PCG_SAMPLES_PER_PACKET = PCG_PACKET_LENGTH * 2;      // 448
    public static final int AUDIOTRACK_BUFFER_SIZE = PCG_SAMPLES_PER_PACKET * 2; // 896


    private Context _ctx;

    // BLE State
    public static final int BLE_INIT = 0;
    public static final int BLE_CONNECTING = 1;
    public static final int BLE_CONNECTED = 2;
    public static final int BLE_DISCONNECTING = 3;
    public static final int BLE_DISCONNECTED = 4;

    // SMDFile State
    public static final int SMDFILEPLAYER_PLAY = 0;
    public static final int SMDFILEPLAYER_READ = 1;
    public static final int SMDFILEPLAYER_STOP = 2;
    public static final int SMDFILEPLAYER_DONE = 3;

    // Error Code
    public static final int ERROR_BLUETOOTH_UNAVAILABLE = 1;

    // abstract method
    protected abstract void onBleServiceConnected();
    protected abstract void onBleTimerExpire();
    protected abstract void onBleDeviceConnected();
    protected abstract void onBleDeviceDisconnected();
    protected abstract boolean onReceiverPcg(short[] pcgData);
    protected abstract boolean onReceiverPpg(short[] ppgData, short ppgMin, short ppgMax);

    protected abstract void onMeasurementStateChanged(boolean bMeasurement);
    protected abstract void onMeasurementTimeLapse(int timeLapse);
    protected abstract void onMeasurementBeatDetected(int type);  // 0: mom, 1: mom

    protected abstract void onSmdFilePlayerChanged(int state, int par);

    protected abstract void onError(int errCode);

    //------------------------------------------------
    private LsBluetooth mLsBt = null;
    private String mConnectedAddress = null;

    private MeasurementManager mMeasMgr;
    private FileManager mFileMgr;
    private BleData mBleData = null;

    private static int PCM_SCALE = 10;

    private PCMPlayer mPcmPlayer = null;
    private SmdFilePlayer mSmdFilePlayer = null;
    private int mCurSmdFile = -1;



    public SynesperSupport(Context ctx) {
        this._ctx = ctx;
    }

    public void init(Activity a) {
        LsBluetooth.CREATE(a, true, 0);

        bleStartService(a);
        initMeasurementManager();

        mBleData = new BleData();
        mFileMgr = new FileManager(_ctx);

        initPCMPlayer();
        initSmdFilePlayer();

        timerStart();
    }

    public void destroy() {
        timerStop();

        if (mPcmPlayer != null) {
            mPcmPlayer.stop();
            mPcmPlayer = null;
        }

        closeSmdFilePlayer();

        bleDisconnectDevice();
        bleStopService(_ctx);

        mLsBt.close();
    }

    public void resume() {
        if (mConnectedAddress != null) {
            bleConnectDevice(mConnectedAddress);
        }
    }

    public void stop() {
        mConnectedAddress = mLsBt.getConnectedAddress();
        bleDisconnectDevice();
    }


    public void measurementStartOrStop() {
        if (!mMeasMgr.isMeasuring()) {
            mMeasMgr.startMeasurement();
        } else {
            mMeasMgr.stopMeasurement();
        }
    }

    public void measurementStop() {
        mMeasMgr.stopMeasurement();
        //mMeasMgr.saveMeasurement();
    }

    public void measurementSave() {
        mMeasMgr.saveMeasurement();
    }

    public int getPCGBpm() {
        return mMeasMgr.getPCGBpm();
    }

    public int getPPGBpm() {
        return mMeasMgr.getPPGBpm();
    }

    public int getPPGMax() {
        return mMeasMgr.getPPGMax();
    }

    public int getPPGMin() {
        return mMeasMgr.getPPGMin();
    }

    public short[] pcgSubsampling(short[] pcgData) {
        return mBleData.subsampleVoice(pcgData, 32);
    }

    //-----------------------------------------------
    // Timer
    private Timer mCheckTimer;

    public void timerStart() {
        mCheckTimer = new Timer();
        TimerTask checkTimerTask = new TimerTask() {
            @Override
            public void run() {
                bleTimerHandler();
            }
        };
        mCheckTimer.schedule(checkTimerTask, 0, 1000);
    }

    public void timerStop() {
        if (mCheckTimer != null) {
            mCheckTimer.cancel();
            mCheckTimer = null;
        }
    }

    //-----------------------------------------------
    // Measurement Manager
    public void initMeasurementManager() {
        mMeasMgr = new MeasurementManager(_ctx, new MeasurementManager.OnMeasurementManagerListener() {
            @Override
            public void onStateChanged(boolean bMeasurement) {
                onMeasurementStateChanged(bMeasurement);
            }

            @Override
            public void onTimeLapse(int timeLapse) {
                onMeasurementTimeLapse(timeLapse);
            }

            @Override
            public void onBeatDetected(int type) {
                onMeasurementBeatDetected(type);
            }

            @Override
            public boolean onFileOpend() {
                return true;
            }

            @Override
            public boolean onFileClosed() {
                return true;
            }
        });
    }

    //----------------------------------------------------------------------------
    // BLE support
    private boolean mSvcConnected = false;
    private int mBleState = BLE_INIT;
    private int bleTimerCount = 0;

    private void bleTimerHandler() {
        onBleTimerExpire();

        if (mBleState == BLE_INIT || mBleState == BLE_DISCONNECTED) {
            bleTimerCount++;
        } else {
            bleTimerCount = 0;
        }
    }

    public boolean bleConnectDevice(String address) {
        if (address != null && address.length() > 0) {
            if (mLsBt != null) {
                mBleState = BLE_CONNECTING;
                mLsBt.connect(_ctx, address);
                return true;
            }
        }
        return false;
    }

    public void bleDisconnectDevice() {
        if (mLsBt != null) {
            mBleState = BLE_DISCONNECTING;
            mLsBt.disconnect();
        }
    }

    public boolean bleIsServiceConnected() {
        return mSvcConnected;
    }

    public int bleGetGattState() {
        return mBleState;
    }


    public void bleStartService(Context ctx) {
        if (ctx == null) {
            ctx = _ctx;
        }

        mLsBt = LsBluetooth.IGet();
        if (mLsBt == null) {
            onError(ERROR_BLUETOOTH_UNAVAILABLE);
            return;
        }

        if (mLsBt.IsBluetoothEnabled()) {
            mLsBt.startOnService(ctx, mOnBleServiceListener);
        }
    }

    public void bleStopService(Context ctx) {
        if (ctx == null) {
            ctx = _ctx;
        }

        if (mLsBt != null) {
            mLsBt.stopOnService(ctx);
        }
    }

    //=============================================================================
    //private BLEService.OnUartServiceListener mOnUartServiceListener = new BLEService.OnUartServiceListener() {
    public static int txSize = 0; // kim (지워야 하는거)

    private BLEManager.OnBleServiceListener mOnBleServiceListener = new BLEManager.OnBleServiceListener() {

        @Override
        public void onServiceConnected(boolean bInit) {
            if (!bInit) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                onError(ERROR_BLUETOOTH_UNAVAILABLE);
                return;
            }
            mSvcConnected = true;
            onBleServiceConnected();
        }

        @Override
        public void onServiceDisconnected() {
            mSvcConnected = false;
        }

        @Override
        public DeviceGatt onDeviceCreate(Context ctx, BluetoothDevice device) {
            return new SynesperGatt(ctx, device);
        }

        @Override
        public void onDeviceConnected() {
            Log.d(TAG, "onDeviceConnected() ----------");
        }

        @Override
        public void onDeviceDisconnected() {
            Log.d(TAG, "onDeviceDisconnected() ----------");

            mLsBt.close();
        }

        @Override
        public void onStatusChangeReceiver(String action) {
            //======================================
            if (action.equals(BLEManager.ACTION_GATT_CONNECTED)) {
                //String currentDateTimeString = DateFormat.getTimeInstance().format(new Date());
                Log.d(TAG, "GATT_CONNECT_MSG");
                mBleState = BLE_CONNECTED;
                onBleDeviceConnected();

                mBleData.init();
                pcmPlayerStart(PCMPlayer.PlayerMode.PLAYER_STREAM);
            }

            //======================================
            if (action.equals(BLEManager.ACTION_GATT_DISCONNECTED)) {
                String currentDateTimeString = DateFormat.getTimeInstance().format(new Date());
                Log.d(TAG, "GATT_DISCONNECT_MSG");
                mBleState = BLE_DISCONNECTED;
                onBleDeviceDisconnected();

                pcmPlayerStop(PCMPlayer.PlayerMode.PLAYER_STREAM);
            }

            //======================================
            if (action.equals(BLEManager.ACTION_GATT_SERVICES_DISCOVERED)) {
                //mLsBt.enableTXNotification();
            }

            //======================================
            if (action.equals(BLEManager.ACTION_DATA_AVAILABLE)) { }

            //======================================
            if (action.equals(BLEManager.DEVICE_DOES_NOT_SUPPORT_UART)){
                Toast.makeText(_ctx, "Device doesn't support UART. Disconnecting", Toast.LENGTH_SHORT).show();
                mLsBt.disconnect();
            }
        }

        //kim -> tx Data To .smd 파일에 write
        @Override
        public void onStatusChangeReceiverData(final byte[] txValue) {
            AppData ad = AppData.I();
            if(ad.BLE_RECEIVE_STATE_Profile == true)
                return;
            Log.i("kimmmmmmmmmmmmmm",ad.BLE_RECEIVE_STATE_Profile+"");
            try {
                //Log.d(TAG, "onStatusChangeReceiverData: len=" + txValue.length);
                if (txValue.length == PCG_PACKET_LENGTH) {
                    //Log.d(TAG, "VoBLE=" + txValue.length);
                    //mFileMgr.processVoBLEPacket(txValue);
                    short[] adpcmVoice = mBleData.decodeVoice(txValue); // kim (체크) -> TX 데이터 디코딩
                    mMeasMgr.processMeasurementVoice(txValue, adpcmVoice); // file write : Voice

                    short[] filteredVoice = mBleData.filterVoice(adpcmVoice);
                    pcmPlaying(filteredVoice, PCMPlayer.PlayerMode.PLAYER_STREAM);

                    onReceiverPcg(filteredVoice);
                } else  {
                    //Log.d(TAG, "PPG=" + txValue.length);
                    //Log.d(TAG, ByteArray.bytesToHex(txValue));
                    int[] ppgRaw = mBleData.decodePPG(txValue); // file write : PPG
                    if (ppgRaw[0] < 1000000) {
                        //Log.d(TAG, "PPG: out of range........");
                    }

                    BleData.FilteredData fd = mBleData.filterPPG(ppgRaw);
                    mMeasMgr.processMeasurementPPG(txValue, fd.ppgs);

                    onReceiverPpg(fd.ppgs, fd.min, fd.max);
                }
            } catch (Exception e) {
                Log.e(TAG, e.toString());
                Log.i("kim (file)",e.toString());
            }
        }
    };

    //------------------------------------------------------
    public static int writeCount = 0;//kim(수정) -> 삭제
    private void initSmdFilePlayer() {
        mSmdFilePlayer = new SmdFilePlayer(mPcmPlayer);
        mSmdFilePlayer.setOnSmdFilePlayerListener(new SmdFilePlayer.OnSmdFilePlayerListener() {
            @Override
            public void onPlay(SmdFilePlayer player, SmdFile.Header header) {
                writeCount = 0;
                Log.d(TAG, "SmdFile Play: date=" + header.getDateCreated());
                Log.i("kim","SmdFile play: data = "+header.getDateCreated());

                pcmPlayerStart(PCMPlayer.PlayerMode.PLAYER_FILE);
                onSmdFilePlayerChanged(SMDFILEPLAYER_PLAY, -1);
            }

            @Override
            public void onRead(SmdFilePlayer player, SmdFile.Chunk chunk) {
                onSmdFilePlayerChanged(SMDFILEPLAYER_READ, -1);
                short[] adpcmVoice = mBleData.decodeVoice(chunk.getData()); //kim (체크) -> ".smd" 파일로 부터 읽은 데이터 디코딩
                //Log.d(TAG, "SmdFilePlayer::onRead(), len=" + adpcmVoice.length);
                Log.d("kim", "SmdFilePlayer::onRead(), len=" + adpcmVoice.length);
                Log.i("kim","writeCount : "+(++writeCount));

                short[] filteredVoice = mBleData.filterVoice(adpcmVoice); //kim (체크) -> 디코딩 한 데이터 필터링
                // kim ( 23.04.18 수정) -> 만약 필터링을 안하면.... => 결과 : 필터링이랑 상관없는 듯 함...
                pcmPlaying(filteredVoice, PCMPlayer.PlayerMode.PLAYER_FILE);
            }

            /*
                Smd 파일 읽기가 완료되지 않은 상황에서 SmdFilePlayer가 중단되는 경우 호출
             */
            @Override
            public void onStop(SmdFilePlayer player) {
                Log.d(TAG, "SmdFile ------------------------ Stop");
            }

            /*
                Smd 파일의 읽기가 완료된 후 bSuccess=true와 함께 호출됨
                Smd 파일 읽기가 실패한 경우 bSuccess=false와 함께 호출됨
             */
            @Override
            public void onDone(SmdFilePlayer player, boolean bSuccess) {
                Log.d(TAG, "SmdFile ------------------------ Done");

                pcmPlayerAutoStop();
                onSmdFilePlayerChanged(SMDFILEPLAYER_DONE, -1);
            }
        });
    }

    private void closeSmdFilePlayer() {
        if (mSmdFilePlayer != null) {
            mSmdFilePlayer.stop();
            mSmdFilePlayer = null;
        }
    }

    public void smdFilePlayerStart(String filePath, int pos) {
        if (mSmdFilePlayer.isOpened()) {
            mSmdFilePlayer.stop();
        }

        Log.d(TAG, "smdFilePlayerStart: pos=" + pos);
        pcmPlayerForceStop();

        mCurSmdFile = pos;
        Log.i("kim_play","mSmdFilePlayer.play(filePath);");
        mSmdFilePlayer.play(filePath);
        Log.i("kim_play","mSmdFilePlayer.play(filePath); - end");

    }


    //kim (수정) -> 2023.04.19
//    public void smdFilePlayerStop() {
//        pcmPlayerStop(PCMPlayer.PlayerMode.PLAYER_FILE);
//        mSmdFilePlayer.stop();
//    }

    //kim (수정) -> 2023.04.19
    public void smdFilePlayerStop() {
        pcmPlayerStop(PCMPlayer.PlayerMode.PLAYER_FILE);
        if (mSmdFilePlayer != null) {
            mSmdFilePlayer.stop();
        }
    }


    public boolean isSmdFilePlayerPlaying() {
        return mSmdFilePlayer.isPlaying();
    }

    //------------------------------------------------------
    private void initPCMPlayer() {
        mPcmPlayer = new PCMPlayer();
        mPcmPlayer.clear();// kim(수정) : 삭제
        mPcmPlayer.setOnPCMPlayerListener(new PCMPlayer.OnPCMPlayerListener() {
            @Override
            public void onPlay() {
                Log.d(TAG, "audio track play");
            }

            @Override
            public void onWrite(byte[] pcmData, int result) {
                //Log.d(TAG, "audio track write: result=" + result);
            }

            @Override
            public void onStop() {
                Log.d(TAG, "audio track stop");

                if (mPcmPlayer.getPlayerMode() ==  PCMPlayer.PlayerMode.PLAYER_FILE) {
                    onSmdFilePlayerChanged(SMDFILEPLAYER_STOP, mCurSmdFile);
                }
            }
        });
    }

    public void pcmPlayerStart(PCMPlayer.PlayerMode mode) {
        Log.d(TAG, "pcmPlayerStart: " + mode);

        pcmPlayerForceStop();

        if (mode == PCMPlayer.PlayerMode.PLAYER_STREAM) {
            AppData ad = AppData.I();
            if (ad.mPrefVolumeOn) {
                mPcmPlayer.setPlayerMode(mode);
                mPcmPlayer.play(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, AUDIOTRACK_BUFFER_SIZE);
            }
        } else if (mode == PCMPlayer.PlayerMode.PLAYER_FILE){
            mPcmPlayer.setPlayerMode(mode);
            mPcmPlayer.play(16000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, AUDIOTRACK_BUFFER_SIZE);
        }
    }

    public void pcmPlayerForceStop() {
        mPcmPlayer.stop();
    }

    public void pcmPlayerStop(PCMPlayer.PlayerMode mode) {
        Log.d(TAG, "pcmPlayerStop: " + mode);

        if (mPcmPlayer.isPlaying()) {
            if (mode == mPcmPlayer.getPlayerMode()) {
                mPcmPlayer.stop();
                mPcmPlayer.setPlayerMode(PCMPlayer.PlayerMode.PLAYER_NONE);
            }
        }
    }


    //kim (수정)
    //    public void pcmPlaying(short[] pcmStream, PCMPlayer.PlayerMode mode) {
//        if (mode == PCMPlayer.PlayerMode.PLAYER_STREAM) {
//            AppData ad = AppData.I();
//            if (!ad.mPrefVolumeOn)
//                return;
//        }
////        mPcmPlayer.addPacket(pcmStream);
//        //kim (수정)
//        if (mPcmPlayer.isPlaying() && mPcmPlayer.getPlayerMode() == mode) {
//            short[] scale = new short[pcmStream.length];
//            int i;
//            for (i = 0 ; i<pcmStream.length ; i++) {
//                scale[i] = (short)(pcmStream[i]*PCM_SCALE);
//            }
//            mPcmPlayer.addPacket(scale);
//        }
//    }
    //kim (수정) : 2023.04.19
    public void pcmPlaying(short[] pcmStream, PCMPlayer.PlayerMode mode) {
        if (mPcmPlayer.getPlayerMode() != mode)
            return;

        if (mode == PCMPlayer.PlayerMode.PLAYER_STREAM) {
            AppData ad = AppData.I();
            if (!ad.mPrefVolumeOn || !mPcmPlayer.isPlaying())
                return;
        }

        short[] scale = new short[pcmStream.length];
        int i;
        for (i = 0 ; i<pcmStream.length ; i++) {
            scale[i] = (short)(pcmStream[i]*PCM_SCALE);
        }
        mPcmPlayer.addPacket(scale);
    }



    public void pcmPlayerAutoStop() {
        if (mPcmPlayer.isPlaying() && mPcmPlayer.getPlayerMode() == PCMPlayer.PlayerMode.PLAYER_FILE) {
            byte[] pkt = mPcmPlayer.getAutoStopPacket();
            mPcmPlayer.addPacket(pkt);
        }
    }
}
