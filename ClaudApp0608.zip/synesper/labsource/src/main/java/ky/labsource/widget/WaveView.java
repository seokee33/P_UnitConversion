package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import ky.labsource.R;


public class WaveView extends SurfaceView implements SurfaceHolder.Callback{
    private static final String TAG = "WAVV";

    private Context mContext;

	private float mDrawStep = 1.0f;
	private int mScrollPos = 0;

	private float mScaleV = 2.0f;

	private PlotThread plot_thread = null;

	// plot area size
	private int mWidth = 478;
	private int mHeight = 240;

	private Bitmap mWaveBitmap = null;
	private Canvas mWaveCanvas = null;

	private Bitmap mOverlayBitmap = null;
	private Canvas mOverlayCanvas = null;



	private Paint grid_paint = new Paint();
	private Paint cross_paint = new Paint();
	private Paint outline_paint = new Paint();

    private Paint mForePaint = new Paint();
    private Paint mEventPaint = new Paint();
    private Paint mClearPaint = new Paint();

    private Paint mOvlTextPaint = new Paint();


    // overlay
    public String mszTitle = "Speech";

    public float mOvlFontSize = 12;



	private void init(AttributeSet attrs, int defStyle) {
		TypedArray ta = getContext().obtainStyledAttributes(attrs, R.styleable.WaveView, 0, 0);
		try {
			int chartMode = ta.getInt(R.styleable.WaveView_chartMode, 0);
		} finally {
			ta.recycle();
		}
	}

	private void initGdiObject()
	{
		mForePaint.setStyle(Paint.Style.STROKE);
		mForePaint.setStrokeCap(Paint.Cap.ROUND);
        mForePaint.setStrokeWidth(3.f);
        mForePaint.setAntiAlias(true);
        mForePaint.setColor(Color.rgb(128, 255, 128));
        
        mEventPaint.setColor(Color.argb(0, 0, 0, 0));
        mEventPaint.setAntiAlias(true);
        
        mClearPaint.setColor(Color.argb(0, 0, 0, 0));
        mClearPaint.setXfermode(new PorterDuffXfermode(Mode.CLEAR));
        mClearPaint.setAntiAlias(true);

        // overlay
		mOvlTextPaint.setAntiAlias(true);
		mOvlTextPaint.setColor(Color.WHITE);
		mOvlTextPaint.setTextSize(DisplayUtils.PixelFromDP(mContext, mOvlFontSize));
        //mOvlTextPaint.setStrokeWidth(2.0f);
        //mOvlTextPaint.setStyle(Paint.Style.STROKE);
        //mOvlTextPaint.setShadowLayer(7.0f, 0.0f, 0.0f, Color.WHITE);


		grid_paint.setColor(Color.rgb(33, 66, 33));
		grid_paint.setAntiAlias(true);
		grid_paint.setStrokeWidth(3.f);
		cross_paint.setColor(Color.rgb(70, 100, 70));
		cross_paint.setAntiAlias(true);
		cross_paint.setStrokeWidth(3.f);
		outline_paint.setColor(Color.GREEN);
		outline_paint.setAntiAlias(true);
		outline_paint.setStrokeWidth(3.f);
	}
    
    private boolean createResources(int width, int height)
    {
    	mWaveBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    	mWaveCanvas = new Canvas();
    	mWaveCanvas.setBitmap(mWaveBitmap);

    	mOverlayBitmap = Bitmap.createBitmap(width, height, Config.ARGB_8888);
    	mOverlayCanvas = new Canvas();
    	mOverlayCanvas.setBitmap(mOverlayBitmap);

    	// draw initial overlay
		//drawTextToOverlay(mszLead + " " + mLeadNumber + "        5 mm/Div.", new Rect(10, 10, 0, 0), mOvlTextPaint);
		return true;
    }
    
    private void destroyResources()
    {
		mWaveBitmap = null;
		mWaveCanvas = null;

		mOverlayBitmap = null;
		mOverlayCanvas = null;
    }


    //--- Constructor ---------------------------------
	public WaveView(Context context) {
		super(context);

		mContext = context;

		initGdiObject();

		getHolder().addCallback(this);
	}

	public WaveView(Context context, AttributeSet attrs)
	{
		super(context, attrs);

		mContext = context;

		init(attrs, 0);
		initGdiObject();

		getHolder().addCallback(this);

		//plot_thread = new WaveformPlotThread(getHolder(), this);
	}

	public WaveView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);

		mContext = context;

		init(attrs, defStyle);
		initGdiObject();

		getHolder().addCallback(this);
	}



	private boolean mUpdating = false;
	private float[] mLastPos = null;
	
	public void updateWaveform(short[] updateData)
	{
		if (mUpdating)
			return;
		mUpdating = true;

		float[] lastPos = PlotPoints(mWaveCanvas, updateData, mLastPos);
		if (lastPos != null)
			mLastPos = lastPos;

		Canvas c = null;
		SurfaceHolder surfaceHolder = getHolder();
		try{
			c = surfaceHolder.lockCanvas(null);
			synchronized (surfaceHolder) {
				DrawWaveform(c);
			}
		} finally {
			if(c!=null){
				surfaceHolder.unlockCanvasAndPost(c);
			}
		}

		mUpdating = false;
	}

	public void setOverlayTextSize(float size)
	{
		mOvlFontSize = size;
		mOvlTextPaint.setTextSize(mOvlFontSize);
	}

	public void drawTextToOverlay(String text, Rect rcDraw, Paint drwPaint)
	{
		if (mOverlayCanvas == null)
			return;

		if (drwPaint == null)
			drwPaint = mOvlTextPaint;

		Rect rcBound = new Rect();
		mOvlTextPaint.getTextBounds(text, 0, text.length(), rcBound);
		rcDraw.set(rcDraw.left, rcDraw.top, rcDraw.left + rcBound.left + rcBound.width(), rcDraw.top + rcBound.height());

		Rect rcErase = new Rect();
		rcErase.set(rcDraw.left - 10, rcDraw.top - 10, rcDraw.right + 10, rcDraw.bottom + 10);
		mOverlayCanvas.drawRect(rcErase, mClearPaint);

		mOverlayCanvas.drawText(text, rcDraw.left, rcDraw.top - rcBound.top, drwPaint);
	}

	public void DrawSpeechInfo(int sampleRate, long duration)
	{
		float h = DisplayUtils.PixelFromDP(mContext, mOvlFontSize);

		drawTextToOverlay("SampleRate: " + sampleRate, new Rect(10, 10, 0, 0), null);

		int totalMilliSec = (int)(duration / 1000);
		int totalSec = (int)(totalMilliSec / 1000);
		int min = (int) totalSec / 60;
		int sec = totalSec % 60;
		int milliSec = totalMilliSec % 1000;
		drawTextToOverlay("Duration: " + String.format("%02d:%02d", min, sec) + "." + milliSec, new Rect(10, 10 + (int) h + 8, 0, 0), null);
	}

	public void clearWaveDraw() {
		mLastPos = null;
	}

	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width, int height)
	{
		mWidth = width;
		mHeight = height;
		Log.v(TAG, "surfaceChanged() [" + mszTitle + "]: W=" + mWidth + ", H=" + mHeight);

		createResources(mWidth, mHeight);
	}
	
	@Override
	public void surfaceCreated(SurfaceHolder holder)
	{
		Log.v(TAG, "surfaceCreated() [" + mszTitle + "]");

		if (plot_thread != null) {
			Log.v(TAG, "WaveformPlotThread.setRunning():" + true);
			plot_thread.setRunning(true);
			plot_thread.start();
		}
	}
	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{
		Log.v(TAG, "surfaceDestroyed()");

		if (plot_thread != null) {
			boolean retry = true;
			plot_thread.setRunning(false);
			while (retry){
				try{
					plot_thread.join();
					retry = false;
				}catch(InterruptedException e){
					
				}
			}
		}

		destroyResources();
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

		int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		int heightMode = MeasureSpec.getMode(heightMeasureSpec);

		//int width = (int)getDip(10);
		//int height = (int)getDip(10);
		//int width = mWidthCol1 + 200;
		//int height = mHeightRow1 + mHeightRow2 + mHeightTemp + mHeightHumid + mHeightIlluminance;
		int width = mWidth;
		int height = mHeight;

		switch (widthMode) {
			case MeasureSpec.UNSPECIFIED: // unspecified
				width = widthMeasureSpec;
				break;
			case MeasureSpec.AT_MOST:  // wrap_content
				break;
			case MeasureSpec.EXACTLY:  // match_parent
				width = MeasureSpec.getSize(widthMeasureSpec);
				break;
		}

		switch (heightMode) {
			case MeasureSpec.UNSPECIFIED: // unspecified
				height = heightMeasureSpec;
				break;
			case MeasureSpec.AT_MOST:  // wrap_content
				break;
			case MeasureSpec.EXACTLY:  // match_parent
				height = MeasureSpec.getSize(heightMeasureSpec);
				break;
		}

		setMeasuredDimension(width, height);

		mWidth = width;
		mHeight = height;
	}

	@Override
	public void onDraw(Canvas canvas) {
		Log.v(TAG, "onDraw(): Canvas.W=" + canvas.getWidth() + ", Canvas.H=" + canvas.getHeight());

		if (mWaveBitmap == null || mOverlayBitmap == null)
			createResources(mWidth, mHeight);

		DrawWaveform(canvas);
	}

	private void DrawWaveform(Canvas canvas)
	{
		if (canvas == null)
			return;

		// clear screen
		canvas.drawColor(Color.rgb(20, 20, 20));
		
		DrawGrid(canvas);

		if (mWaveBitmap != null)
		{
			canvas.drawBitmap(mWaveBitmap, 0, 0, null);
		}
		if (mOverlayBitmap != null)
		{
			canvas.drawBitmap(mOverlayBitmap, 0, 0, null);
		}

		DrawBorder(canvas);
	}

	private void DrawGrid(Canvas canvas)
	{
		// draw vertical grids
	    //for(int vertical = 1; vertical<10; vertical++){
	    //	canvas.drawLine(vertical*(mWidth/10)+1, 1, vertical*(mWidth/10)+1, mHeight+1, grid_paint);
	    //}
	    // draw horizontal grids
	    float vCenter = mHeight / 2.0f;
		float vStep = mHeight / 5.0f;
		float vDiff = vStep;
		canvas.drawLine(1, vCenter, mWidth+1, vCenter, grid_paint);
		while(vDiff < (float) vCenter)
		{
	    	canvas.drawLine(1, vCenter+vDiff, mWidth+1, vCenter+vDiff, grid_paint);
			canvas.drawLine(1, vCenter-vDiff, mWidth+1, vCenter-vDiff, grid_paint);
	    	vDiff += vStep;
		}
		//for(int horizontal = 1; horizontal<10; horizontal++){
	    //	canvas.drawLine(1, horizontal*(mHeight/10)+1, mWidth+1, horizontal*(mHeight/10)+1, grid_paint);
	    //}
	}
	
	private void DrawBorder(Canvas canvas)
	{
	    // draw outline
 		canvas.drawLine(0, 0, mWidth-1, 0, outline_paint);	// top
 		canvas.drawLine(mWidth-1, 0, mWidth-1, mHeight-1, outline_paint); //right
 		canvas.drawLine(0, mHeight-1, mWidth-1, mHeight-1, outline_paint); // bottom
 		canvas.drawLine(0, 0, 0, mHeight-1, outline_paint); //left
	}

	private static final int mDrawSpace = 30;

	private float CalcYDrawPoint(float value)
	{
		float newValue = value * mHeight/(float)(Short.MAX_VALUE - Short.MIN_VALUE);
		newValue *= mScaleV;
		newValue = mHeight/2.0f - newValue;
		return newValue;
	}

	public void setupParameter(int samplesCount)
	{
		if (samplesCount > mWidth)
			mDrawStep = mWidth/(float)samplesCount;
		else
			mDrawStep = 1.0f;
	}

	public float[] PlotPoints(Canvas canvas, short[] drawData, float[] sPos)
	{
        if (canvas == null || drawData == null)
            return null;
        if (drawData.length == 0)
        	return null;

		int samplesLength = drawData.length;

        float[] lastPos = new float[2];
        final Path drwPath = new Path();
        
        double samp = 0.;
        int preSamp = 0;
        boolean bClearAll = false;

        float drwPos = 0;
        float drwValue = 0.f;
        if (sPos != null)
        {
        	drwPos = (int)sPos[0];
        	drwValue = sPos[1];
    		preSamp = -1;
        }
        else
        {
        	drwPos = 0;
        	drwValue = CalcYDrawPoint(drawData[0]);
    		preSamp = 0;
    		bClearAll = true;
        }

		drwPath.moveTo((float)drwPos, drwValue);

		lastPos[0] = (float)drwPos;
		lastPos[1] = drwValue;
		
		int l = (int) drwPos;
		int r = (int) drwPos;

        while (true)
        {
//        	samp += mDrawStep;
//        	drwPos++;
			samp++;
			drwPos += mDrawStep;

        	int curSamp = (int)(samp+0.5);
        	if (curSamp >= samplesLength)
        		break;

        	if (curSamp == preSamp)
        		continue;

        	drwValue = CalcYDrawPoint(drawData[curSamp]);
       		drwPath.lineTo((float)drwPos, drwValue);
       		lastPos[0] = (float)drwPos;
    		lastPos[1] = drwValue;
    		r = (int) drwPos;

        	preSamp = curSamp;

        	if (drwPos >= mWidth)
        	{
        		drwPos = 0;
           		drwPath.moveTo((float)drwPos, drwValue);
           		lastPos[0] = (float)drwPos;
        		lastPos[1] = drwValue;
        		r = (int)drwPos;
        	}
        }

        if (bClearAll)
        {
        	canvas.drawRect(0, 0, mWidth, mHeight, mClearPaint);
        }
        else
        {
	        if (l > r)
	        {
	        	canvas.drawRect(l, 0, mWidth, mHeight, mClearPaint);
	        	canvas.drawRect(0, 0, r+mDrawSpace, mHeight, mClearPaint);
	        }
	        else
	        {
	        	canvas.drawRect(l, 0, r+mDrawSpace, mHeight, mClearPaint);
	        }
        }
        
        canvas.drawPath(drwPath, mForePaint);
        return lastPos;
	}


	public class PlotThread extends Thread {
		private SurfaceHolder holder;
		private WaveView plot_area;
		private boolean _run = false;

		public PlotThread(SurfaceHolder surfaceHolder, WaveView view){
			holder = surfaceHolder;
			plot_area = view;
		}

		public void setRunning(boolean run){
			_run = run;
		}

		@Override
		public void run(){
			Canvas c;
			while(_run){
				c = null;
				try{
					c = holder.lockCanvas(null);
					synchronized (holder) {
						plot_area.PlotPoints(c, null, null);
					}
				}finally{
					if(c!=null){
						holder.unlockCanvasAndPost(c);
					}
				}
			}
		}
	}
}
