package kr.claud.synesper.common;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

import kr.claud.synesper.dialog.DialogUtil;
import ky.labsource.LsBluetooth;
import ky.labsource.LsRequest;

public class ServiceCheckList {
    public static final String TAG = "ServiceCheckList";

    private static final int PERMISSION_REQUEST_UNDEF = LsRequest.PERMISSION_REQUEST_UNDEF;
    private static final int PERMISSION_REQUEST_LOCATION = 101;
    private static final int PERMISSION_REQUEST_BLUETOOTHS = 102;
    private static final int PERMISSION_REQUEST_CAMERA = 103;
    private static final int PERMISSION_REQUEST_EXTERNAL = 104;

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_TURN_ON_LOCATION_RESULT = 2;

    //-------------------------------------------------
    // interface
    public interface OnServiceCheckListener {
        void onCheck(String checkType, boolean bState);
        void onReady(boolean bReady);
    }
    private OnServiceCheckListener mOnServiceCheckListener = null;
    public void setOnServiceCheckListener(OnServiceCheckListener l) {
        mOnServiceCheckListener = l;
    }


    private interface CheckListCallbacks {
        boolean request();
        void activityResult(int requestCode, int resultCode, @Nullable Intent data);
        boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults);
    }

    private class CheckList implements CheckListCallbacks {
        private Boolean done;
        private CheckList nextCheck;
        private int reqCodeEnable;
        private int reqCodePermission;

        CheckList() {
            this.done = null;
            this.nextCheck = null;

            this.reqCodeEnable = PERMISSION_REQUEST_UNDEF;
            this.reqCodePermission = PERMISSION_REQUEST_UNDEF;
        }

        CheckList(Boolean bDone) {
            this.done = bDone;
            this.nextCheck = null;

            this.reqCodeEnable = PERMISSION_REQUEST_UNDEF;
            this.reqCodePermission = PERMISSION_REQUEST_UNDEF;
        }

        CheckList(int reqEnable, int reqCodePermission) {
            this.done = null;
            this.nextCheck = null;

            this.reqCodeEnable = reqEnable;
            this.reqCodePermission = reqCodePermission;
        }

        CheckList(int reqEnable, int reqCodePermission, Boolean bDone) {
            this.done = bDone;
            this.nextCheck = null;

            this.reqCodeEnable = reqEnable;
            this.reqCodePermission = reqCodePermission;
        }

        public Boolean getDone() {
            return done;
        }

        public int getReqCodeEnable() {
            return reqCodeEnable;
        }

        public int getReqCodePermission() {
            return reqCodePermission;
        }

        @Override
        public boolean request() {
            return false;
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) {}

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            for (int gr : grantResults) {
                if (gr == PackageManager.PERMISSION_DENIED)
                    return false;
            }
            return true;
        }


        public void setNextCheck(@NonNull CheckList nextCheck) {
            this.nextCheck = nextCheck;
        }
    }

    private Activity _acty = null;
    private Handler _handler = null;

    private ArrayList<CheckList> _chkServices = null;

    private CheckList _startupCheck = new CheckList(true);
    private CheckList _finishCheck = new CheckList() {
        @Override
        public boolean request() {
            if (mOnServiceCheckListener != null) {
                mOnServiceCheckListener.onReady(getDone());
            }
            return true; // !!! Absolutely true, Important for finishing
        }
    };

    //-------------------------------------------------
    // Constructor
    public ServiceCheckList(Activity acty) {
        this._acty = acty;
        this._handler = new Handler();
        this._chkServices = new ArrayList<>();
    }

    public void addCheckList(CheckList chkList) {
        if (_chkServices.size() == 0) {
            _chkServices.add(_startupCheck);
        }
        _chkServices.get(_chkServices.size() - 1).setNextCheck(chkList);
        _chkServices.add(chkList);
    }

    public void check(OnServiceCheckListener l) {
        setOnServiceCheckListener(l);

        _chkServices.clear();

        addCheckList(checkLocation);
        addCheckList(checkBluetooth);
        addCheckList(checkCamera);
        addCheckList(checkExternal);

        checkStateChanged(_startupCheck);
    }

    public boolean activityResult(int requestCode, int resultCode, @Nullable Intent data) {
        for (CheckList chklst : _chkServices) {
            if (requestCode == chklst.getReqCodeEnable()) {
                chklst.activityResult(requestCode, resultCode, data);
                break;
            }
        }
        /*
        switch (requestCode) {
            case REQUEST_TURN_ON_LOCATION_RESULT:
                checkLocation.activityResult(requestCode, resultCode, data);
                break;

            case REQUEST_ENABLE_BT:
                checkBluetooth.activityResult(requestCode, resultCode, data);
                break;
        }
        */
        return true;
    }

    public boolean requestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        boolean bRet = false;
        for (CheckList chklst : _chkServices) {
            if (requestCode == chklst.getReqCodePermission()) {
                chklst.permissionsResult(requestCode, permissions, grantResults);
                bRet = true;
                break;
            }
        }
/*
        boolean bRet = true;
        if (requestCode == PERMISSION_REQUEST_LOCATION) {
            checkLocation.permissionsResult(requestCode, permissions, grantResults);
        } else if (requestCode == PERMISSION_REQUEST_BLUETOOTHS) {
            checkBluetooth.permissionsResult(requestCode, permissions, grantResults);
        } else if (requestCode == PERMISSION_REQUEST_CAMERA) {
            checkCamera.permissionsResult(requestCode, permissions, grantResults);
        } else if (requestCode == PERMISSION_REQUEST_EXTERNAL) {
            checkExternal.permissionsResult(requestCode, permissions, grantResults);
        } else {
            bRet = false;
        }
 */
        return bRet;
    }

    //----------------------------------------------
    private void setCheckResult(@NonNull CheckList chkList, Boolean bDone) {
        chkList.done = bDone;
        checkStateChanged(chkList);
    }

    private void checkStateChanged(@NonNull CheckList chkList) {
        if (chkList == _finishCheck)
            return;

        CheckList nextChk = null;
        if (chkList.done != null) {
            if (chkList.done) {
                nextChk = chkList.nextCheck;
                if (nextChk == null) {
                    nextChk = _finishCheck;
                    nextChk.done = true;
                }
            } else {
                nextChk = _finishCheck;
                nextChk.done = false;
            }
        }

        if (nextChk != null) {
            CheckList finalNextChk = nextChk;
            _handler.post(new Runnable() {
                @Override
                public void run() {
                    if (!finalNextChk.request()) {
                        setCheckResult(finalNextChk, true);
                    }
                }
            });
        }
    }


    //-------------------------------------------------------------------------
    // 1. Location
    private LocationManager locationManager;
    private boolean isGPSEnabled;
    private boolean isNetworkEnabled;


    private void checkLocationProvider(CheckList chkList)
    {
        locationManager = ((LocationManager)_acty.getApplicationContext().getSystemService(Context.LOCATION_SERVICE));
        if (locationManager != null) {
            isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } else {
            isGPSEnabled = false;
            isNetworkEnabled = false;
        }

        Log.d(TAG, "GPS=" + isGPSEnabled + ", Network=" + isNetworkEnabled);
        if ((!isGPSEnabled) && (!isNetworkEnabled))
        {
            if (mOnServiceCheckListener != null) {
                mOnServiceCheckListener.onCheck("Location", false);
            }
            Log.d(TAG, "No Location Provider Available");

            DialogUtil.showTurnOnLocation(_acty, new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialogInterface, int which)
                {
                    if (which == DialogInterface.BUTTON_POSITIVE) {
                        LsRequest.Action.SETTINGS_LOCATION_SOURCE(_acty, chkList.getReqCodeEnable());
                    } else if (which == DialogInterface.BUTTON_NEGATIVE) {
                        dialogInterface.cancel();
                        Toast.makeText(_acty, "Please Turn On Location!!!", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
        else
        {
            if (mOnServiceCheckListener != null) {
                mOnServiceCheckListener.onCheck("Location", true);
            }

            if (LsRequest.Permission.ACCESS_FINE_LOCATION_IF(_acty, chkList.getReqCodePermission())) {
                setCheckResult(chkList, true);
            }
        }
    }


    private CheckList checkLocation = new CheckList(REQUEST_TURN_ON_LOCATION_RESULT, PERMISSION_REQUEST_LOCATION) {
        @Override
        public boolean request() {
            checkLocationProvider(this);
            return true;
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) {
            locationManager = (LocationManager)_acty.getApplicationContext().getSystemService(Context.LOCATION_SERVICE);
            if (locationManager != null) {
                isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
                isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
            } else {
                isGPSEnabled = false;
                isNetworkEnabled = false;
            }

            if (!isGPSEnabled && !isNetworkEnabled) {
                Toast.makeText(_acty.getApplicationContext(), "Please Turn On Location!!!", Toast.LENGTH_LONG).show();
                setCheckResult(this, false);
            } else {
                if (LsRequest.Permission.ACCESS_FINE_LOCATION_IF(_acty, getReqCodePermission())) {
                    setCheckResult(this, true);
                }
            }
        }

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            boolean bpr = super.permissionsResult(requestCode, permissions, grantResults);
            if (!bpr) {
                // Permission was denied or request was cancelled
                Toast.makeText(_acty, "Permission denied !!!", Toast.LENGTH_SHORT).show();
/*
                Snackbar.make(mLayout, "퍼미션이 거부되어 앱이 종료됩니다.", Snackbar.LENGTH_INDEFINITE).setAction("확인", new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {
                        finishFwrApp();
                    }
                }).show();
 */
            }
            setCheckResult(this, bpr);
            return bpr;
        }
    };

    //-------------------------------------------------------------------------
    // 2. Bluetooth
    private CheckList checkBluetooth = new CheckList(REQUEST_ENABLE_BT, PERMISSION_REQUEST_BLUETOOTHS) {
        @Override
        public boolean request() {
            Boolean bDone = false;
            LsBluetooth lsBt = LsBluetooth.CREATE(_acty, true, getReqCodeEnable());
            if (lsBt != null) {
                //Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                //Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                if (!LsRequest.Permission.BLUETOOTH_ALL_IF(_acty, getReqCodePermission())) {
                    return true;
                }
                if (!lsBt.IsBluetoothEnabled())
                    return true;

                bDone = true;
            }
            setCheckResult(this, bDone);
            return true;
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(_acty, "Bluetooth has turned on ", Toast.LENGTH_SHORT).show();
                if (LsRequest.Permission.BLUETOOTH_ALL_IF(_acty, getReqCodePermission())) {
                    setCheckResult(this, true);
                }
            } else {
                // User did not enable Bluetooth or an error occurred
                Log.d(TAG, "BT not enabled");
                Toast.makeText(_acty.getApplicationContext(), "Problem in BT Turning ON ", Toast.LENGTH_SHORT).show();
                setCheckResult(this, false);
            }
        }

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            // If request is cancelled, the result arrays are empty.
            boolean bpr = super.permissionsResult(requestCode, permissions, grantResults);

            if (bpr && LsBluetooth.IGet().IsBluetoothEnabled()) {
                Toast.makeText(_acty, "Bluetooth Permissions granted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(_acty, "Permissions must be granted", Toast.LENGTH_SHORT).show();
                bpr = false;
            }
            setCheckResult(this, bpr);
            return bpr;
        }
    };

    //-------------------------------------------------------------------------
    // 3. Camera
    private CheckList checkCamera = new CheckList(PERMISSION_REQUEST_UNDEF, PERMISSION_REQUEST_CAMERA) {
        @Override
        public boolean request() {
            super.request();

            if (LsRequest.Permission.CAMERA_IF(_acty, getReqCodePermission())) {
                setCheckResult(this, true);
            }
            return true;
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) { }

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            boolean bpr = super.permissionsResult(requestCode, permissions, grantResults);
            Log.d(TAG, "permissionsResult(): CAMERA - " + bpr);
            setCheckResult(this, bpr);
            return bpr;
        }
    };

    //-------------------------------------------------------------------------
    // 4. External
    private CheckList checkExternal = new CheckList(PERMISSION_REQUEST_UNDEF, PERMISSION_REQUEST_EXTERNAL) {
        @Override
        public boolean request() {
            super.request();

            if (LsRequest.Permission.EXTERNAL_STORAGE_IF(_acty, getReqCodePermission())) {
                setCheckResult(this, true);
            }
            return true;
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) { }

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            boolean bpr = super.permissionsResult(requestCode, permissions, grantResults);
            Log.d(TAG, "permissionsResult(): EXTERNAL - " + bpr);
            setCheckResult(this, bpr);
            return bpr;
        }
    };

    //-----------------------------------------------------------------
    // Template
    private CheckList checkTemplate = new CheckList() {
        @Override
        public boolean request() {
            return super.request();
        }

        @Override
        public void activityResult(int requestCode, int resultCode, @Nullable Intent data) { }

        @Override
        public boolean permissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) { return true; }
    };
}
