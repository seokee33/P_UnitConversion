package kr.claud.synesper;

import static kr.claud.libs.api.OkHttpClientProvider.cookieJar;
import static kr.claud.libs.api.RetrofitBuilderProvider.web;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.ms.api.login.Login;
import kr.claud.libs.crypto.AES256Chiper;
import kr.claud.libs.enums.KeySize;
import kr.claud.synesper.common.ServiceCheckList;
import kr.claud.synesper.dialog.DialogUtil;
import ky.labsource.LsBluetooth;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserActivity extends AppCompatActivity {

    public static final String TAG = "UserActivity";

    public static final int RESULT_REGISTER_OK = Activity.RESULT_FIRST_USER + 1;
    public static final int RESULT_LOGIN_OK = Activity.RESULT_FIRST_USER + 2;
    public static final int RESULT_REGISTER_START = Activity.RESULT_FIRST_USER + 3;


    private static final int PERMISSION_REQUEST_LOCATION = 101;
    private static final int PERMISSION_REQUEST_BLUETOOTHS = 102;

    private static final int REQUEST_SELECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int REQUEST_TURN_ON_LOCATION_RESULT = 3;

    private static final int UI_STARTACTIVITY_DELAY = 3000;

    ServiceCheckList svcCheck;

    private Button mButtonStart;
    private Button mButtonRegister;
    private Button mButtonLogin;

    ActivityResultLauncher<Intent> startActivityResult = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    int resultCode = result.getResultCode();
                    if (resultCode == RESULT_LOGIN_OK) {
                        //Log.d(TAG, "MainActivity로 돌아왔다. ");
                        startNext();
                    } else if (resultCode == RESULT_REGISTER_OK) {
                        startLoginActivity();
                    } else if (resultCode == RESULT_REGISTER_START) {
                        startRegisterActivity();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        initButtonListener();

        svcCheck = new ServiceCheckList(this);
        svcCheck.check(new ServiceCheckList.OnServiceCheckListener() {
            @Override
            public void onCheck(String checkType, boolean bState) {

            }

            @Override
            public void onReady(boolean bReady) {
                if (bReady) {
                    readyUserActivity();
                } else {
                    finish();
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //----------------
        //if (LsRequest.doActivityResult(requestCode, resultCode, data))
        //    return;
        //----------------

        svcCheck.activityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (!svcCheck.requestPermissionsResult(requestCode, permissions, grantResults)) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    private void initButtonListener() {
        mButtonStart = (Button) findViewById(R.id.buttonStart);
        mButtonStart.setEnabled(false);
        mButtonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LsBluetooth lsBt = LsBluetooth.IGet(); //블루투스 활성화

                AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
                if (lsBt != null && lsBt.IsBluetoothEnabled()) {
                    AppData ad = AppData.I();

                    //Network Check
                    int stateNetwork = ad.getNetworkInfo(UserActivity.this);
                    if(stateNetwork >=3){
                        DialogUtil.showDialogMessage(UserActivity.this, "인터넷 연결 문제", "데이터 및 와이파이를 확인해주세요", null);
                        return;
                    }
                    // AutoLogin Check : (true)-> try Login or (false) -> Switch Register page screen
                    if (ad.mAutoLogin) {
                        String userName = ad.mPrefUserName;
                        String passwd = ad.mPrefPasswd;
                        String passwdAESDecry;
                        try {
                            passwdAESDecry = aes.AES_Decode(passwd);
                        } catch (UnsupportedEncodingException | NoSuchPaddingException |
                                 NoSuchAlgorithmException | IllegalBlockSizeException |
                                 BadPaddingException | InvalidKeyException |
                                 InvalidAlgorithmParameterException e) {
                            throw new RuntimeException(e);
                        }
                        Log.d(TAG, "name=" + userName + ", passwd=" + passwdAESDecry);
                        if(!userName.equals("") || !passwd.equals("")){
                            Login.login(userName, passwdAESDecry, new Callback<ResponseBody>() {
                                @Override
                                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                                    if(response.isSuccessful()){
                                        if(response.code() == 200){
                                            try {
                                                List<Cookie> cookies = new ArrayList<>();
                                                List<String> cookieHeaders = response.headers().values("Set-Cookie");
                                                for (String cookieHeader : cookieHeaders) {
                                                    Cookie cookie = Cookie.parse(HttpUrl.parse(web), cookieHeader);
                                                    cookies.add(cookie);
                                                }
                                                cookieJar.saveFromResponse(HttpUrl.parse(web), cookies);

                                                String jsonString = response.body().string();
                                                JSONObject jsonObject = new JSONObject(jsonString);
                                                String name = jsonObject.get("name").toString();
                                                String num = jsonObject.get("accountId").toString();
                                                String email = jsonObject.get("email").toString();
                                                String delivery = jsonObject.get("delivery").toString();
                                                AppData ad = AppData.I();
                                                ad.login(userName,passwd);
                                                ad.mSqliteDB.changeLoginUserUpdate(num,userName,passwd,name,delivery,email);


                                                if (ad.mPrefDeviceName != null){
                                                    Login.updateDeviceSerialNumber(ad.mPrefDeviceName, new Callback<ResponseBody>() {
                                                        @Override
                                                        public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                                            if(response.isSuccessful()){
                                                                Log.i("kimmmmmmmm","성공");
                                                            }
                                                        }

                                                        @Override
                                                        public void onFailure(Call<ResponseBody> call, Throwable t) {
                                                            Toast.makeText(getApplication(),"기기등록을 실패했습니다.\n설정에서 기기를 다시 등록해주세요.",Toast.LENGTH_SHORT);
                                                        }
                                                    });
                                                }


                                                startNext();
                                            } catch (JSONException | IOException e) {
                                                throw new RuntimeException(e);
                                            }

                                        }else if(response.code()==400){
                                            Log.i("kim(UserAtivity code)","400번");
                                            DialogUtil.showDialogMessage(UserActivity.this, "아이디 및 비밀번호를 확인해주세요.", "아이디 및 비밀번호를 확인해주세요.", null);
                                        }else{
                                            Log.i("kim(UserAtivity code)","500번");
                                            DialogUtil.showDialogMessage(UserActivity.this, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                                        }
                                    }
                                }

                                @Override
                                public void onFailure(Call<ResponseBody> call, Throwable t) {
                                    DialogUtil.showDialogMessage(UserActivity.this, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                                }
                            });
                        }else{
                            startLoginActivity();
                        }
                    } else {
                        startLoginActivity();
                    }
                }
            }
        });

        mButtonRegister = (Button) findViewById(R.id.buttonRegister);
        mButtonRegister.setEnabled(false);
        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LsBluetooth lsBt = LsBluetooth.IGet();
                if (lsBt != null && lsBt.IsBluetoothEnabled())
                    startRegisterActivity();
            }
        });

        mButtonLogin = (Button) findViewById(R.id.buttonLogin);
        mButtonLogin.setEnabled(false);
        mButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LsBluetooth lsBt = LsBluetooth.IGet();
                if (lsBt != null && lsBt.IsBluetoothEnabled())
                    startLoginActivity();
            }
        });
    }

    private void readyUserActivity() {
        mButtonStart.setEnabled(true);
        mButtonRegister.setEnabled(true);
        mButtonLogin.setEnabled(true);
    }

    private void startNext() {
        AppData ad = AppData.I();
        Intent intent = new Intent(UserActivity.this, (ad.mAppRunFirst) ? ExplanationActivity.class : MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void startRegisterActivity() {
        Intent intent = new Intent(UserActivity.this, RegisterActivity.class);
        startActivityResult.launch(intent);
    }

    private void startLoginActivity() {
        Intent intent = new Intent(UserActivity.this, LoginActivity.class);
        startActivityResult.launch(intent);
    }
}