package kr.claud.libs.enums;

import android.graphics.Color;

import java.util.Calendar;

public enum WeekDay {
    SUN("Sunday",    "Sun", Color.RED),    // 1
    MON("Monday",    "Mon", Color.DKGRAY),  // 2
    TUE("Tuesday",   "Tue", Color.DKGRAY),  // 3
    WED("Wednesday", "Wed", Color.DKGRAY),  // 4
    THU("Thursday",  "Thu", Color.DKGRAY),  // 5
    FRI("Friday",    "Fri", Color.DKGRAY),  // 6
    SAT("Saturday",  "Sat", Color.BLUE);   // 7


    private String fullName;
    private String shortName;
    private int color;

    WeekDay(String fullName, String shortName, int color) {
        this.fullName = fullName;
        this.shortName = shortName;
        this.color = color;
    }

    public String getFullName() {
        return fullName;
    }

    public String getShortName() {
        return shortName;
    }

    public int getColor() {
        return color;
    }

    // 1(SUNDAY), 2, ..., 7(SATURDAY)
    public static WeekDay fromIndex(int idx) {
        return WeekDay.values()[(idx-1+7)%7];
    }

    public static WeekDay fromDate(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK); // 1(SUNDAY), 2, ..., 7(SATURDAY)
        if (dayOfWeek < 0) {
            dayOfWeek += 7;
        }
        return fromIndex(dayOfWeek);
    }
}
