package kr.claud.synesper.media;


import static java.lang.System.arraycopy;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;


/*
  C:\Users\pysik\AppData\Local\Google\AndroidStudio2021.2\device-explorer\pixel_5_-_api_31 [emulator-5554]\sdcard\Android\data\kr.claud.synesper\files


<<< Synesper Media Data(smd) >>>

  File format
-------------------------------------------------
Identity:
  (16)'SMD File' + EOF

Header:
  (4)length
  (4)created date : Year - short(2), Month - byte(1), Day - byte(1)
  (32)user name
  (2)week
  (4)delivery date

Chunk:
  (4)length
  (1)type - pcg(voice) or ppg
  (1)bpm
  (4)sequence
  (4)timestamp (msec)

  signal data
*/
public class SmdFile {
    public static final String TAG = "SmdFile";
    public static final String CACHE_FILENAME = "synsper_smd.tmp";

    public enum ChunkType {
        PPG((byte)0),
        PCG((byte)1);

        private byte idx;

        ChunkType(byte idx) {
            this.idx = idx;
        }

        public byte getIndex() {
            return idx;
        }
    }

    //------------------------------------------------
    // Data
    public static final String _idStr = "SMD File";

    public static String stringSmdFileName(Date date) {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(date);
        return "dat_" + timeStamp + ".smd";
    }

    public static class Header {
        public static int header_length = 64;  //4 + 16 + 32 + 1 + 4 + 7
        public static String DATE_FORMAT = "yyyyMMdd_HHmmss";

        byte[] length;       // 4
        byte[] dateCreated;  // 16 yyyyMMdd_HHmmss
        byte[] userName;     // 32
        byte   week;         // 1
        byte[] dateDelivery; // 4
        byte[] resered;      // 7

        public Header(Date dateCreated, String userName, int week, Date dateDelivery) {
            int len = header_length;
            ByteBuffer bb = ByteBuffer.allocate(4);
            bb.putInt(len);
            this.length = new byte[4];
            arraycopy(bb.array(), 0, this.length, 0, 4);

            byte[] szCreated = new SimpleDateFormat(DATE_FORMAT).format(dateCreated).getBytes(StandardCharsets.UTF_8);
            this.dateCreated = new byte[16];
            arraycopy(szCreated, 0, this.dateCreated, 0, szCreated.length);

            this.dateDelivery = dateToByteArray(dateDelivery);

            this.userName = new byte[32];
            byte[] str = userName.getBytes(StandardCharsets.UTF_8);
            arraycopy(str, 0, this.userName, 0, str.length);
            this.userName[str.length] = '\0';

            this.week = (byte) week;

            this.resered = new byte[7];
        }

        public Header(byte[] rbuf) {
            this.length = new byte[4];
            this.dateCreated = new byte[16];
            this.userName = new byte[32];
            this.dateDelivery = new byte[4];
            this.resered = new byte[7];

            put(rbuf);
        }


        public byte[] get() {
            byte[] wbuf = new byte[header_length];
            arraycopy(this.length, 0, wbuf, 0, 4);
            arraycopy(this.dateCreated, 0, wbuf, 4, 16);
            arraycopy(this.userName, 0, wbuf, 20, 32);
            wbuf[52] = this.week;
            arraycopy(this.dateDelivery, 0, wbuf, 53, 4);
            //arraycopy(this.resered, 0, wbuf, 57, 7);
            return wbuf;
        }

        public void put(byte[] rbuf) {
            arraycopy(rbuf, 0, this.length, 0, 4);
            arraycopy(rbuf, 4, this.dateCreated, 0, 16);
            arraycopy(rbuf, 20, this.userName, 0, 32);
            this.week = rbuf[52];
            arraycopy(rbuf, 53, this.dateDelivery, 0, 4);
            arraycopy(rbuf, 57, this.resered, 0, 7);
        }

        public Date getDateCreated() {
            String szDateCreated = new String(dateCreated, StandardCharsets.UTF_8);
            SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
            try {
                Date date = formatter.parse(szDateCreated);
                return date;
            } catch (ParseException e) {
                e.printStackTrace();
            }
            return null;
        }

        private byte[] dateToByteArray(Date date) {
            byte[] bArr = new byte[4];
            if (date == null) {
                bArr[0] = (byte) 0;
                bArr[1] = (byte) 0;
                bArr[2] = (byte) 0;
                bArr[3] = (byte) 0;
                return bArr;
            }

            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH) + 1;
            int day = c.get(Calendar.DAY_OF_MONTH);

            bArr[0] = (byte) (year >> 8);
            bArr[1] = (byte) (year /* >> 0 */);
            bArr[2] = (byte) month;
            bArr[3] = (byte) day;
            return bArr;
        }

        private Date dateFromByteArray(byte[] bArr) {
            int year = ((int) bArr[0] << 8) | bArr[1];
            int month = (int) bArr[2];
            int day = (int) bArr[3];

            Calendar c = Calendar.getInstance();
            c.set(year, month-1, day);
            return c.getTime();
        }
    }

    public static class Chunk {

        public static int chunk_info_length = 4 + 1 + 1 + 4 + 4 + 2;

        byte[] length;    // 4
        byte   type;      // 1
        byte   bpm;       // 1
        byte[] seqNum;    // 4
        byte[] timestamp; // 4
        byte[] count;     // 2(short)
        byte[] data;      // ?

        private int byteLength;

        public static int calcDataLength(byte[] rbuf) {
            return byteArrayToInt(Arrays.copyOfRange(rbuf, 0, 4));
        }

        public Chunk(byte type, byte bpm, int seqNum, int timestamp, short count, byte[] data) {
            byteLength = chunk_info_length + data.length;

            this.length = intToByteArray(byteLength);
            this.type = type;
            this.bpm = bpm;
            this.seqNum = intToByteArray(seqNum);
            this.timestamp = intToByteArray(timestamp);
            this.count = shortToByteArray(count);
            this.data = data;
        }

        public Chunk(byte[] rbuf, byte[] data) {
            this.length = new byte[4];
            this.seqNum = new byte[4];
            this.timestamp = new byte[4];
            this.count = new byte[2];

            put(rbuf, data);
        }

        public byte[] get() {
            byte[] wbuf = new byte[byteLength];
            arraycopy(this.length, 0, wbuf, 0, 4);
            wbuf[4] = this.type;
            wbuf[5] = this.bpm;
            arraycopy(this.seqNum, 0, wbuf, 6, 4);
            arraycopy(this.timestamp, 0, wbuf, 10, 4);
            arraycopy(this.count, 0, wbuf, 14, 2);
            arraycopy(this.data, 0, wbuf, 16, this.data.length);
            return wbuf;
        }

        public void put(byte[] rbuf, byte[] data) {
            arraycopy(rbuf, 0, this.length, 0, 4);
            this.type = rbuf[4];
            this.bpm = rbuf[5];
            arraycopy(rbuf, 6, this.seqNum, 0, 4);
            arraycopy(rbuf, 10, this.timestamp, 0, 4);
            arraycopy(rbuf, 14, this.count, 0, 2);

            this.data = new byte[data.length];
            arraycopy(data, 0, this.data, 0, data.length);
        }

        public int getLength() {
            return byteArrayToInt(length);
        }

        public byte getType() {
            return type;
        }

        public byte getBpm() {
            return bpm;
        }

        public int getSeqNum() {
            return byteArrayToInt(seqNum);
        }

        public int getTimestamp() {
            return byteArrayToInt(timestamp);
        }

        public short getCount() {
            return byteArrayToShort(count);
        }

        public byte[] getData() {
            return data;
        }


        private static byte[] intToByteArray(int intNum) {
            ByteBuffer bb = ByteBuffer.allocate(4);
            bb.putInt(intNum);
            byte[] bArr = new byte[4];
            arraycopy(bb.array(), 0, bArr, 0, 4);
            return bArr;
        }

        private static int byteArrayToInt(byte[] bArr) {
            ByteBuffer wrapped = ByteBuffer.wrap(bArr);
            int iVal = wrapped.getInt();
            return iVal;
        }

        private static byte[] shortToByteArray(short shortNum) {
            ByteBuffer bb = ByteBuffer.allocate(4);
            bb.putShort(shortNum);
            byte[] bArr = new byte[2];
            arraycopy(bb.array(), 0, bArr, 0, 2);
            return bArr;
        }

        private static short byteArrayToShort(byte[] bArr) {
            ByteBuffer wrapped = ByteBuffer.wrap(bArr);
            short sVal = wrapped.getShort();
            return sVal;
        }
    }

    //---------------------------------------------------
    public SmdFile() {
    }

    public File getSmdFilesDir(Context ctx) {
        return ctx.getExternalFilesDir(null);
    }
}