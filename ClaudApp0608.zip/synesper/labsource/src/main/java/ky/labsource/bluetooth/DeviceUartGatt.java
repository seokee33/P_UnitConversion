package ky.labsource.bluetooth;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.util.UUID;

import ky.labsource.bluetooth.ble.UUIDGroup;

import static ky.labsource.bluetooth.BLEManager.ACTION_DATA_AVAILABLE;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_CONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_DISCONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_SERVICES_DISCOVERED;

public class DeviceUartGatt extends DeviceGatt {
    private final static String TAG = DeviceUartGatt.class.getSimpleName();


    public DeviceUartGatt(Context ctx, BluetoothDevice device) {
        super.connect(ctx, device);

        registerUartUUID();
    }

    public void registerUartUUID() {
        UUIDGroup uartService = UUIDGroup.SERVICE(UUIDGroup.UUID_SERVICE_UART.toString());
        uartService.addCharUUIDs(UUIDGroup.UUID_CHAR_RX, UUIDGroup.UUID_CHAR_TX);
        mUUIDServices.add(uartService);
    }


    public void enableUartNotification() {
        enableNotification(UUIDGroup.UUID_SERVICE_UART, UUIDGroup.UUID_CHAR_TX);
    }


    //===================================
    @SuppressLint("MissingPermission")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
        String intentAction;
        mConnectionState = newState;

        if (newState == BluetoothProfile.STATE_CONNECTED) {
            Log.i(TAG, "Connected to GATT server.");

            // Attempts to discover services after successful connection.
            gatt.discoverServices();
            //Log.i(TAG, "Attempting to start service discovery:" + );

            intentAction = ACTION_GATT_CONNECTED;
            BLEManager.broadcastUpdate(mCtx, intentAction);
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            intentAction = ACTION_GATT_DISCONNECTED;
            Log.i(TAG, "Disconnected from GATT server.");
            BLEManager.broadcastUpdate(mCtx, intentAction);
        }
        //super.onConnectionStateChange(gatt, status, newState);
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
        super.onServicesDiscovered(gatt, status);

        if (status == BluetoothGatt.GATT_SUCCESS) {
            enableUartNotification();
        }
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        super.onCharacteristicRead(gatt, characteristic, status);
    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        super.onCharacteristicWrite(gatt, characteristic, status);
    }

    @Override
    public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        super.onDescriptorRead(gatt, descriptor, status);
    }

    @Override
    public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        super.onDescriptorWrite(gatt, descriptor, status);
    }

    @Override
    public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
        super.onReliableWriteCompleted(gatt, status);
    }

    @Override
    public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
        super.onReadRemoteRssi(gatt, rssi, status);
    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        super.onCharacteristicChanged(gatt, characteristic);
        BLEManager.broadcastUpdate(mCtx, ACTION_DATA_AVAILABLE, characteristic);
    }
    //===================================
}
