package com.ms.api.login;

public class User {
    public User(String userId, String userEmail, String userName, String password, String delivery) {
        this.userId = userId;
        this.userEmail = userEmail;
        this.userName = userName;
        this.password = password;
        this.delivery = delivery;
    }

    private String userId;
    private String userEmail;
    private String userName;
    private String password;
    private String delivery;


}
