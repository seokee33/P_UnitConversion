package com.ms.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

public class OkHttpClientProvider {

    public static CookieJar cookieJar;

    public static OkHttpClient getLoginOkHttpClient() {
        HttpLoggingInterceptor loggingInterceptor = LoggingInterceptor.getLogger();

        // 쿠키 매니저 설정
//        CookieManager cookieManager = new CookieManager();
//        cookieManager.setCookiePolicy(CookiePolicy.ACCEPT_ALL);
        cookieJar = new CookieJar() {
            private final HashMap<String, List<Cookie>> cookieStore = new HashMap<>();

            @Override
            public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                cookieStore.put(url.host(), cookies);
            }

            @Override
            public List<Cookie> loadForRequest(HttpUrl url) {
                List<Cookie> cookies = cookieStore.get(url.host());
                return cookies != null ? cookies : new ArrayList<>();
            }
        };

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor) // 로깅 인터셉터 추가
                .cookieJar(cookieJar)
                .build();

        return client;
    }

    public static OkHttpClient getFileUploadOkHttpClient(){
        HttpLoggingInterceptor loggingInterceptor = LoggingInterceptor.getLogger();

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor) // 로깅 인터셉터 추가
                .build();

        return client;
    }

    public static OkHttpClient getAccountOkHttpClient(){
        HttpLoggingInterceptor loggingInterceptor = LoggingInterceptor.getLogger();

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();
        return client;
    }
}
