package kr.claud.synesper.ui.setting.menu;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DataresetViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public DataresetViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is datareset fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}