package ky.labsource.common;

import android.os.Handler;

import androidx.annotation.Nullable;

public class StepDivider {
    public static final String TAG = StepDivider.class.getSimpleName();

    public static final int REGULARTIME = 0;
    public static final int SINUSOIDALTIME = 1;


    public interface OnStepDividerListener {
        void onStep(StepDivider stepDivider, int point, boolean bLast);
    }
    private OnStepDividerListener mStepDividerListener = null;


    private final Handler mHandler = new Handler();

    private final float mStepInterval; // on point
    private final float mSpeed;  // points per second

    private boolean mPointAssigned = false;
    private float mStartPoint = 0.f;
    private float mEndPoint = 0.f;
    private float[] mPoints = null;
    private int[] mIntervals = null;
    private int mStepPos = 0;


    public StepDivider(float stepInterval, int speed, OnStepDividerListener listener) {
        mStepInterval = stepInterval;
        mSpeed = speed;

        setOnStepDividerListener(listener);

        clear();
    }


    public void setOnStepDividerListener(@Nullable OnStepDividerListener listener) { mStepDividerListener = listener; }

    public void clear() {
        mHandler.removeCallbacks(mRunnable);

        mPoints = null;
        mIntervals = null;
        mStepPos = 0;

        mPointAssigned = false;
    }

    public boolean isEnabled() {
        return mPointAssigned;
    }

    public float getCurPoint() {
        if (mPoints != null && mStepPos >= 0)
            return mPoints[mStepPos];
        return mEndPoint;
    }

    public void move(float start, float end, int mode) {
        move(start, end, mode, mSpeed);
    }

    public void movePerOneSec(float start, float end, int mode) { move(start, end, mode, (end - start)/1.f); }
    public void movePer500mSec(float start, float end, int mode) { move(start, end, mode, (end - start)/0.5f); }
    public void movePer250mSec(float start, float end, int mode) { move(start, end, mode, (end - start)/0.25f); }

    public void move(float start, float end, int mode, float speed) {
        clear();

        mStartPoint = start;
        mEndPoint = end;
        mPointAssigned = true;

        float diff = end - start;
        int nStep = Math.abs((int)(diff / mStepInterval));
        if (nStep > 1) {
            float stepInterval = diff / nStep;

            mPoints = new float[nStep+1];
            mIntervals = new int[nStep];

            int i;
            float curPoint = start;
            for (i=0 ; i<nStep ; i++) {
                mPoints[i] = curPoint;
                curPoint += stepInterval;
            }
            mPoints[nStep] = end;

            if (mode == REGULARTIME) {
                regularMove(stepInterval, speed);
            }
            else if (mode == SINUSOIDALTIME) {
                sinusoidalMove(stepInterval, speed);
            }

            _start();
        }
        else {
            if (mStepDividerListener != null) {
                mStepDividerListener.onStep(StepDivider.this, (int)end, true);
            }
        }
    }


    private void _start() {
        mStepPos = 0;

        mHandler.removeCallbacks(mRunnable);
        mHandler.postDelayed(mRunnable, mIntervals[mStepPos]);
    }

    private boolean _next() {
        boolean bRet = false;
        if (mStepPos < mPoints.length-1)
            mStepPos++;

        if (mStepPos < mIntervals.length) {
            mHandler.postDelayed(mRunnable, mIntervals[mStepPos]);
            bRet = true;
        }
        return bRet;
    }

    private final Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            boolean bLast = !_next();

            if (mStepDividerListener != null) {
                mStepDividerListener.onStep(StepDivider.this, (int)mPoints[mStepPos], bLast);
            }
        }
    };


    private void regularMove(float stepInterval, float speed) {
        int i;
        int nStep = mIntervals.length;
        float timeStep = stepInterval / speed;
        for (i=0 ; i<nStep ; i++) {
            mIntervals[i] = (int)(timeStep * 1000);
        }
    }

    private void sinusoidalMove(float stepInterval, float speed) {
        int i;
        int nStep = mIntervals.length;

        double timeTotal = (double)stepInterval * nStep;
        double radStep = Math.PI / nStep;
        double curRad = radStep;
        double prevValue = 0;
        double sumValue = 0;
        double[] tmpIntervals = new double[nStep];

        for (i=0 ; i<nStep ; i++) {
            double curValue = Math.sin(curRad);
            double diffValue = curValue - prevValue;
            tmpIntervals[i] = Math.abs(diffValue);
            sumValue += tmpIntervals[i];

            prevValue = curValue;
            curRad += radStep;
        }

        double mul = timeTotal / sumValue;
        for (i=0 ; i<nStep ; i++) {
            mIntervals[i] = (int)(tmpIntervals[i] * mul * 1000);
        }
    }
}