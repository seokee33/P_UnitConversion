package kr.claud.synesper.adapter;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.libs.enums.WeekDay;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.ui.measurement.MeasurementCache;


public class HcalDataAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final String TAG = "HcalDataAdapter";

    private final int VIEW_TYPE_ITEM = 0;

    private ArrayList<HcalDataItem> mList;
    private boolean mLoading = false;
    private int mItemLimit = 20;


    public interface OnAdapterListener {
        void onItemClick(View v, HcalDataItem item, int pos);
        void onItemChanged(HcalDataAdapter adapter, int firstPos, int lastPos);
    }
    private OnAdapterListener mOnAdapterListener = null;
    public void setOnAdapterListener(OnAdapterListener l) {
        mOnAdapterListener = l;
    }

    public HcalDataAdapter(ArrayList<HcalDataItem> list) {
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_data_item, parent, false);
        HcalDataViewHolder viewHolder = new HcalDataViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HcalDataViewHolder) {
            populateHcalData((HcalDataViewHolder) holder, position);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return VIEW_TYPE_ITEM;
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }


    public HcalDataItem getItem(int index) {
        if (index >= 0 && index < mList.size()) {
            return mList.get(index);
        }
        return null;
    }

    //------------------------------------------------------------------------
    // scroll listener
    public RecyclerView.OnScrollListener mOnScrollListener = new RecyclerView.OnScrollListener() {
        private int scrollState = RecyclerView.SCROLL_STATE_IDLE;

        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            //Log.d("HcalDataAdapter", "onScrollStateChanged() - newState=" + newState);

            scrollState = newState;
        }

        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);

            if (mList.size() >= mItemLimit && dx == 0)
                return;

            LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            if (layoutManager != null) {
                if (!mLoading) {
                    int firstPos = layoutManager.findFirstCompletelyVisibleItemPosition();
                    int lastPos = layoutManager.findLastCompletelyVisibleItemPosition();
                    //Log.d("HcalDataAdapter", "onScrolled(): dx=" + dx + ", dy=" + dy);
                    loadMoreItems(firstPos, lastPos);
                }
            }
        }
    };

    public boolean addHcalData(int index, HcalDataItem item, boolean bNotify) {
        boolean bRet = false;
        if (index >= 0) {
            mList.add(index, item);
            bRet = true;
        } else {
            bRet = mList.add(item);
        }
        if (bNotify) {
            notifyDataSetChanged();
        }
        return bRet;
    }

    public boolean addHcalData(HcalDataItem item, boolean bNotify) {
        return addHcalData(-1, item, bNotify);
    }

    public boolean addHcalData(String curDate, int low, int high, boolean bNotify) {
        HcalDataItem deviceItem = new HcalDataItem(curDate, low, high);
        return addHcalData(-1, deviceItem, bNotify);
    }

    public boolean addHcalData(int index, String curDate, int low, int high, boolean bNotify) {
        HcalDataItem deviceItem = new HcalDataItem(curDate, low, high);
        return addHcalData(index, deviceItem, bNotify);
    }

    public boolean addHcalDataToday(int low, int high, boolean bNotify) {
        String curDate = HcalDataItem.stringFromDate(new Date());
        return addHcalData(curDate, low, high, bNotify);
    }

    public boolean addHcalDataToday(int index, int low, int high, boolean bNotify) {
        String curDate = HcalDataItem.stringFromDate(new Date());
        return addHcalData(index, curDate, low, high, bNotify);
    }

    public void invalidateHcalData(Date date, int low, int high) {
        int pos = 0;
        for (HcalDataItem item : mList) {
            if (item.compareDate(date)) {
                Log.d(TAG, "invalidateHcalData() - " + pos);
                item.low = low;
                item.high = high;
                notifyItemChanged(pos);
                break;
            }
            pos++;
        }
    }

    public void loadMoreItems(int firstPos, int lastPos) {
        boolean bHead = (firstPos == 0);
        boolean bTail = (lastPos == mList.size() - 1);
        if (!bHead && !bTail)
            return;

        mLoading = true;

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                AppData ad = AppData.I();
                if (bHead) {
                    HcalDataAdapter.HcalDataItem item = mList.get(0).newItemPrev(0, 0);
                    MeasurementCache.MeasurementDay md = ad.getMeasurement(item.getDate());
                    if (md != null) {
                        item.setLow(md.momMin);
                        item.setHigh(md.momMax);
                    }
                    addHcalData(0, item, false);
                    notifyItemInserted(0);

                    if (mList.size() > mItemLimit) {
                        mList.remove(mList.size() - 1);
                        notifyItemRemoved(mList.size());
                    }
                }
                if (bTail) {
                    HcalDataAdapter.HcalDataItem item = mList.get(mList.size()-1).newItemNext(0, 0);
                    MeasurementCache.MeasurementDay md = ad.getMeasurement(item.getDate());
                    if (md != null) {
                        item.setLow(md.momMin);
                        item.setHigh(md.momMax);
                    }
                    addHcalData(item, false);
                    notifyItemInserted(mList.size() - 1);

                    if (mList.size() > mItemLimit) {
                        mList.remove(0);
                        notifyItemRemoved(0);
                    }
                }

                if (mOnAdapterListener != null) {
                    mOnAdapterListener.onItemChanged(HcalDataAdapter.this, firstPos, lastPos);
                }
                //mHcalDataAdapter.notifyDataSetChanged();
                mLoading = false;
            }
        }, 10);
    }
    //------------------------------------------------------------------------
    public static class HcalDataItem {

        public static int minValue = 0;
        public static int maxValue = 250;
        public static String pattern = "yyyy-MM-dd";
        public static String stringFromDate(Date date) {
            SimpleDateFormat sdf = new SimpleDateFormat(pattern, Locale.getDefault());
            return sdf.format(date);
        }

        private Date date;
        private int low;
        private int high;

        public HcalDataItem(String date, int low, int high) {  // yyyy-MM-dd
            DateFormat fmt = new SimpleDateFormat(pattern);
            try {
                this.date = fmt.parse(date);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            this.low = low;
            this.high = high;
        }

        public Date getDate() {
            return date;
        }

        public boolean compareDate(Date date) {
            return DateUtil.compareDate(this.date, date);
        }

        public int getYear() {
            return DateUtil.yearFromDate(this.date);
        }

        public int getMonth() {
            return DateUtil.monthFromDate(this.date);
        }

        public int getDay() {
            return DateUtil.dayFromDate(this.date);
        }

        // 1(SUNDAY), 2, ..., 7(SATURDAY)
        public int getWeekday() {
            return DateUtil.weekdayFromDate(this.date);
        }

        public int getLow() {
            return low;
        }

        public void setLow(int low) {
            this.low = low;
        }

        public int getHigh() {
            return high;
        }

        public void setHigh(int high) {
            this.high = high;
        }

        public HcalDataItem newItemPrev(int low, int high) {
            Calendar c = Calendar.getInstance();
            c.setTime(this.date);
            c.add(Calendar.DATE, -1);
            return new HcalDataItem(stringFromDate(c.getTime()), low, high);
        }

        public HcalDataItem newItemNext(int low, int high) {
            Calendar c = Calendar.getInstance();
            c.setTime(this.date);
            c.add(Calendar.DATE, 1);
            return new HcalDataItem(stringFromDate(c.getTime()), low, high);
        }
    }

    //----------------------------------------------------
    public class HcalDataViewHolder extends RecyclerView.ViewHolder {

        protected LinearLayout border;
        protected CardView value;
        protected TextView weekday;
        protected TextView day;

        public HcalDataViewHolder(@NonNull View itemView) {
            super(itemView);

            this.border = (LinearLayout) itemView.findViewById(R.id.linearLayoutValue);
            this.value = (CardView) itemView.findViewById(R.id.cardViewValue);
            this.weekday = (TextView) itemView.findViewById(R.id.textViewDayOfWeek);
            this.day = (TextView) itemView.findViewById(R.id.textViewDay);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            mOnAdapterListener.onItemClick(v, mList.get(pos), pos);
                        }
                    }
                }
            });
        }
    }

    private void updateDataBar(HcalDataViewHolder holder, int high, int low, int h) {
        int paddingTop = (HcalDataItem.maxValue - high) * h / (HcalDataItem.maxValue - HcalDataItem.minValue);
        int paddingBottom = (low - HcalDataItem.minValue) * h / (HcalDataItem.maxValue - HcalDataItem.minValue);
        //Log.d(TAG, "top=" + paddingTop + ", bottom=" + paddingBottom);
        holder.border.setPadding(0, paddingTop, 0, paddingBottom);
        holder.value.setVisibility(View.VISIBLE);
    }

    private void populateHcalData(HcalDataViewHolder holder, int position) {
        //holder.weekday.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9);
        //holder.day.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);

        //holder.weekday.setGravity(Gravity.CENTER);
        //holder.day.setGravity(Gravity.CENTER);

        Log.d(TAG, "populateHcalData() - " + position);

        int weekday = mList.get(position).getWeekday();
        int day = mList.get(position).getDay();

        int low = mList.get(position).getLow();
        if (low < HcalDataItem.minValue)
            low = HcalDataItem.minValue;
        else if (low > HcalDataItem.maxValue)
            low = HcalDataItem.maxValue;

        int high = mList.get(position).getHigh();
        if (high < HcalDataItem.minValue)
            high = HcalDataItem.minValue;
        else if (high > HcalDataItem.maxValue)
            high = HcalDataItem.maxValue;

        if (high == 0 && low == 0) {
            holder.value.setVisibility(View.GONE);
        } else {
            int h = holder.border.getHeight();
            //Log.d(TAG, "day=" + day + "====> position=" + position + ", h=" + h);
            if (h > 0) {
                updateDataBar(holder, high, low, h);
            } else {
                int finalHigh = high;
                int finalLow = low;
                holder.border.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        holder.border.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        updateDataBar(holder, finalHigh, finalLow, holder.border.getHeight());
                    }
                });
            }
        }

        WeekDay wd = WeekDay.fromIndex(weekday);
        holder.weekday.setText(wd.getShortName());
        holder.weekday.setTextColor(wd.getColor());
        holder.day.setText("" + day);
    }
}
