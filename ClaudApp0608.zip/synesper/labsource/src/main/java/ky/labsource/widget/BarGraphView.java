package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

import ky.labsource.R;

/**
 * TODO: document your custom view class.
 */
public class BarGraphView extends View {
    private static final String TAG = "BarGraphView";

    //----- properties -----------------------------------------
    private String mBarGraphString; // TODO: use a default from R.string...
    private int mBarGraphColor = Color.RED; // TODO: use a default from R.color...
    private float mBarGraphDimension = 0; // TODO: use a default from R.dimen...
    private Drawable mBarGraphDrawable;

    private TextPaint mTextPaint;
    private float mTextWidth;
    private float mTextHeight;

    //-----------------------------------------------------------
    private float[] mBarData;


    public BarGraphView(Context context) {
        super(context);
        init(null, 0);
    }

    public BarGraphView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }

    public BarGraphView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        // Load attributes
        final TypedArray a = getContext().obtainStyledAttributes(
                attrs, R.styleable.BarGraphView, defStyle, 0);

        mBarGraphString = a.getString(R.styleable.BarGraphView_barGraphString);
        mBarGraphColor = a.getColor(R.styleable.BarGraphView_barGraphColor, mBarGraphColor);
        // Use getDimensionPixelSize or getDimensionPixelOffset when dealing with
        // values that should fall on pixel boundaries.
        mBarGraphDimension = a.getDimension(R.styleable.BarGraphView_barGraphDimension, mBarGraphDimension);

        if (a.hasValue(R.styleable.BarGraphView_barGraphDrawable)) {
            mBarGraphDrawable = a.getDrawable(R.styleable.BarGraphView_barGraphDrawable);
            mBarGraphDrawable.setCallback(this);
        }

        a.recycle();

        // Set up a default TextPaint object
        mTextPaint = new TextPaint();
        mTextPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setTextAlign(Paint.Align.LEFT);

        // Update TextPaint and text measurements from attributes
        invalidateTextPaintAndMeasurements();
    }

    private void invalidateTextPaintAndMeasurements() {
        mTextPaint.setTextSize(mBarGraphDimension);
        mTextPaint.setColor(mBarGraphColor);
        mTextWidth = mTextPaint.measureText(mBarGraphString);

        Paint.FontMetrics fontMetrics = mTextPaint.getFontMetrics();
        mTextHeight = fontMetrics.bottom;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // TODO: consider storing these as member variables to reduce
        // allocations per draw cycle.
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();

        int contentWidth = getWidth() - paddingLeft - paddingRight;
        int contentHeight = getHeight() - paddingTop - paddingBottom;

        //canvas.drawRect()
        RectF rcGraph = new RectF(paddingLeft, paddingTop, paddingLeft + contentWidth, paddingTop + contentHeight);
        drawGraph(canvas, rcGraph);

        // Draw the text.
        canvas.drawText(mBarGraphString,
                paddingLeft + (contentWidth - mTextWidth) / 2,
                paddingTop + (contentHeight + mTextHeight) / 2,
                mTextPaint);

        // Draw the example drawable on top of the text.
        if (mBarGraphDrawable != null) {
            mBarGraphDrawable.setBounds(paddingLeft, paddingTop,
                    paddingLeft + contentWidth, paddingTop + contentHeight);
            mBarGraphDrawable.draw(canvas);
        }
    }


    private void drawGraph(Canvas canvas, RectF r) {
        int nSamples = 12;
        int i;

        Paint barPaint = new Paint();
        barPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        barPaint.setStyle(Paint.Style.STROKE);
        barPaint.setStrokeCap(Paint.Cap.ROUND);
        barPaint.setStrokeWidth(3.f);
        barPaint.setAntiAlias(true);
        barPaint.setColor(Color.rgb(255, 0, 0));

        float step = r.width()/nSamples;
        float x = 0.f;
        RectF rcTmp = new RectF(r.left, 0.f, 0.f, r.bottom);
        for (i=0 ; i<nSamples ; ++i) {
            rcTmp.right = rcTmp.left + step - 1;
            rcTmp.top = r.top + 30;
            canvas.drawRect(rcTmp, barPaint);

            rcTmp.left += step;
        }
    }

    /**
     * Gets the barGraph string attribute value.
     *
     * @return The barGraph string attribute value.
     */
    public String getBarGraphString() {
        return mBarGraphString;
    }

    /**
     * Sets the view"s barGraph string attribute value. In the barGraph view, this string
     * is the text to draw.
     *
     * @param barGraphString The barGraph string attribute value to use.
     */
    public void setBarGraphString(String barGraphString) {
        mBarGraphString = barGraphString;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the barGraph color attribute value.
     *
     * @return The barGraph color attribute value.
     */
    public int getBarGraphColor() {
        return mBarGraphColor;
    }

    /**
     * Sets the view"s barGraph color attribute value. In the barGraph view, this color
     * is the font color.
     *
     * @param barGraphColor The example color attribute value to use.
     */
    public void setBarGraphColor(int barGraphColor) {
        mBarGraphColor = barGraphColor;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the barGraph dimension attribute value.
     *
     * @return The barGraph dimension attribute value.
     */
    public float getBarGraphDimension() {
        return mBarGraphDimension;
    }

    /**
     * Sets the view"s example dimension attribute value. In the example view, this dimension
     * is the font size.
     *
     * @param barGraphDimension The example dimension attribute value to use.
     */
    public void setBarGraphDimension(float barGraphDimension) {
        mBarGraphDimension = barGraphDimension;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the barGraph drawable attribute value.
     *
     * @return The barGraph drawable attribute value.
     */
    public Drawable getBarGraphDrawable() {
        return mBarGraphDrawable;
    }

    /**
     * Sets the view"s barGraph drawable attribute value. In the barGraph view, this drawable is
     * drawn above the text.
     *
     * @param barGraphDrawable The example drawable attribute value to use.
     */
    public void setBarGraphDrawable(Drawable barGraphDrawable) {
        mBarGraphDrawable = barGraphDrawable;
    }
}