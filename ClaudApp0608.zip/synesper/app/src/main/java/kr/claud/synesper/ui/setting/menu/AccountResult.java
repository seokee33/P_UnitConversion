package kr.claud.synesper.ui.setting.menu;

import androidx.annotation.Nullable;


/**
 * Authentication result : success (user details) or error message.
 */
public class AccountResult {
    @Nullable
    private AccountInUserView success;
    @Nullable
    private Integer error;

    AccountResult(@Nullable Integer error) {
        this.error = error;
    }

    AccountResult(@Nullable AccountInUserView success) {
        this.success = success;
    }

    @Nullable
    public AccountInUserView getSuccess() {
        return success;
    }

    @Nullable
    public Integer getError() {
        return error;
    }



    public class AccountInUserView {
        private String name;
        //... other data fields that may be accessible to the UI

        public AccountInUserView(String name) {
            this.name = name;
        }

        public String getDisplayName() {
            return name;
        }
    }
}