package kr.claud.synesper.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.R;

public class HcalNoticeDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public static final String TAG = "HcalNoticeDetailAdapter";

    private static final int VIEWTYPE_EMPTY = 0;
    private static final int VIEWTYPE_DETAIL = 1;

    private Context mContext;
    private Date mDate;
    private ArrayList<HcalNoticeDetailItem> mList;

    public interface OnAdapterListener {
        void onItemClick(View v, HcalNoticeDetailItem item, int pos);
        void onItemChanged(HcalNoticeDetailAdapter adapter, int firstPos, int lastPos);
        void onDelete(HcalNoticeDetailAdapter adapter, int pos);
    }
    private OnAdapterListener mOnAdapterListener = null;
    public void setOnAdapterListener(OnAdapterListener l) {
        mOnAdapterListener = l;
    }

    public HcalNoticeDetailAdapter(Context context, ArrayList<HcalNoticeDetailItem> list) {
        this.mContext = context;

        this.mDate = null;
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        if (viewType == VIEWTYPE_DETAIL) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_notice_detail_item, parent, false);
            viewHolder = new HcalNoticeDetailViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.hcal_notice_detail_item_empty, parent, false);
            viewHolder = new HcalNoticeEmptyViewHolder(view);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof HcalNoticeDetailViewHolder) {
            populateHcalNoticeDetail((HcalNoticeDetailViewHolder) holder, position);
        } else if (holder instanceof HcalNoticeEmptyViewHolder) {
            HcalNoticeEmptyViewHolder emptyViewHolder = (HcalNoticeEmptyViewHolder) holder;
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mList == null || mList.size() == 0)
            return VIEWTYPE_EMPTY;
        return VIEWTYPE_DETAIL;
        //return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        if (mList == null || mList.size() == 0)
            return 1;
        return mList.size();
        //return (null != mList ? mList.size() : 0);
    }

    public HcalNoticeDetailItem getItem(int index) {
        if (index >= 0 && index < mList.size()) {
            return mList.get(index);
        }
        return null;
    }

    public boolean addHcalNoticeDetail(HcalNoticeDetailAdapter.HcalNoticeDetailItem item, boolean bNotify) {
        boolean bRet = mList.add(item);
        if (bNotify) {
            notifyDataSetChanged();
        }
        return bRet;
    }

    public boolean addHcalNoticeDetail(Date date, HcalNoticeDetailItem.ItemType itype, String msg, int bpm, int avgMin, int avgMax, String result, boolean bNotify) {
        HcalNoticeDetailAdapter.HcalNoticeDetailItem item = new HcalNoticeDetailAdapter.HcalNoticeDetailItem(date, itype, msg, bpm, avgMin, avgMax, result);
        return addHcalNoticeDetail(item, bNotify);
    }

    public boolean addHcalNoticeDetailBaby(Date date, String msg, int bpm, int avgMin, int avgMax, String result, boolean bNotify) {
        HcalNoticeDetailAdapter.HcalNoticeDetailItem item = new HcalNoticeDetailAdapter.HcalNoticeDetailItem(date, HcalNoticeDetailItem.ItemType.IT_BABY, msg, bpm, avgMin, avgMax, result);
        return addHcalNoticeDetail(item, bNotify);
    }

    public boolean addHcalNoticeDetailMom(Date date, String msg, int bpm, int avgMin, int avgMax, String result, boolean bNotify) {
        HcalNoticeDetailAdapter.HcalNoticeDetailItem item = new HcalNoticeDetailAdapter.HcalNoticeDetailItem(date, HcalNoticeDetailItem.ItemType.IT_MOM, msg, bpm, avgMin, avgMax, result);
        return addHcalNoticeDetail(item, bNotify);
    }

    public boolean addHcalNoticeDetailEtc(Date date, String msg, int bpm, int avgMin, int avgMax, String result, boolean bNotify) {
        HcalNoticeDetailAdapter.HcalNoticeDetailItem item = new HcalNoticeDetailAdapter.HcalNoticeDetailItem(date, HcalNoticeDetailItem.ItemType.IT_ETC, msg, bpm, avgMin, avgMax, result);
        return addHcalNoticeDetail(item, bNotify);
    }

    public boolean removeHcalNoticeDetail(int pos) {
        HcalNoticeDetailItem item = mList.remove(pos);
        notifyItemRemoved(pos);
        return true;
    }

    public void setDate(Date date) {
        this.mDate = date;
    }

    //------------------------------------------------------------------------
    // scroll listener
    public RecyclerView.OnScrollListener mOnScrollListener = new RecyclerView.OnScrollListener() {
        private int scrollState = RecyclerView.SCROLL_STATE_IDLE;

        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            scrollState = newState;
        }

        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
        }
    };

    //------------------------------------------------------------------------
    public static class HcalNoticeDetailItem {
        private Date date;
        private ItemType type;
        private String msg;
        private int bpm;
        private int avgMin;
        private int avgMax;
        private String result;

        public enum ItemType {
            IT_BABY, IT_MOM, IT_ETC
        }

        public HcalNoticeDetailItem(Date date, ItemType itype, String msg, int bpm, int avgMin, int avgMax, String result) {
            this.date = date;
            this.type = itype;
            this.msg = msg;
            this.bpm = bpm;
            this.avgMin = avgMin;
            this.avgMax = avgMax;
            this.result = result;
        }

        public Date getDate() {
            return this.date;
        }
    }


    //----------------------------------------------------
    public class HcalNoticeEmptyViewHolder extends RecyclerView.ViewHolder {
        public HcalNoticeEmptyViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

    public class HcalNoticeDetailViewHolder extends RecyclerView.ViewHolder {

        protected TextView tvDay;
        protected ImageView ivAlert;
        protected ConstraintLayout clayoutResult;
        protected TextView tvMsg;
        protected TextView tvText;
        protected TextView tvBpm;
        protected TextView tvUnit;
        protected TextView tvText2;
        protected TextView tvResult;
        protected TextView tvContent;
        protected ImageView ivDelete;

        public HcalNoticeDetailViewHolder(@NonNull View itemView) {
            super(itemView);

            this.tvDay = (TextView) itemView.findViewById(R.id.textViewDay);
            this.ivAlert = (ImageView) itemView.findViewById(R.id.imageViewAlert);
            this.clayoutResult = (ConstraintLayout) itemView.findViewById(R.id.layoutResult);
            this.tvMsg = (TextView) itemView.findViewById(R.id.textViewMsg);
            this.tvText = (TextView) itemView.findViewById(R.id.textViewText);
            this.tvBpm = (TextView) itemView.findViewById(R.id.textViewBpm);
            this.tvUnit = (TextView) itemView.findViewById(R.id.textViewUnit);
            this.tvText2 = (TextView) itemView.findViewById(R.id.textViewText2);
            this.tvResult = (TextView) itemView.findViewById(R.id.textViewResult);
            this.tvContent = (TextView) itemView.findViewById(R.id.textViewContent);
            this.ivDelete = (ImageView) itemView.findViewById(R.id.imageViewDelete);

            this.ivDelete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            mOnAdapterListener.onDelete(HcalNoticeDetailAdapter.this, pos);
                        }
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnAdapterListener != null) {
                            //mOnAdapterListener.onItemClick(view, mList.get(pos), pos);
                        }
                    }
                }
            });
        }
    }

    private void populateHcalNoticeDetail(HcalNoticeDetailViewHolder holder, int position) {
        HcalNoticeDetailItem item = mList.get(position);

        holder.tvDay.setText(String.format("%d", DateUtil.dayFromDate(item.date)));
        switch(item.type) {
            case IT_BABY:
                holder.ivAlert.setImageResource(R.drawable.red_alert);
                holder.clayoutResult.setBackgroundResource(R.drawable.notice_box_red_bg);

                holder.tvText.setText(R.string.notice_baby_pulse);
                holder.tvBpm.setText(String.format("%d", item.bpm));
                holder.tvBpm.setTextColor(mContext.getResources().getColor(R.color.notice_text_red));
                holder.tvResult.setText(item.result);

                holder.tvMsg.setVisibility(View.GONE);
                holder.tvText.setVisibility(View.VISIBLE);
                holder.tvBpm.setVisibility(View.VISIBLE);
                holder.tvUnit.setVisibility(View.VISIBLE);
                holder.tvText2.setVisibility(View.VISIBLE);
                holder.tvResult.setVisibility(View.VISIBLE);
                break;

            case IT_MOM:
                holder.ivAlert.setImageResource(R.drawable.blue_alert);
                holder.clayoutResult.setBackgroundResource(R.drawable.notice_box_blue_bg);

                holder.tvText.setText(R.string.notice_mom_pulse);
                holder.tvBpm.setText(String.format("%d", item.bpm));
                holder.tvBpm.setTextColor(mContext.getResources().getColor(R.color.notice_text_blue));
                holder.tvResult.setText(item.result);

                holder.tvMsg.setVisibility(View.GONE);
                holder.tvText.setVisibility(View.VISIBLE);
                holder.tvBpm.setVisibility(View.VISIBLE);
                holder.tvUnit.setVisibility(View.VISIBLE);
                holder.tvText2.setVisibility(View.GONE);
                holder.tvResult.setVisibility(View.GONE);

                break;

            case IT_ETC:
                holder.ivAlert.setImageResource(R.drawable.purple_alert);
                holder.clayoutResult.setBackgroundResource(R.drawable.notice_box_purple_bg);

                holder.tvMsg.setText(R.string.notice_msg_ex0);
                holder.tvMsg.setTextColor(mContext.getResources().getColor(R.color.notice_text_purple));

                holder.tvMsg.setVisibility(View.VISIBLE);
                holder.tvText.setVisibility(View.GONE);
                holder.tvBpm.setVisibility(View.GONE);
                holder.tvUnit.setVisibility(View.GONE);
                holder.tvText2.setVisibility(View.GONE);
                holder.tvResult.setVisibility(View.GONE);
                break;
        }

        holder.tvContent.setText(item.msg);
    }

}