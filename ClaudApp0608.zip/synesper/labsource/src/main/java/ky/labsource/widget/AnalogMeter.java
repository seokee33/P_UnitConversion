package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

import ky.labsource.R;

/**
 * TODO: document your custom view class.
 */
public class AnalogMeter extends View {

    // Attr {{
    private float maMinValue = 0;
    private float maMaxValue = 100;

    private int maFaceColor = Color.WHITE;
    // Attr }}

    private String mExampleString; // TODO: use a default from R.string...
    private int mExampleColor = Color.RED; // TODO: use a default from R.color...
    private float mExampleDimension = 0; // TODO: use a default from R.dimen...
    private Drawable mExampleDrawable;


    private int    mAnalogMeterBitmapWidth = 0;
    private int    mAnalogMeterBitmapHeight = 0;
    private Bitmap mAnalogMeterBitmap = null;
    private Canvas mAnalogMeterCanvas = null;

    private float mCanvasCenterX;
    private float mCanvasCenterY;
    private float mCanvasWidth;
    private float mCanvasHeight;



    private TextPaint mTextPaint;
    private float mTextWidth;
    private float mTextHeight;

    public AnalogMeter(Context context) {
        super(context);
        init(null, 0);
    }

    public AnalogMeter(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs, 0);
    }

    public AnalogMeter(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs, defStyle);
    }

    private void init(AttributeSet attrs, int defStyle) {
        // Load attributes
        final TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.AnalogMeter, defStyle, 0);

        maMinValue = a.getFloat(R.styleable.AnalogMeter_analogMeterMinValue, maMinValue);
        maMaxValue = a.getFloat(R.styleable.AnalogMeter_analogMeterMaxValue, maMaxValue);
        maFaceColor = a.getColor(R.styleable.AnalogMeter_analogMeterFaceColor, maFaceColor);

        mExampleString = a.getString(R.styleable.AnalogMeter_exampleString);
        mExampleColor = a.getColor(R.styleable.AnalogMeter_exampleColor, mExampleColor);
        // Use getDimensionPixelSize or getDimensionPixelOffset when dealing with
        // values that should fall on pixel boundaries.
        mExampleDimension = a.getDimension(R.styleable.AnalogMeter_exampleDimension, mExampleDimension);

        if (a.hasValue(R.styleable.AnalogMeter_exampleDrawable)) {
            mExampleDrawable = a.getDrawable(R.styleable.AnalogMeter_exampleDrawable);
            mExampleDrawable.setCallback(this);
        }

        a.recycle();

        // Set up a default TextPaint object
        mTextPaint = new TextPaint();
        mTextPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setTextAlign(Paint.Align.LEFT);

        // Update TextPaint and text measurements from attributes
        invalidateTextPaintAndMeasurements();
    }

    private void createAnalogMeterBitmap(int w, int h) {
        mAnalogMeterBitmapWidth = w;
        mAnalogMeterBitmapHeight = h;

        mAnalogMeterBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mAnalogMeterCanvas = new Canvas();
        mAnalogMeterCanvas.setBitmap(mAnalogMeterBitmap);


        Paint pnt = new Paint();
        pnt.setStrokeWidth(6f);
        pnt.setColor(Color.parseColor("#FF0000"));
        pnt.setStyle(Paint.Style.STROKE);

        RectF rect = new RectF();
        rect.set(1, 1, w-1, h-1);
        mAnalogMeterCanvas.drawArc(rect, (270), 290, false, pnt);

        //rect = new RectF();
        //rect.set(300, 700, 700, 1100);
        //mAnalogMeterCanvas.drawArc(rect, 0, 290, true, pnt);


/*
        RectF rimRect = new RectF(w * .05f, h * .05f, w * 0.95f, h * 0.95f);
        Paint rimPaint = new Paint();
        rimPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        rimPaint.setShader(new LinearGradient(w * 0.40f, h * 0.0f, w * 0.60f, h * 1.0f,
                Color.rgb(0xf0, 0xf5, 0xf0),
                Color.rgb(0x30, 0x31, 0x30),
                Shader.TileMode.CLAMP));

        float rimSize = 0.02f * w;
        RectF faceRect = new RectF();
        faceRect.set(rimRect.left + rimSize, rimRect.top + rimSize,
                rimRect.right - rimSize, rimRect.bottom - rimSize);
        Paint facePaint = new Paint();
        facePaint.setAntiAlias(true);
        facePaint.setStyle(Paint.Style.FILL);
        facePaint.setColor(maFaceColor);

        Paint rimShadowPaint = new Paint();
        rimShadowPaint.setStyle(Paint.Style.FILL);
        rimShadowPaint.setShader(new RadialGradient(0.5f * w, 0.5f * h, faceRect.width() / 2.0f,
                new int[]{0x00000000, 0x00000500, 0x50000500},
                new float[]{0.96f, 0.96f, 0.99f},
                Shader.TileMode.MIRROR));

        Paint rimCirclePaint = new Paint();
        rimCirclePaint.setAntiAlias(true);
        rimCirclePaint.setStyle(Paint.Style.STROKE);
        rimCirclePaint.setColor(Color.argb(0x4f, 0x33, 0x36, 0x33));
        rimCirclePaint.setStrokeWidth(0.005f);

        mAnalogMeterCanvas.drawOval(rimRect, rimPaint);
        mAnalogMeterCanvas.drawOval(rimRect, rimCirclePaint);

        mAnalogMeterCanvas.drawOval(faceRect, facePaint);
        mAnalogMeterCanvas.drawOval(faceRect, rimCirclePaint);
        mAnalogMeterCanvas.drawOval(faceRect, rimShadowPaint);
        */
    }

    private void invalidateTextPaintAndMeasurements() {
        mTextPaint.setTextSize(mExampleDimension);
        mTextPaint.setColor(mExampleColor);
        mTextWidth = mTextPaint.measureText(mExampleString);

        Paint.FontMetrics fontMetrics = mTextPaint.getFontMetrics();
        mTextHeight = fontMetrics.bottom;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // TODO: consider storing these as member variables to reduce
        // allocations per draw cycle.
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();

        int contentWidth = getWidth() - paddingLeft - paddingRight;
        int contentHeight = getHeight() - paddingTop - paddingBottom;

        if (mAnalogMeterBitmap == null) {
            createAnalogMeterBitmap(contentWidth, contentHeight);
        }
        else if (mAnalogMeterBitmapWidth != contentWidth || mAnalogMeterBitmapHeight != contentHeight) {
            createAnalogMeterBitmap(contentWidth, contentHeight);
        }

        canvas.drawBitmap(mAnalogMeterBitmap, paddingLeft, paddingTop, null);

        // Draw the text.
        canvas.drawText(mExampleString,
                paddingLeft + (contentWidth - mTextWidth) / 2,
                paddingTop + (contentHeight + mTextHeight) / 2,
                mTextPaint);

        // Draw the example drawable on top of the text.
        if (mExampleDrawable != null) {
            mExampleDrawable.setBounds(paddingLeft, paddingTop,paddingLeft + contentWidth,paddingTop + contentHeight);
            mExampleDrawable.draw(canvas);
        }
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        mCanvasWidth = (float) w;
        mCanvasHeight = (float) h;
        mCanvasCenterX = w / 2f;
        mCanvasCenterY = h / 2f;

        super.onSizeChanged(w, h, oldw, oldh);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int size;
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int widthWithoutPadding = width - getPaddingLeft() - getPaddingRight();
        int heightWithoutPadding = height - getPaddingTop() - getPaddingBottom();

        if (widthWithoutPadding > heightWithoutPadding) {
            size = heightWithoutPadding;
        } else {
            size = widthWithoutPadding;
        }

        setMeasuredDimension(size + getPaddingLeft() + getPaddingRight(), size + getPaddingTop() + getPaddingBottom());
    }


    /**
     * Gets the example string attribute value.
     *
     * @return The example string attribute value.
     */
    public String getExampleString() {
        return mExampleString;
    }

    /**
     * Sets the view's example string attribute value. In the example view, this string
     * is the text to draw.
     *
     * @param exampleString The example string attribute value to use.
     */
    public void setExampleString(String exampleString) {
        mExampleString = exampleString;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the example color attribute value.
     *
     * @return The example color attribute value.
     */
    public int getExampleColor() {
        return mExampleColor;
    }

    /**
     * Sets the view's example color attribute value. In the example view, this color
     * is the font color.
     *
     * @param exampleColor The example color attribute value to use.
     */
    public void setExampleColor(int exampleColor) {
        mExampleColor = exampleColor;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the example dimension attribute value.
     *
     * @return The example dimension attribute value.
     */
    public float getExampleDimension() {
        return mExampleDimension;
    }

    /**
     * Sets the view's example dimension attribute value. In the example view, this dimension
     * is the font size.
     *
     * @param exampleDimension The example dimension attribute value to use.
     */
    public void setExampleDimension(float exampleDimension) {
        mExampleDimension = exampleDimension;
        invalidateTextPaintAndMeasurements();
    }

    /**
     * Gets the example drawable attribute value.
     *
     * @return The example drawable attribute value.
     */
    public Drawable getExampleDrawable() {
        return mExampleDrawable;
    }

    /**
     * Sets the view's example drawable attribute value. In the example view, this drawable is
     * drawn above the text.
     *
     * @param exampleDrawable The example drawable attribute value to use.
     */
    public void setExampleDrawable(Drawable exampleDrawable) {
        mExampleDrawable = exampleDrawable;
    }
}
