package com.ms.api.changeuser;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ChangeAccountService {
    @POST("account")
    Call<ResponseBody> account(@Header("Cookie") String cookie, @Body RequestBody body);

    @POST("account/password")
    Call<ResponseBody> password(@Header("Cookie") String cookie, @Body RequestBody body);

}
