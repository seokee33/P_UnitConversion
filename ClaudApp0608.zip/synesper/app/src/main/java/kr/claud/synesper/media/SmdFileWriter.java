package kr.claud.synesper.media;


import static java.lang.System.arraycopy;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;


/*
  C:\Users\pysik\AppData\Local\Google\AndroidStudio2021.2\device-explorer\pixel_5_-_api_31 [emulator-5554]\sdcard\Android\data\kr.claud.synesper\files


<<< Synesper Media Data(smd) >>>

  File format
-------------------------------------------------
Identity:
  (16)'SMD File' + EOF

Header:
  (4)length
  (4)created date : Year - short(2), Month - byte(1), Day - byte(1)
  (32)user name
  (2)week
  (4)delivery date

Chunk:
  (4)length
  (1)type - pcg(voice) or ppg
  (1)bpm
  (4)sequence
  (4)timestamp (msec)

  signal data
*/
public class SmdFileWriter extends SmdFile {
    public static final String TAG = "SmdFileWriter";

    private FileOutputStream mFileOutputStream = null;
    private String mFileName = null;
    private String mFilePath = null;

    public SmdFileWriter() {
    }

    public File getSmdFilesDir(Context ctx) {
        return ctx.getExternalFilesDir(null);
    }

    public boolean isOpened() {
        return (mFileOutputStream != null);
    }

    public String getFileName() {
        return mFileName;
    }

    public String getFilePath() {
        return mFilePath;
    }


    //ctx.getFilesDir();             : "/data/data/kr.claud.synesper/files/"
    //ctx.getExternalCacheDir();     :
    //ctx.getExternalFilesDir(null); : "/Android/data/kr.claud.synesper/files/"
    private boolean _open(String fileName, File fileDir) {
        File ofile = new File(fileDir, fileName);

        this.mFilePath = ofile.getAbsolutePath();
        Log.d(TAG, "FilePath=" + mFilePath);

        try {
            //mFileOutputStream = ctx.openFileOutput(fileName, Context.MODE_PRIVATE); // "/data/data/kr.claud.synesper/files/"
            mFileOutputStream = new FileOutputStream(ofile);
        } catch (FileNotFoundException e) {
            mFileOutputStream = null;
            e.printStackTrace();
            return false;
        }

        //(16)'SMD File' + EOF
        if (mFileOutputStream != null) {
            byte[] wbuff = new byte[16];

            byte[] str = _idStr.getBytes(StandardCharsets.UTF_8);
            arraycopy(str, 0, wbuff, 0, str.length);
            wbuff[str.length] = 0x1A;

            try {
                mFileOutputStream.write(wbuff, 0, 16);
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }

            close();
        }
        return false;
    }

    public boolean open(Context ctx, String fileName) {
        File smdFilesDir = getSmdFilesDir(ctx);
        this.mFileName = fileName;
        return _open(fileName, smdFilesDir);
    }

    public boolean openCache(Context ctx, String fileName) {
        File ofile = new File(ctx.getExternalCacheDir(), CACHE_FILENAME);
        if (ofile.exists()) {
            ofile.delete();
        }
        this.mFileName = fileName;
        return _open(CACHE_FILENAME, ctx.getExternalCacheDir());
    }

    private boolean _move(File src, File dest) {
        boolean bRes = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                Files.copy(src.toPath(), dest.toPath());
                bRes = true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                InputStream in = new FileInputStream(src);
                try {
                    OutputStream out = new FileOutputStream(dest);
                    try {
                        byte[] buf = new byte[1024];
                        int len;
                        while ((len = in.read(buf)) > 0) {
                            out.write(buf, 0, len);
                        }
                        out.close();

                        bRes = true;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                in.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return bRes;
    }

    public void move(File destDir) {
        File srcFile = new File(this.mFilePath);
        File destFile = new File(destDir, this.mFileName);
        if (_move(srcFile, destFile)) {
            this.mFilePath = destFile.getAbsolutePath();
        }
    }

    public boolean close() {
        if (mFileOutputStream != null) {
            try {
                mFileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            mFileOutputStream = null;
            return true;
        }
        return false;
    }

    public void clear() {
        mFileName = null;
        mFilePath = null;
    }

    public boolean writeHeader(String name, int week, Date dateCreated, Date dateDelivery) {
        if (mFileOutputStream != null) {
            Header _header = new Header(dateCreated, name, week, dateDelivery);
            byte[] wbuff = _header.get();

            try {
                Log.d(TAG, "write header: length=" + wbuff.length);
                mFileOutputStream.write(wbuff, 0, wbuff.length);
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }


    public boolean writeChunk(byte type, byte bpm, int seqNum, int timestamp, short count, byte[] data, int dataLength) {
        if (mFileOutputStream != null) {
            byte[] wdata = new byte[dataLength];
            arraycopy(data, 0, wdata, 0, dataLength);
            Chunk _chunk = new Chunk(type, bpm, seqNum, timestamp, count, wdata);
            byte[] wbuff = _chunk.get();

            try {
//                Log.d(TAG, "write chunk: length=" + wbuff.length);
//                Log.d("kim", "write chunk: length=" + Arrays.toString(wbuff));
                mFileOutputStream.write(wbuff, 0, wbuff.length);
                return true;
            } catch (IOException e) {
                //Log.i("kim","SMD Error : "+e.toString());
                e.printStackTrace();
            }
        }
        return false;
    }

    public boolean write(byte[] data) {
        if (mFileOutputStream != null) {
            try {
                mFileOutputStream.write(data);
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}