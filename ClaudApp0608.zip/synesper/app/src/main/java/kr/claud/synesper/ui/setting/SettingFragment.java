package kr.claud.synesper.ui.setting;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.adapter.SettingsAdapter;
import kr.claud.synesper.databinding.FragmentSettingBinding;
import kr.claud.synesper.ui.chart.ChartFragment;

public class SettingFragment extends Fragment {
    public static final String TAG = "SettingFragment";

    private SettingViewModel settingViewModel;
    private FragmentSettingBinding binding;
    private RecyclerView mRecyclerSettingsView;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        settingViewModel = new ViewModelProvider(this).get(SettingViewModel.class);

        binding = FragmentSettingBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        //final TextView textView = binding.textSetting;
        //settingViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        initSettingsRecycler(root);
        return root;
    }

    @Override
    public void onDestroyView() {
        MainActivity macty = (MainActivity) getActivity();
        macty.destroyChildFragment(SettingFragment.class);

        super.onDestroyView();
        binding = null;
    }


    //-----------------------------------------------------------
    private SettingsAdapter.OnItemClickListener mOnItemClickListener = new SettingsAdapter.OnItemClickListener() {
        @Override
        public void onItemClick(View v, SettingsAdapter.SettingsItem item, int pos) {
            MainActivity macty = (MainActivity) getActivity();
            if (item.getType() == SettingsAdapter.VIEWTYPE_SETTING) {
                int itemId = item.getTag();
                if (itemId >= 0) {
                    macty.NavigateFragment(MainActivity.NAVISRC.NAVISRC_FRAGMENT, itemId, false);
                }
            }

        }
    };

    private void initSettingsRecycler(View root) {
        settingViewModel.setAdapterItemClickListener(mOnItemClickListener);

        mRecyclerSettingsView = binding.recyclerSettings;
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerSettingsView.setLayoutManager(mLinearLayoutManager);

        SettingsAdapter adapter = settingViewModel.getAdapter();
        mRecyclerSettingsView.setAdapter(adapter);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mRecyclerSettingsView.getContext(), mLinearLayoutManager.getOrientation());
        //mRecyclerSettingsView.addItemDecoration(dividerItemDecoration);
        DividerItemDecoration spaceDecoration = new DividerItemDecoration(mRecyclerSettingsView.getContext(), mLinearLayoutManager.getOrientation());
        spaceDecoration.setDrawable(getResources().getDrawable(R.drawable.divider_16));
        mRecyclerSettingsView.addItemDecoration(spaceDecoration);

        settingViewModel.clearArrayList();

        adapter.addHeaderItem(getContext().getString(R.string.setting_category_info));
        adapter.addSettingsItem(R.drawable.settings_icon_1, getString(R.string.menu_profile), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_profile);
        adapter.addSettingsItem(R.drawable.settings_icon_2, getString(R.string.menu_account), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_account);
        adapter.addSettingsItem(R.drawable.settings_icon_3, getString(R.string.menu_device), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_device);
        adapter.addHeaderItem(getContext().getString(R.string.setting_category_notification));
        adapter.addSettingsItem(R.drawable.settings_icon_6, getString(R.string.menu_pulse), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_pulse);
        adapter.addHeaderItem(getContext().getString(R.string.setting_category_help));
        adapter.addSettingsItem(R.drawable.settings_icon_4, getString(R.string.menu_usage), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_usage);
        adapter.addSettingsItem(R.drawable.settings_icon_5, getString(R.string.menu_contact), R.drawable.ic_arrow_right_24, null).setTag(R.id.nav_contact);
        adapter.addSettingsItem(R.drawable.settings_icon_7, getString(R.string.menu_reset), -1, null).setTag(R.id.nav_datareset);
    }
}