package kr.claud.libs.internet;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {
    public static final String TAG = "Email";

    public enum MailProvider {
        GMAIL,
        DAUM,
        NAVER;
    }

    public interface OnEmailListener {
        void onDone(boolean bResult);
    }


    private String _user;  //"ravi.sharma@oodlestechnologies.com"
    private String _pw;    //"Can't disclose, enter your password and your email"

    private Session _session;
    private String _personal;

    private void _init(@NonNull String user, @NonNull String pw, @NonNull Properties props) {
        this._user = user;
        this._pw = pw;

        this._personal = null;

        //Session session = Session.getInstance(props, ...
        this._session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(_user, _pw);
            }
        });
    }

    public Email(@NonNull String user, @NonNull String pw, @NonNull MailProvider mp) {
        Properties props = null;
        switch (mp) {
            case GMAIL:
                props = propsGmail();
                break;
            case DAUM:
                props = propsDaum();
                break;
            case NAVER:
                props = propsNaver();
                break;
            default:
                props = propsGmail();
                break;
        }
        _init(user, pw, props);
    }

    public Email(@NonNull String user, @NonNull String pw, @NonNull Properties props) {
        _init(user, pw, props);
    }

    public void setPersonal(String personal) {
        this._personal = personal;
    }

    //------------------------------------------------------------
    // static function
    public static Properties propsDaum() {
        Properties props = new Properties();
        //props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl.enable", "true");
        //props.put("mail.smtp.ssl.trust", "smtp.daum.net");
        //props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.daum.net");
        props.put("mail.smtp.port", "465");
        return props;
    }

    public static Properties propsGmail() {
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", 465);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.ssl.enable", "true");
        props.put("mail.smtp.ssl.trust", "smtp.gmail.com");
        return props;
    }

    public static Properties propsNaver() {
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.naver.com");
        props.put("mail.smtp.port", 587);
        props.put("mail.smtp.auth", "true");
        return props;
    }

    public static boolean startEmail(Context ctx, String email, String subject, String text) {
        Intent mailIntent = new Intent(Intent.ACTION_SEND);
        mailIntent.setType("*/*");
        mailIntent.putExtra(Intent.EXTRA_EMAIL, email);   //"aaa@naver.com"
        mailIntent.putExtra(Intent.EXTRA_SUBJECT, subject); //"Email Subject"
        mailIntent.putExtra(Intent.EXTRA_TEXT, text);  //"Email Text"
        ctx.startActivity(mailIntent);
        return true;
    }

    public static Intent buildMailIntent(String email, String subject, String text) {
        Intent mailIntent = new Intent(Intent.ACTION_SEND);
        mailIntent.setType("*/*");
        mailIntent.putExtra(Intent.EXTRA_EMAIL, email);   //"aaa@naver.com"
        mailIntent.putExtra(Intent.EXTRA_SUBJECT, subject); //"Email Subject"
        mailIntent.putExtra(Intent.EXTRA_TEXT, text);  //"Email Text"
        return mailIntent;
    }
    //------------------------------------------------------------

    private boolean _sendHtml(Session session, String email, String subject, String body) {
        try
        {
            InternetAddress fromAddr = (_personal != null && _personal.length() > 0) ? new InternetAddress(_user, _personal) : new InternetAddress(_user);

            MimeMessage msg = new MimeMessage(session);
            //set message headers
            msg.addHeader("Content-type", "text/HTML; charset=UTF-8");
            msg.addHeader("format", "flowed");
            msg.addHeader("Content-Transfer-Encoding", "8bit");

            msg.setFrom(fromAddr);
            msg.setReplyTo(InternetAddress.parse(_user, false));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email, false));

            msg.setSubject(subject, "UTF-8");
            msg.setContent(body, "text/html;charset=UTF-8"); //msg.setText(body, "UTF-8");
            msg.setSentDate(new Date());

            Transport.send(msg);
            return true;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean _sendText(Session session, String email, String subject, String body) {
        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(_user));

            //수신자메일주소
            //message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email, false));
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(email));

            // 메일 제목
            message.setSubject(subject);
            // 메일 내용
            message.setText(body);

            Transport.send(message);
            return true;
        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return false;
    }

    public void viaHtml(String email, String subject, String body, OnEmailListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean bResult = _sendHtml(_session, email, subject, body);
                if (listener != null) {
                    listener.onDone(bResult);
                }
            }
        }).start();
    }

    public void viaText(String recipient, String subject, String content, Properties props, OnEmailListener listener) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                //Session session = Session.getInstance(props, ...
                Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(_user, _pw);
                    }
                });

                boolean bResult = _sendText(session, recipient, subject, content);
                if (listener != null) {
                    listener.onDone(bResult);
                }
            }
        }).start();
    }

    public void sendDaumMail(String recipient, String subject, String content, OnEmailListener listener) {
        viaText(recipient, subject, content, propsDaum(), listener);
    }

    public void sendGmail(String recipient, String subject, String content, OnEmailListener listener) {
        viaText(recipient, subject, content, propsGmail(), listener);
    }

    public void sendNaverMail(String recipient, String subject, String content, OnEmailListener listener) {
        viaText(recipient, subject, content, propsNaver(), listener);
    }


    public boolean sendByGMailSender(String email, String subject, String text) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    Log.d(TAG, "SEND EMAIL-------");

                    GMailSender sender = new GMailSender(_user, _pw);
                    //sender.addAttachment(Environment.getExternalStorageDirectory().getPath()+"/image.jpg");
                    sender.sendMail(subject, text, _user, email);
                    //Toast.makeText(ctx,"[SENDMAIL] Success", Toast.LENGTH_LONG).show();
                    Log.d(TAG, "SEND EMAIL-------> Success");
                } catch (Exception e) {
                    //Toast.makeText(ctx,"Error", Toast.LENGTH_LONG).show();
                    Log.d(TAG, e.toString());
                    //e.printStackTrace();
                }
            }
        }).start();
        return true;
    }
}
