package kr.claud.synesper.media;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

import androidx.preference.PreferenceManager;

import org.json.JSONArray;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import ky.labsource.LsNet;
import ky.labsource.net.AsyncUploadFile;

/*
We can't write to these folers:
Environment.getDataDirectory()	         /data
Environment.getDownloadCacheDirectory()	 /cache
Environment.getRootDirectory()	         /system

Need WRITE_EXTERNAL_STORAGE Permission:
Environment.getExternalStorageDirectory()	/storage/sdcard0
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_ALARMS)	/storage/sdcard0/Alarms
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)	/storage/sdcard0/DCIM
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)	/storage/sdcard0/Download
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)	/storage/sdcard0/Movies
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)	/storage/sdcard0/Music
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_NOTIFICATIONS)	/storage/sdcard0/Notifications
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)	/storage/sdcard0/Pictures
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PODCASTS)	/storage/sdcard0/Podcasts
Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)	/storage/sdcard0/Ringtones

Application directories:
getCacheDir()	            /data/data/package/cache
getFilesDir()	            /data/data/package/files
getFilesDir().getParent()	/data/data/package

Application External storage directories:
getExternalCacheDir()	/storage/sdcard0/Android/data/package/cache
getExternalFilesDir(null)	/storage/sdcard0/Android/data/package/files
getExternalFilesDir(Environment.DIRECTORY_ALARMS)	/storage/sdcard0/Android/data/package/files/Alarms
getExternalFilesDir(Environment.DIRECTORY_DCIM)	/storage/sdcard0/Android/data/package/files/DCIM
getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)	/storage/sdcard0/Android/data/package/files/Download
getExternalFilesDir(Environment.DIRECTORY_MOVIES)	/storage/sdcard0/Android/data/package/files/Movies
getExternalFilesDir(Environment.DIRECTORY_MUSIC)	/storage/sdcard0/Android/data/package/files/Music
getExternalFilesDir(Environment.DIRECTORY_NOTIFICATIONS)	/storage/sdcard0/Android/data/package/files/Notifications
getExternalFilesDir(Environment.DIRECTORY_PICTURES)	/storage/sdcard0/Android/data/package/files/Pictures
getExternalFilesDir(Environment.DIRECTORY_PODCASTS)	/storage/sdcard0/Android/data/package/files/Podcasts
getExternalFilesDir(Environment.DIRECTORY_RINGTONES)	/storage/sdcard0/Android/data/package/files/Ringtones
*/

public class FileManager {
    public static final String TAG = "FileManager";

    public static final int VOBLE_PACKETS_MAX_COUNT = 36*5;  // during 5 seconds

    private Context mContext = null;
    private FileOutputStream mFileOutputStream = null;
    private String mFileOutputName = null;
    //private String mUploadFileName = null;
    //private String mFileOutputPath = null;

    private Handler mHandler = null;

    private int mPacketsCount = 0;
    private long mPrevTime = 0;


    public interface FileUploadCallback {
        void onDone(String filePath);
    }

    private FileUploadCallback mFileUploadCallback = new FileUploadCallback() {
        @Override
        public void onDone(String filePath) {
            File file = new File(filePath);
            if (file.exists()) {
                boolean bDeleted = file.delete();
                Log.d(TAG, "File deleted: " + filePath + ", result=" + bDeleted);
            }
        }
    };

    private Runnable mRunnableVoBLE = new Runnable() {
        @Override
        public void run() {
            if (closeFile()) {
                if (mPacketsCount > 0) {
                    uploadFileToServer(mFileOutputName, mFileUploadCallback);
                }
                mPacketsCount = 0;
            }
        }
    };

    //--------------------------------------------------------------------
    // Constructor
    public FileManager(Context ctx) {
        this.mContext = ctx;
        this.mHandler = new Handler();
    }

    public void processVoBLEPacket(byte[] data) {
        Date curDate = new Date();
        long curTime = curDate.getTime();
        long diffTime = curTime - mPrevTime;
        mPrevTime = curTime;

        if (diffTime > 1000 || mPacketsCount >= VOBLE_PACKETS_MAX_COUNT) {
            if (closeFile()) {
                if (mPacketsCount > 0) {
                    uploadFileToServer(mFileOutputName, mFileUploadCallback);
                }
            }
            mPacketsCount = 0;
            mHandler.removeCallbacks(mRunnableVoBLE);
        }

        if (mFileOutputStream == null) {
            setFileNew(curDate);
            mPacketsCount = 0;
        }
        if (writePacket(data)) {
            mHandler.removeCallbacks(mRunnableVoBLE);
            mHandler.postDelayed(mRunnableVoBLE, 1000);
        }
    }

    private void uploadFileToServer(String fileName, final FileUploadCallback cb) {
        if (fileName == null)
            return;

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(mContext);
        String serverAddr = prefs.getString("server", "");
        Log.d(TAG, "Server Address=" + serverAddr + ", file name=" + fileName);

        String fileOutputPath = mContext.getFileStreamPath(fileName).getAbsolutePath();
/*
        if (cb != null) {
            cb.onDone(fileOutputPath);
            return;
        }
*/
        if (serverAddr.length() > 0) {
            Uri.Builder builder = new Uri.Builder();
            builder.scheme("http");
            builder.authority(serverAddr);
            builder.appendPath("upload.php");
            String serverUrl = builder.build().toString();

            //String serverUrl = serverAddr + "upload.php";  //http://192.168.0.169/upload.php

            LsNet.AsyncUploadFile(serverUrl, fileOutputPath, fileName, new AsyncUploadFile.AsyncUploadFileCallback() {
                @Override
                public void onPreExecute(AsyncUploadFile aufTask) {

                }

                @Override
                public void onPostExecute(AsyncUploadFile aufTask, JSONArray paramJSONArray) {
                    if (cb != null) {
                        cb.onDone(fileOutputPath);
                    }
                }

                @Override
                public void onError(AsyncUploadFile aufTask, String errMsg) {

                }
            });
        }
    }

    private void setFileNew(Date date) {
        try {
            @SuppressLint("SimpleDateFormat")
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            mFileOutputName = "voble_" + timeStamp + ".ima";

            //File ofile = new File(mContext.getFilesDir(), mFileOutputName);
            File ofile = new File(mContext.getExternalFilesDir(null), mFileOutputName);
            String filePath = ofile.getAbsolutePath();
            Log.d(TAG, "FilePath=" + filePath);
            mFileOutputStream = new FileOutputStream(ofile);

            //String fileOutputPath = mContext.getFileStreamPath(mFileOutputName).getAbsolutePath();
            //mFileOutputStream = mContext.openFileOutput(mFileOutputName, Context.MODE_PRIVATE);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean closeFile() {
        if (mFileOutputStream != null) {
            try {
                mFileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
            mFileOutputStream = null;
            return true;
        }
        return false;
    }

    private boolean writePacket(byte[] data) {
        if (mFileOutputStream != null) {
            try {
                mFileOutputStream.write(data);
                mPacketsCount++;
                return true;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }
}