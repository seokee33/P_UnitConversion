package kr.claud.synesper.ui.chart;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.adapter.HcalDataAdapter;
import kr.claud.synesper.adapter.HcalDataDetailAdapter;
import kr.claud.synesper.adapter.HcalNoticeAdapter;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.databinding.FragmentChartBinding;
import kr.claud.synesper.dialog.DatePickerDialog;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.dialog.SmdPlayerDialog;
import kr.claud.synesper.ui.measurement.MeasurementCache;

public class ChartFragment extends Fragment {
    public static final String TAG = "ChartFragment";

    private FragmentChartBinding binding;
    private ChartViewModel chartViewModel;

    private TextView mChartDateTextView;
    private ImageView mImageViewDatePicker;

    private int mSmdFilePlayerPos = -1;
    private String mPlayingSmdFile = null;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        chartViewModel = new ViewModelProvider(this).get(ChartViewModel.class);
        chartViewModel.createAdapter(getContext());

        binding = FragmentChartBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initButton(root);
        initHcalData(root);
        initHcalDataDetail(root);

        //final TextView textView = binding.textChart;
        //chartViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        saveRecyclerViewState();

        MainActivity macty = (MainActivity) getActivity();
        macty.destroyChildFragment(ChartFragment.class);

        super.onDestroyView();
        binding = null;
    }

    private void initButton(View root) {
        mImageViewDatePicker = (ImageView) root.findViewById(R.id.imageViewDatePicker);
        mImageViewDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtil.showDatePicker(getContext(), new DatePickerDialog.DatePickerDialogListener() {
                    @Override
                    public void onPositiveClicked(int year, int month, int day) {
                        populateHcalDataDetail(DateUtil.dateFrom(year, month, day));
                    }

                    @Override
                    public void onNegativeClicked() {

                    }
                });
            }
        });
    }
    //----------------------------------------------------
    // Hcal Data
    private HcalDataAdapter.OnAdapterListener mOnAdapterListener = new HcalDataAdapter.OnAdapterListener() {
        @Override
        public void onItemClick(View v, HcalDataAdapter.HcalDataItem item, int pos) {
            populateHcalDataDetail(item.getDate());
        }

        @Override
        public void onItemChanged(HcalDataAdapter adapter, int firstPos, int lastPos) {
            HcalDataAdapter.HcalDataItem item = adapter.getItem(firstPos);
            if (item != null) {
                int year = item.getYear();
                int month = item.getMonth();
                String sz = String.format("%4d년 %02d월", year, month);
                mChartDateTextView.setText(sz);
            }

            //Log.d(TAG, "Item Count=" + adapter.getItemCount());
        }
    };

    //------------------------------------------------------
    private RecyclerView mHcalDataView;
    private static Parcelable recyclerViewState = null;

    private void initHcalData(View root) {
        chartViewModel.setAdapterListener(mOnAdapterListener);

        mChartDateTextView = (TextView) root.findViewById(R.id.textViewChartDate);

        mHcalDataView = (RecyclerView) root.findViewById(R.id.recyclerHcalData);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mLinearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mHcalDataView.setLayoutManager(mLinearLayoutManager);

        HcalDataAdapter adapter = chartViewModel.getAdapter();
        mHcalDataView.setAdapter(adapter);
        mHcalDataView.addOnScrollListener(adapter.mOnScrollListener);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mHcalNoticeView.getContext(), mLinearLayoutManager.getOrientation());
        //mHcalNoticeView.addItemDecoration(dividerItemDecoration);

        mHcalDataView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (recyclerViewState != null) {
                    restoreRecyclerViewState();
                }

                if (mHcalDataView.getLayoutManager() != null) {
                    int pos = ((LinearLayoutManager) mHcalDataView.getLayoutManager()).findFirstVisibleItemPosition();
                    HcalDataAdapter.HcalDataItem di = adapter.getItem(pos);
                    String sz = String.format("%4d년 %02d월", di.getYear(), di.getMonth());
                    mChartDateTextView.setText(sz);
                }

                mHcalDataView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });

        //------------------------------------------
        updateHcalData(new Date());
    }

    private void saveRecyclerViewState() {
        if (mHcalDataView.getLayoutManager() != null) {
            recyclerViewState = mHcalDataView.getLayoutManager().onSaveInstanceState();
        }
    }

    private void restoreRecyclerViewState() {
        if (mHcalDataView.getLayoutManager() != null) {
            mHcalDataView.getLayoutManager().onRestoreInstanceState(recyclerViewState);
            recyclerViewState = null;
        }
    }

    private void updateHcalData(Date date) {
        HcalDataAdapter adapter = chartViewModel.getAdapter();
        AppData ad = AppData.I();
        MeasurementCache.MeasurementDay md = ad.getMeasurement(date);
        int low = 0;
        int high = 0;
        if (md != null) {
            low = md.momMin;
            high = md.momMax;
        }

        if (adapter.getItemCount() == 0) {
            String curDate = HcalDataAdapter.HcalDataItem.stringFromDate(date);
            adapter.addHcalData(curDate, low, high, true);
        } else {
            adapter.invalidateHcalData(date, low, high);
        }
    }
    //------------------------------------------------------
    private HcalDataDetailAdapter.OnAdapterListener mOnAdapterDetailListener = new HcalDataDetailAdapter.OnAdapterListener() {
        @Override
        public void onItemClick(View v, HcalDataDetailAdapter.HcalDataDetailItem item, int pos) {
        }

        @Override
        public void onItemChanged(HcalDataDetailAdapter adapter, int firstPos, int lastPos) {
            HcalDataDetailAdapter.HcalDataDetailItem item = adapter.getItem(firstPos);

            Log.d(TAG, "Item Count=" + adapter.getItemCount());
        }

        @Override
        public void onDelete(HcalDataDetailAdapter adapter, int pos) {
            HcalDataDetailAdapter.HcalDataDetailItem item = adapter.getItem(pos);
            AppData ad = AppData.I();
            int userNum = ad.mUserData.userNum();
            ad.removeMeasurement(userNum, item.getDate());
            adapter.removeHcalDataDetail(pos);

            updateHcalData(item.getDate());
        }

        /*
            저장된 청진 데이터 목록에서 플레이 버튼을 클릭하면 호출됨
         */
        // kim -> 재생시 여기로2
        @Override
        public void onPlaySound(HcalDataDetailAdapter adapter, int pos, View view) {
            HcalDataDetailAdapter.HcalDataDetailItem item = adapter.getItem(pos);
            ImageView imageView = (ImageView) view;
            String filePath = item.getFilePath();
            if (filePath != null) {
                MainActivity macty = (MainActivity) getActivity();
                if (mSmdFilePlayerPos == pos) {
                    imageView.setImageResource(R.drawable.ic_baseline_headphones_play);
                    macty.clickPlaySoundByChartFragment(filePath, false, pos);
                    Log.i("kim_play","macty.clickPlaySoundByChartFragment(filePath, false, pos);");
                    mSmdFilePlayerPos = -1;
                    mPlayingSmdFile = null;
                } else {
                    imageView.setImageResource(R.drawable.ic_baseline_headphones_pause);
                    Log.i("kim_play","macty.clickPlaySoundByChartFragment(filePath, true, pos);");
                    macty.clickPlaySoundByChartFragment(filePath, true, pos);
                    mSmdFilePlayerPos = pos;
                    mPlayingSmdFile = filePath;
                }
            }
        }
    };

    public void SmdFilePlayer_Play() {
    }

    public void SmdFilePlayer_Stop(int smdFilePos) {
        Log.d("kim_play", "public void SmdFilePlayer_Stop(int smdFilePos) {");
        Log.d(TAG, "SmdFilePlayer_Stop(): pos=" + smdFilePos);

        if (smdFilePos == -1) {
            smdFilePos = mSmdFilePlayerPos;
        }

        final int pos = smdFilePos;
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                HcalDataDetailAdapter adapter = chartViewModel.getAdapterDetail();
                adapter.notifyItemChanged(pos);
            }
        });

        if (smdFilePos == mSmdFilePlayerPos) {
            mSmdFilePlayerPos = -1;
            mPlayingSmdFile = null;
        }
    }
/*
    DialogUtil.showSmdPlayer(getContext(), new SmdPlayerDialog.SmdPlayerDialogListener() {
        @Override
        public int onNumber() {
            return pos;
        }

        @Override
        public String onDate() {
            return item.dateToString();
        }

        @Override
        public String onFileName() {
            return item.getFileName();
        }

        @Override
        public File onFileDir() {
            return null;
        }

        @Override
        public int onPlayPauseClicked(SmdPlayerDialog dlg, boolean bState) {
            return 0;
        }

        @Override
        public void onCloseClicked() {

        }
    });
*/

    private void initHcalDataDetail(View root) {
        chartViewModel.setAdapterDetailListener(mOnAdapterDetailListener);

        final RecyclerView mHcalDataDetailView = (RecyclerView) root.findViewById(R.id.recyclerHcalDataDetail);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mHcalDataDetailView.setLayoutManager(mLinearLayoutManager);
        HcalDataDetailAdapter adapter = chartViewModel.getAdapterDetail();

        mHcalDataDetailView.setAdapter(adapter);
        mHcalDataDetailView.addOnScrollListener(adapter.mOnScrollListener);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mHcalNoticeView.getContext(), mLinearLayoutManager.getOrientation());
        //mHcalNoticeView.addItemDecoration(dividerItemDecoration);

        //adapter.addHcalDataToday(50, 150, true);

        //populateHcalDataDetail(new Date());
    }

    private void populateHcalDataDetail(Date date) {
        if (mPlayingSmdFile != null) {
            MainActivity macty = (MainActivity) getActivity();
            macty.clickPlaySoundByChartFragment(mPlayingSmdFile, false, mSmdFilePlayerPos);
        }
        mSmdFilePlayerPos = -1;
        mPlayingSmdFile = null;

        //----------------------------------------------
        chartViewModel.clearArrayListDetail();
        HcalDataDetailAdapter adapter = chartViewModel.getAdapterDetail();
        adapter.setDate(date);

        AppData ad = AppData.I();
        MeasurementCache.MeasurementDay md = ad.getMeasurement(date);
        if (md != null) {
            ArrayList<DBHelper.MeasureItem> items = md.getItems();
            for (DBHelper.MeasureItem mi : items) {
                adapter.addHcalDataDetail(DateUtil.stringFromDate(date, HcalDataDetailAdapter.DATE_FMT), mi.time, mi.babyMin, mi.babyMax, mi.babyAvg, mi.momMin, mi.momMax, mi.momAvg, mi.file, true);
            }
        }
    }
}