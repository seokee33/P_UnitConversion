package kr.claud.synesper.dialog;

import androidx.appcompat.app.AlertDialog;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;

public class DialogUtil {

    public static void showDialogMessage(Activity acty, CharSequence title, CharSequence msg, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(acty, R.style.Theme_ClaudApp_PopupDialogTheme);
        LayoutInflater inflater = acty.getLayoutInflater();
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setMessage(msg);
        builder.setPositiveButton(R.string.dialog_ok, listener);
        //builder.setNegativeButton(R.string.quit_dialog_no, null);
        builder.show();
    }


    public static void showFinishApp(AlertDialog.Builder builder, DialogInterface.OnClickListener listener) {
        builder.setIcon(android.R.drawable.ic_dialog_alert);
        builder.setTitle(R.string.quit_dialog_title);
        builder.setMessage(R.string.quit_dialog_message);
        builder.setPositiveButton(R.string.quit_dialog_yes, listener);
        builder.setNegativeButton(R.string.quit_dialog_no, null);
        builder.show();
    }

    public static void showFinishApp(Context ctx, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx, R.style.Theme_ClaudApp_FinishDialogTheme);
        showFinishApp(builder, listener);
    }

    public static void showTurnOnLocation(Context ctx, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder localBuilder = new AlertDialog.Builder(ctx, R.style.Theme_ClaudApp_FinishDialogTheme);
        localBuilder.setMessage("Turn On Location").setCancelable(false);
        localBuilder.setPositiveButton("Enable GPS", listener);
        localBuilder.setNegativeButton("Cancel", listener);
        localBuilder.create().show();
    }


    public static void showProfilePhoto(Context ctx, ProfilePhotoDialog.ProfilePhotoDialogListener listener) {
        ProfilePhotoDialog ppdlg = new ProfilePhotoDialog(ctx, R.style.Theme_ClaudApp_PopupDialogTheme);
        ppdlg.setDialogListener(listener);
        ppdlg.show();
    }

    public static void showDatePicker(Context ctx, DatePickerDialog.DatePickerDialogListener listener) {
        DatePickerDialog dpdlg = new DatePickerDialog(ctx, R.style.Theme_ClaudApp_PopupDialogTheme);
        dpdlg.setDialogListener(listener);
        dpdlg.show();
    }

    public static void showDeliveryPicker(Context ctx, DeliveryPickerDialog.DeliveryPickerDialogListener listener) {
        DeliveryPickerDialog dpdlg = new DeliveryPickerDialog(ctx, R.style.Theme_ClaudApp_PopupDialogTheme);
        dpdlg.setDialogListener(listener);
        dpdlg.show();
    }

    public static void showSmdPlayer(Context ctx, SmdPlayerDialog.SmdPlayerDialogListener listener) {
        SmdPlayerDialog spdlg = new SmdPlayerDialog(ctx, R.style.Theme_ClaudApp_SmdPlayerDialogTheme, listener);
        Window window = spdlg.getWindow();
        window.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        spdlg.show();

        /*
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(spdlg.getWindow().getAttributes());
        layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        layoutParams.height = WindowManager.LayoutParams.MATCH_PARENT;
        spdlg.getWindow().setAttributes(layoutParams);
         */
    }

    public static void showDataReset(Activity acty, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(acty, R.style.Theme_ClaudApp_PopupDialogTheme);
        LayoutInflater inflater = acty.getLayoutInflater();
        builder.setCancelable(true);
        builder.setTitle(R.string.menu_reset);
        builder.setIcon(R.drawable.settings_icon_7);

        View view = inflater.inflate(R.layout.dialog_data_reset, null);
        Button buttonReset = (Button) view.findViewById(R.id.buttonOK);
        Button buttonCancel = (Button) view.findViewById(R.id.buttonCancel);
        builder.setView(view);

        final AlertDialog ad = builder.create();
        ad.show();

        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    if (view.getId() == R.id.buttonOK) {
                        listener.onClick(ad, DialogInterface.BUTTON_POSITIVE);
                    } else if (view.getId() == R.id.buttonCancel) {
                        listener.onClick(ad, DialogInterface.BUTTON_NEGATIVE);
                    }
                }
                ad.dismiss();
            }
        };

        buttonReset.setOnClickListener(l);
        buttonCancel.setOnClickListener(l);
    }

    public static void showProfileLogout(Activity acty, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(acty, R.style.Theme_ClaudApp_PopupDialogTheme);
        LayoutInflater inflater = acty.getLayoutInflater();
        builder.setCancelable(true);
        builder.setTitle(R.string.menu_account);
        builder.setIcon(R.drawable.settings_icon_2);

        View view = inflater.inflate(R.layout.dialog_logout, null);
        Button buttonOK = (Button) view.findViewById(R.id.buttonOK);
        Button buttonCancel = (Button) view.findViewById(R.id.buttonCancel);
        builder.setView(view);
        /*
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
         */
        final AlertDialog ad = builder.create();
        ad.show();

        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (listener != null) {
                    if (view.getId() == R.id.buttonOK) {
                        listener.onClick(ad, DialogInterface.BUTTON_POSITIVE);
                    } else if (view.getId() == R.id.buttonCancel) {
                        listener.onClick(ad, DialogInterface.BUTTON_NEGATIVE);
                    }
                }
                ad.dismiss();
            }
        };
        buttonOK.setOnClickListener(l);
        buttonCancel.setOnClickListener(l);
    }

    public static void showLTECheck(Activity acty, DialogInterface.OnClickListener listener){
        AlertDialog.Builder builder = new AlertDialog.Builder(acty, R.style.Theme_ClaudApp_PopupDialogTheme);
        LayoutInflater inflater = acty.getLayoutInflater();
        builder.setCancelable(true);
        builder.setTitle(R.string.dialog_title);
        builder.setIcon(R.drawable.ic_wifi);

        View view = inflater.inflate(R.layout.dialog_ltecheck, null);
        Button buttonOK = (Button) view.findViewById(R.id.btn_OK );
        Button buttonCancel = (Button) view.findViewById(R.id.btn_Cancel);
        ImageView ivReCheck = (ImageView) view.findViewById(R.id.iv_ReCheck);
        TextView tvReCheck = (TextView) view.findViewById(R.id.tv_ReCheck);

        AppData ad = AppData.I();
        builder.setView(view);

        final AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();

        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("dialogTouch","OK");
                ad.setLETCheck(ad.mPrefServerOK);
                dialog.dismiss();
            }
        });

        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("dialogTouch","Cancel");
                ad.mPrefServerOK = false;
                ad.mPrefCheckLTE = false;
                dialog.dismiss();
            }
        });


        ivReCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("dialogTouch","iv_re");
                if(ad.mPrefCheckLTE){
                    ivReCheck.setImageResource(R.drawable.login_1);
                    ad.mPrefCheckLTE = false;
                }else{
                    ivReCheck.setImageResource(R.drawable.login_1_button_1);
                    ad.mPrefCheckLTE = true;
                }
            }
        });

        tvReCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("dialogTouch","tv_re");
                if(ad.mPrefCheckLTE){
                    ivReCheck.setImageResource(R.drawable.login_1);
                    ad.mPrefCheckLTE = false;
                }else{
                    ivReCheck.setImageResource(R.drawable.login_1_button_1);
                    ad.mPrefCheckLTE = true;
                }
            }
        });
    }

}
