package kr.claud.synesper.ui.measurement;

import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import kr.claud.synesper.data.DBHelper;

public class MeasurementCache {
    public static final String TAG = "MeasurementCache";

    private DBHelper _db;

    public MeasurementCache(DBHelper db) {
        _db = db;

        initCache();
    }

    public MeasurementDay get(int userNum, Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);

        MeasurementMonth mm = loadCache(userNum, year, month);
        return mm.get(day);
    }

    public boolean update(int userNum, Date date, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, boolean uploadState) {
        ArrayList<DBHelper.MeasureItem> measArr = _db.selectMeasure(userNum, date);
        boolean bRet = false;
        if (measArr.size() == 0) {
            bRet = _db.insertMeasure(userNum, date, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
        } else {
            DBHelper.MeasureItem mi = measArr.get(0);
/*
            int bMin = mi.babyMin;
            int bMax = mi.babyMax;
            int mMin = mi.momMin;
            int mMax = mi.momMax;

            if (bpmBaby > 0) {
                if (bpmBaby < bMin)
                    bMin = bpmBaby;
                if (bpmBaby > bMax)
                    bMax = bpmBaby;
            }

            if (bpmMom > 0) {
                if (bpmMom < mMin)
                    mMin = bpmMom;
                if (bpmMom > mMax)
                    mMax = bpmMom;
            }
*/
            bRet = _db.updateMeasure(userNum, date, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
        }

        if (bRet) {
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH) + 1;
            removeMonth(year, month);
            Log.d(TAG, "update() - removeMonth:" + year + "." + month);
        }
        return bRet;
    }

    public void remove(int userNum, Date date) {
        Integer iResult = _db.deleteMeasure(userNum, date);
        Log.d(TAG, "remove() ------------" + DBHelper.stringFromDate(date) + " " + DBHelper.stringTimeFromDate(date));
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        removeMonth(year, month);
    }

    //-------------------------------------------------
    ArrayList<MeasurementMonth> _months;

    private void initCache() {
        _months = new ArrayList<>();
    }

    private MeasurementMonth loadCache(int userNum, int year, int month) {
        MeasurementMonth mm = findMonth(year, month);
        if (mm == null) {
            mm = new MeasurementMonth(year, month);
            mm.load(userNum);
            _months.add(mm);
        }
        return mm;
    }

    private MeasurementMonth reloadCache(int userNum, int year, int month) {
        removeMonth(year, month);
        MeasurementMonth mm = new MeasurementMonth(year, month);
        mm.load(userNum);
        _months.add(mm);
        return mm;
    }

    private MeasurementMonth findMonth(int year, int month) {
        for(MeasurementMonth mm : _months) {
            if (mm.year == year && mm.month == month)
                return mm;
        }
        return null;
    }

    private void removeMonth(int year, int month) {
        for(MeasurementMonth mm : _months) {
            if (mm.year == year && mm.month == month) {
                _months.remove(mm);
                break;
            }
        }
    }


    public class MeasurementDay {
        public int day;
        public ArrayList<DBHelper.MeasureItem> _items;

        public int babyMax;
        public int babyMin;
        public int momMax;
        public int momMin;

        public MeasurementDay(int day, ArrayList<DBHelper.MeasureItem> items) {
            this.day = day;
            this._items = items;

            babyMax = 0;
            babyMin = 0;
            momMax = 0;
            momMin = 0;

            for (DBHelper.MeasureItem mi : this._items) {
                if (babyMax == 0 || mi.babyMax > babyMax)
                    babyMax = mi.babyMax;
                if (babyMin == 0 || mi.babyMin < babyMin)
                    babyMin = mi.babyMin;

                if (momMax == 0 || mi.momMax > momMax)
                    momMax = mi.momMax;
                if (momMin == 0 || mi.momMin < momMin)
                    momMin = mi.momMin;
            }
        }

        public ArrayList<DBHelper.MeasureItem> getItems() {
            return _items;
        }
    }

    public class MeasurementMonth {
        public int year;
        public int month;
        ArrayList<MeasurementDay> _days;

        private int refCount;

        public MeasurementMonth(int year, int month) {
            this.year = year;
            this.month = month;
            _days = new ArrayList<>();

            refCount = 0;
        }

        public void load(int userNum) {
            _days.clear();
            Log.d(TAG, "load() --------------");
            for(int i=1 ; i<=31 ; i++) {
                Date date = DBHelper.dateFrom(year, month, i);
                ArrayList<DBHelper.MeasureItem> items = _db.selectMeasures(userNum, date);
                if (items.size() > 0) {
                    MeasurementDay md = new MeasurementDay(i, items);
                    _days.add(md);

                    Log.d(TAG, "day=" + md.day + ", count=" + items.size() + ": file=" + items.get(0).file);
                }
            }
        }

        public MeasurementDay get(int day) {
            refCount++;
            for(MeasurementDay md : _days) {
                if (md.day == day)
                    return md;
            }
            return null;
        }
    }
}