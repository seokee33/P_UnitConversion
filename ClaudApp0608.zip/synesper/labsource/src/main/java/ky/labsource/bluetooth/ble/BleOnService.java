package ky.labsource.bluetooth.ble;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;


public class BleOnService  extends Service {
    private final static String TAG = BleOnService.class.getSimpleName();

    public class LocalBinder extends Binder {
        public BleOnService getService() {
            return BleOnService.this;
        }
    }
    private final IBinder mBinder = new BleOnService.LocalBinder();

    //----------------------------------------------------
    public interface OnServiceListener {
        IBinder onBind(Intent intent);
        void onUnbind(Intent intent);
    }
    public void setOnServiceListener(OnServiceListener l) { this.mOnServiceListener = l; }
    private OnServiceListener mOnServiceListener = null;
    //----------------------------------------------------

    @Override
    public IBinder onBind(Intent intent) {
        IBinder ibinder = null;
        if (mOnServiceListener != null)
            ibinder = mOnServiceListener.onBind(intent);
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        if (mOnServiceListener != null)
            mOnServiceListener.onUnbind(intent);
        return super.onUnbind(intent);
    }
}
