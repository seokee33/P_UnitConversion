package com.ms.api.changeuser;

import static com.ms.api.OkHttpClientProvider.cookieJar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import com.ms.api.RetrofitBuilderProvider;
import com.ms.api.RetrofitClient;
import okhttp3.Cookie;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;

public class ChangeAccount {
    public static void account(String userName, String delivery, Callback<ResponseBody> callback) throws JSONException {
        JSONObject user = new JSONObject();
        user.put("userName",userName);
        user.put("delivery",delivery);

        List<Cookie> cookies = cookieJar.loadForRequest(HttpUrl.parse(RetrofitBuilderProvider.web));
        String header = "";
        for (Cookie cookie : cookies) {
            String cookieString = cookie.name() + "=" + cookie.value();
            header = cookieString;
        }

        RequestBody body = RequestBody.create(MediaType.parse("application/json"),user.toString());

        Call<ResponseBody> call = RetrofitClient.getChangeAccountService().account(header,body);
        call.enqueue(callback);
    }

    public static void password(String password, Callback<ResponseBody> callback) throws JSONException {
        JSONObject user = new JSONObject();
        user.put("password",password);

        List<Cookie> cookies = cookieJar.loadForRequest(HttpUrl.parse(RetrofitBuilderProvider.web));
        String header = "";
        for (Cookie cookie : cookies) {
            String cookieString = cookie.name() + "=" + cookie.value();
            header = cookieString;
        }

        RequestBody body = RequestBody.create(MediaType.parse("application/json"),user.toString());

        Call<ResponseBody> call = RetrofitClient.getChangeAccountService().password(header,body);
        call.enqueue(callback);
    }


}
