package kr.claud.synesper.media;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.util.Log;

import java.util.LinkedList;
import java.util.Queue;

public class PCMPlayer {

    public static final String TAG = "PCMPlayer";

    public static final byte AUTOSTOP_CODE = 0x1A;

    public enum PlayerMode {
        PLAYER_NONE,
        PLAYER_STREAM,
        PLAYER_FILE;
    }

    //private AudioTrack mAudioTrack = null;
    //private Thread mPlayThread = null;

    private int mSampleRate;
    private int mChannelConf = AudioFormat.CHANNEL_OUT_MONO;
    private int mAudioFormat = AudioFormat.ENCODING_PCM_16BIT;
    private int mBufferSize;

    private Thread mPlayThread = null;
    private boolean mbPlaying = false;
    private PlayerMode mPlayerMode = PlayerMode.PLAYER_NONE;

    private Queue<byte[]> mPcmQueue = new LinkedList<>();

    private OnPCMPlayerListener mListener = null;
    public void setOnPCMPlayerListener(OnPCMPlayerListener l) {
        mListener = l;
    }

    public boolean isPlaying() {
        return mbPlaying;
    }

    public PlayerMode getPlayerMode() {
        return mPlayerMode;
    }

    public void setPlayerMode(PlayerMode mode) {
        mPlayerMode = mode;
    }

    public static int playCount = 0; //kim(수정) -> 지워야함

    // kim(수정) -> 삭제
    public void clear() {
        synchronized (mPcmQueue) {
            mPcmQueue.clear();
//            playCount = 0;
        }
    }

    public byte[] getAutoStopPacket() {
        byte[] pkt = new byte[1];
        pkt[0] = AUTOSTOP_CODE;
        return pkt;
    }

//    public void addPacket(byte[] pcmData) {
//        if (!mbPlaying)
//            return;
//
//        synchronized (mPcmQueue) {
//            Log.i("kim","addPacket : "+(++playCount));
//            Log.i("kim","pkt Length : "+mPcmQueue.size());
//            mPcmQueue.offer(pcmData);
//        }
//
//    }

    //kim (수정) : 2023.04.19
    public void addPacket(byte[] pcmData) {
        synchronized (mPcmQueue) {
            mPcmQueue.offer(pcmData);
        }
    }
    public void addPacket(short[] pcmSamples) {
        byte[] pcmData = new byte[pcmSamples.length*2];
        int idx = 0;
        for (short s : pcmSamples) {
            // in 16 bit wav PCM, first byte is the low order byte
            pcmData[idx++] = (byte) (s & 0x00ff);
            pcmData[idx++] = (byte) ((s & 0xff00) >>> 8);
        }
        addPacket(pcmData);
    }

    public void play(int sampleRate, int channelConf, int audioFormat, int bufferSize) {
        if (mPlayThread != null)
            return;

        mSampleRate = sampleRate;
        mChannelConf = channelConf;
        mAudioFormat = audioFormat;
        mBufferSize = bufferSize;

        mPlayThread = new Thread(new Runnable() {
            @Override
            public void run() {
                int bufsize = AudioTrack.getMinBufferSize(mSampleRate, mChannelConf, mAudioFormat);
                Log.d(TAG, "AudioTrack: min buffer size=" + bufsize);

                AudioTrack audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, mSampleRate, mChannelConf, mAudioFormat, mBufferSize, AudioTrack.MODE_STREAM); // AudioTrack 생성
                audioTrack.play();  // write 하기 전에 play 를 먼저 수행해 주어야 함
                if (mListener != null)
                    mListener.onPlay();

                mbPlaying = true;
                while(mbPlaying) {
                    byte[] qwd = null;
                    synchronized (mPcmQueue) {
                        if (mPcmQueue.size() > 0) {
                            qwd = mPcmQueue.poll();
                        }
                    }
                    if (qwd != null) {
                        int size = qwd.length;
                        if (size == 1 && qwd[0] == AUTOSTOP_CODE) {
                            break;
                        } else {
                            int atwResult = audioTrack.write(qwd, 0, size); // AudioTrack 에 write를 하면 스피커로 송출됨
                            if (mListener != null) {
                                mListener.onWrite(qwd, atwResult);
                            }
                        }
                    }
/*
                    (MainActivity.this).runOnUiThread(new Runnable() { // UI 컨트롤을 위해
                        @Override
                        public void run() {
                            isPlaying = false;
                            mBtPlay.setText("Play");
                        }
                    });
*/
                }
                mbPlaying = false;

                clear();

                audioTrack.stop();
                audioTrack.release();

                if (mListener != null)
                    mListener.onStop();
            }
        });
        mPlayThread.start();
    }

    public void stop() {
        if(mbPlaying == true) {
            mbPlaying = false;

            if (mPlayThread != null) {
                try {
                    mPlayThread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        mPlayThread = null;
    }

    /*
    public void playFile(int sampleRate, int channelCount, int audioFormat, int bufferSize) {
        mSampleRate = sampleRate;
        mChannelCount = channelCount;
        mAudioFormat = audioFormat;
        mBufferSize = bufferSize;

        Thread playThread = new Thread(new Runnable() {
            @Override
            public void run() {
                AudioTrack audioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, mSampleRate, mChannelCount, mAudioFormat, mBufferSize, AudioTrack.MODE_STREAM); // AudioTrack 생성

                byte[] writeData = new byte[mBufferSize];
                FileInputStream fis = null;
                try {
                    fis = new FileInputStream(mFilePath);
                }catch (FileNotFoundException e) {
                    e.printStackTrace();
                }

                DataInputStream dis = new DataInputStream(fis);
                audioTrack.play();  // write 하기 전에 play 를 먼저 수행해 주어야 함

                while(isPlaying) {
                    try {
                        int ret = dis.read(writeData, 0, mBufferSize);
                        if (ret <= 0) {
                            (MainActivity.this).runOnUiThread(new Runnable() { // UI 컨트롤을 위해
                                @Override
                                public void run() {
                                    isPlaying = false;
                                    mBtPlay.setText("Play");
                                }
                            });
                            break;
                        }
                        audioTrack.write(writeData, 0, ret); // AudioTrack 에 write 를 하면 스피커로 송출됨
                    }catch (IOException e) {
                        e.printStackTrace();
                    }

                }
                audioTrack.stop();
                audioTrack.release();
                audioTrack = null;

                try {
                    dis.close();
                    fis.close();
                }catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void onPlay(View view) {
        if(isPlaying == true) {
            isPlaying = false;
            mBtPlay.setText("Play");
        }
        else {
            isPlaying = true;
            mBtPlay.setText("Stop");

            if(mAudioTrack == null) {
                mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, mSampleRate, mChannelCount, mAudioFormat, mBufferSize, AudioTrack.MODE_STREAM);
            }
            mPlayThread.start();
        }

    }
*/

    //----------------------------------------------------
    public interface OnPCMPlayerListener {
        void onPlay();
        void onWrite(byte[] pcmData, int result);
        void onStop();
    }
}
