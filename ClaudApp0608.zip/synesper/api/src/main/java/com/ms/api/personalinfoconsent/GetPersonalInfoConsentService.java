package com.ms.api.personalinfoconsent;

import retrofit2.Call;
import retrofit2.http.GET;

public interface GetPersonalInfoConsentService {
//    @GET("getpersonalinfoconsent")
//    Call<String> getPersonalInfoConsent();

    @GET("getpersonalinfoconsent")
    Call<String> getPersonalInfoConsent();

}
