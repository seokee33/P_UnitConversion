package kr.claud.synesper.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import kr.claud.synesper.R;
import kr.claud.synesper.device.SynesperAdapter;

public class SettingsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int VIEWTYPE_UNDEF = 0;
    public static final int VIEWTYPE_HEADER = 1;
    public static final int VIEWTYPE_SETTING = 2;

    private ArrayList<SettingsItem> mList;

    public interface OnItemClickListener {
        void onItemClick(View v, SettingsItem item, int pos);
    }
    private OnItemClickListener mOnItemClickListener = null;
    public void setOnItemClickListener(OnItemClickListener l) {
        mOnItemClickListener = l;
    }

    public SettingsAdapter(ArrayList<SettingsItem> list) {
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View view;
        switch (viewType) {
            case VIEWTYPE_HEADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.settings_header_item, parent, false);
                viewHolder = new HeaderViewHolder(view);
                break;
            case VIEWTYPE_SETTING:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.settings_setting_item, parent, false);
                viewHolder = new SettingsViewHolder(view);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        SettingsItem item = mList.get(position);
        if (holder instanceof HeaderViewHolder) {
            HeaderViewHolder holdeHeader = (HeaderViewHolder) holder;
            holdeHeader.header.setText(item.text);
        } else if (holder instanceof SettingsViewHolder) {
            SettingsViewHolder holderSettings = (SettingsViewHolder) holder;
            if (item.image > 0) {
                holderSettings.image.setImageResource(item.image);
                holderSettings.image.setVisibility(View.VISIBLE);
            } else {
                holderSettings.image.setVisibility(View.GONE);
            }

            holderSettings.text.setText(item.text);

            if (item.action > 0) {
                holderSettings.action.setImageResource(item.action);
                holderSettings.action.setVisibility(View.VISIBLE);
            } else {
                holderSettings.action.setVisibility(View.GONE);
            }

            if (item.textRight == null) {
                holderSettings.textRight.setVisibility(View.GONE);
            } else {
                holderSettings.textRight.setText(item.textRight);
                holderSettings.textRight.setVisibility(View.VISIBLE);
            }

            if (item.textBottom == null) {
                holderSettings.textBottom.setVisibility(View.GONE);

            } else {
                holderSettings.textBottom.setText(item.textBottom);
                holderSettings.textBottom.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mList != null && position < mList.size()) {
            SettingsItem item = mList.get(position);
            return item.type;
        }
        return VIEWTYPE_UNDEF;
    }

    @Override
    public int getItemCount() {
        return (null != mList ? mList.size() : 0);
    }


    public SettingsItem addHeaderItem(String text) {
        SettingsItem item = new SettingsItem(VIEWTYPE_HEADER, -1, text, -1, null, null);
        boolean bRet = mList.add(item);
        if (bRet) {
            notifyDataSetChanged();
            return item;
        }
        return new SettingsItem(VIEWTYPE_UNDEF, -1, null, -1, null, null);
    }

    public SettingsItem addSettingsItem(int image, String text, int action, String textRight) {
        SettingsItem item = new SettingsItem(VIEWTYPE_SETTING, image, text, action, textRight, null);
        boolean bRet = mList.add(item);
        if (bRet) {
            notifyDataSetChanged();
            return item;
        }
        return new SettingsItem(VIEWTYPE_UNDEF, -1, null, -1, null, null);
    }

    //------------------------------------------------------
    public static class SettingsItem {
        private int type;
        private int tag;

        private int image;
        private String text;
        private int action;
        private String textRight;
        private String textBottom;

        public SettingsItem(int type, int image, String text, int action, String textRight, String textBottom) {
            this.type = type;
            this.tag = -1;

            this.image = image;
            this.text = text;
            this.action = action;
            this.textRight = textRight;
            this.textBottom = textBottom;
        }

        public int getType() {
            return type;
        }

        public int getTag() {
            return tag;
        }

        public void setTag(int tag) {
            this.tag = tag;
        }
    }

    public class HeaderViewHolder extends RecyclerView.ViewHolder {

        protected TextView header;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);

            this.header = (TextView) itemView.findViewById(R.id.header);
        }
    }

    public class SettingsViewHolder extends RecyclerView.ViewHolder {

        protected ImageView image;
        protected TextView text;
        protected ImageView action;
        protected TextView textRight;
        protected TextView textBottom;


        public SettingsViewHolder(@NonNull View itemView) {
            super(itemView);

            this.image = (ImageView) itemView.findViewById(R.id.image);
            this.text = (TextView) itemView.findViewById(R.id.text);
            this.action = (ImageView) itemView.findViewById(R.id.action);
            this.textRight = (TextView) itemView.findViewById(R.id.textRight);
            this.textBottom = (TextView) itemView.findViewById(R.id.textBottom);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnItemClickListener != null) {
                            mOnItemClickListener.onItemClick(v, mList.get(pos), pos);
                        }
                    }
                }
            });
        }
    }
}
