package kr.claud.synesper.ui.measurement;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.util.Log;

import org.json.JSONException;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import com.ms.api.file.FileUploader;

import kr.claud.synesper.AppData;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.dsp.BeatDetector;
import kr.claud.synesper.media.SmdFile;
import kr.claud.synesper.media.SmdFileWriter;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MeasurementManager {
    public static final String TAG = "MeasurementManager";

    // 0: mom, 1: baby
    public static final int BEATTYPE_MOM = 0;
    public static final int BEATTYPE_BABY = 1;

    public interface OnMeasurementManagerListener {
        void onStateChanged(boolean bMeasurement);
        void onTimeLapse(int timeLapse);
        void onBeatDetected(int type);
        boolean onFileOpend();
        boolean onFileClosed();
    }
    private OnMeasurementManagerListener mOnMeasurementManagerListener = null;
    public void setOnMeasurementManagerListener(OnMeasurementManagerListener l) {
        mOnMeasurementManagerListener = l;
    }

    private Context mCtx;
    private Timer mTimer;

    private boolean bMeasuring;
    private long mStartMillis;
    private int mSeqNum;
    private SmdFileWriter mSmdFileWriter;

    private BeatDetector mBeatDetector;

    private int mBabyMin;
    private int mBabyMax;
    private int mMomMin;
    private int mMomMax;

    private int mBabySum;
    private int mBabyCount;

    private int mMomSum;
    private int mMomCount;

    private int mTimeLapse;


    // Constructor
    public MeasurementManager(Context ctx, OnMeasurementManagerListener l) {
        setOnMeasurementManagerListener(l);

        mCtx = ctx;
        bMeasuring = false;
        mStartMillis = 0;
        mSeqNum = 0;
        mSmdFileWriter = new SmdFileWriter();

        mBeatDetector = new BeatDetector();
        mBeatDetector.init();

        mBabyMin = -1;
        mBabyMax = -1;
        mBabySum = 0;
        mBabyCount = 0;

        mMomMin = -1;
        mMomMax = -1;
        mMomSum = 0;
        mMomCount = 0;

        mTimer = null;
        mTimeLapse = 0;
    }

    public boolean isMeasuring() {
        return bMeasuring;
    }


    // Kim -> 실제 기록하는 곳
    public void startMeasurement() {
        if (!bMeasuring) {
            String fileName = SmdFile.stringSmdFileName(new Date());
            if (mSmdFileWriter.openCache(mCtx, fileName)) {
                bMeasuring = true;

                UserData ud = AppData.I().mUserData;
                DBHelper.UserItem ui = ud.user(); //kim(수정필요)
                mSmdFileWriter.writeHeader(ui.name, ud.userWeek(), new Date(), DBHelper.dateFromString(ui.delivery, null));

                mStartMillis = System.currentTimeMillis();
                mSeqNum = 0;

                if (mOnMeasurementManagerListener != null) {
                    boolean bOpend = mOnMeasurementManagerListener.onFileOpend();
                    mOnMeasurementManagerListener.onStateChanged(bMeasuring);
                }

                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        if (mOnMeasurementManagerListener != null) {
                            mOnMeasurementManagerListener.onTimeLapse(mTimeLapse);
                        }

                        mTimeLapse++;
                    }
                };
                mTimeLapse = 0;
                mTimer = new Timer();
                mTimer.schedule(timerTask, 0, 1000);
            }

            mBabyMin = 0;
            mBabyMax = 0;
            mBabySum = 0;
            mBabyCount = 0;

            mMomMin = 0;
            mMomMax = 0;
            mMomSum = 0;
            mMomCount = 0;

            Log.d(TAG, "START measurement: filename=" + fileName);
//            //kim (지워야하는거)
//            AppData.writeState = true;
        }
    }

    public void stopMeasurement() {
        if (bMeasuring) {
            //TODO: update DB

            bMeasuring = false;
            if (mSmdFileWriter.isOpened())
                mSmdFileWriter.close();

            if (mTimer != null) {
                mTimer.cancel();
                mTimer = null;
            }

            if (mOnMeasurementManagerListener != null) {
                mOnMeasurementManagerListener.onStateChanged(bMeasuring);
            }

            Log.d(TAG, "STOP measurement");
        }
    }

    public void saveMeasurement() {
        if (bMeasuring)
            return;

        //--------------------------------------
        //mSmdFile.close();
        mSmdFileWriter.move(mSmdFileWriter.getSmdFilesDir(mCtx));
        String filePath =  mSmdFileWriter.getFilePath();
        mSmdFileWriter.clear();

        //--------------------------------------
        //TODO:
        mBabyMin = new Random().nextInt(40) + 40;   // 40 - 80
        mBabyMax = new Random().nextInt(100) + 80;; // 80 - 180
        int babyAvg = (mBabyMin + mBabyMax) / 2;
        //TODO: int babyAvg = (mBabyCount > 0) ? mBabySum / mBabyCount : 0;

        //mMomMin = new Random().nextInt(40) + 40;   // 40 - 80
        //mMomMax = new Random().nextInt(100) + 80;  // 80 - 180
        //int momAvg = (mMomMin + mMomMax) / 2;
        int momAvg = (mMomCount > 0) ? mMomSum / mMomCount : 0;

        Date today = new Date();

        Log.d(TAG, "saveMeasurement() ----------------");
        Log.d(TAG, "date=" + DBHelper.stringFromDate(today) + ": baby(" + mBabyMin + "~" + mBabyMax + ":" + babyAvg + "), mom(" + mMomMin + "~" + mMomMax + ":" + momAvg + ")");

        AppData ad = AppData.I();
        int userNum = ad.mUserData.userNum();

        int stateNetwork = ad.getNetworkInfo((Activity) mCtx);

        if(stateNetwork == 1){
            uploadServer(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath);
        }else if(stateNetwork == 2){
            if(!ad.mPrefCheckLTE){
                DialogUtil.showLTECheck((Activity) mCtx, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
            }

            if (!ad.mPrefServerOK) {
                uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, false);
                ad.mPrefServerOK = true;
            } else {
                uploadServer(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath);
            }
        }else{
            uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, false);
        }

        if (mOnMeasurementManagerListener != null) {
            mOnMeasurementManagerListener.onFileClosed();
        }

    }
    public void uploadServer(AppData ad, int userNum, Date today, int mBabyMin, int mBabyMax, int babyAvg, int mMomMin, int mMomMax, int momAvg, String filePath){
        try {
            FileUploader.uploadFile(mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, new File(filePath), new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if (response.isSuccessful()) {
                        if (response.code() == 200) {
                            ArrayList<DBHelper.MeasureItem> unSyncItems = ad.mSqliteDB.selectSyncMeasure(ad.mUserData.userNum());
                            if (unSyncItems.size() > 0) {
                                for (DBHelper.MeasureItem item : unSyncItems) {
                                    try {
                                        FileUploader.uploadFile(item.babyMin, item.babyMax, item.babyAvg, item.momMin, item.momMax, item.momAvg, new File(item.file), new Callback<ResponseBody>() {
                                            @Override
                                            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                                                if (response.isSuccessful()) {
                                                    if (response.code() == 200) {
                                                        ad.mSqliteDB.updateSyncMeasure(userNum, item.date, item.time);
                                                    }
                                                }
                                            }

                                            @Override
                                            public void onFailure(Call<ResponseBody> call, Throwable t) {

                                            }
                                        });
                                    } catch (JSONException e) {

                                    }
                                }
                            }
                            uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, true);

                        } else {
                            uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, false);
                        }
                    } else {
                        uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, false);
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    uploadSQLite(ad, userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, false);
                }
            });

        } catch (JSONException e) {

        }
    }

    public void uploadSQLite(AppData ad, int userNum, Date today, int mBabyMin, int mBabyMax, int babyAvg, int mMomMin, int mMomMax, int momAvg, String filePath, boolean uploadState){
        ad.updateMeasurement(userNum, today, mBabyMin, mBabyMax, babyAvg, mMomMin, mMomMax, momAvg, filePath, uploadState);
        //TODO: ad.updateNoticeBaby(userNum, today, mBabyMin, mBabyMax);
        ad.updateNoticeMom(userNum, today, mMomMin, mMomMax);
    }
    public int getPCGBpm() {
        //TODO: calc bpm
        return 70;
    }

    public int getPPGBpm() {
        int bpm = 0;
        if (mBeatDetector != null) {
            bpm = (int) mBeatDetector.getRate();
        }
        return bpm;
    }

    public int getPPGMax() {
        return mMomMax;
    }

    public int getPPGMin() {
        return mMomMin;
    }

    // VoBLE
    public void processMeasurementVoice(byte[] txValue, short[] samples) {
        if (isMeasuring()) {
            byte type = SmdFile.ChunkType.PCG.getIndex();

            long millis = System.currentTimeMillis();
            int timestamp = (int) (millis - mStartMillis);
            int seqNum = mSeqNum;
            mSeqNum += 1;

            byte bpm = (byte) getPCGBpm();

            short count = (short) samples.length;
            //Log.i("kim","Length : "+txValue.length);
            //Log.i("kim", Arrays.toString(txValue));
            byte[] data = txValue;
            int dataLength = txValue.length;

            mSmdFileWriter.writeChunk(type, bpm, seqNum, timestamp, count, data, dataLength);
            //Log.i("kim","SMD Write Count : "+(++AppData.writeCount));
        }
    }

    // PPG Signal
    public void processMeasurementPPG(byte[] txValue, short[] samples) {
        if (isMeasuring()) {
            byte type = SmdFile.ChunkType.PPG.getIndex();

            long millis = System.currentTimeMillis();
            int timestamp = (int) (millis - mStartMillis);
            int seqNum = mSeqNum;
            mSeqNum += 1;

            //TODO: calc bpm ---> from synesper
            boolean bBeat = mBeatDetector.checkForBeat(samples, new BeatDetector.OnBeatDetectorListener() {
                @Override
                public void onDetect() {
                    if (mOnMeasurementManagerListener != null) {
                        mOnMeasurementManagerListener.onBeatDetected(BEATTYPE_MOM);  // 0: mom, 1: mom
                    }
                }
            });

            int bpm = getPPGBpm();
            if (bBeat) {
                mMomSum += bpm;
                mMomCount++;

                if (mMomMin == 0) {
                    mMomMin = bpm;
                } else if (mMomMin > bpm) {
                    mMomMin = bpm;
                }
                if (mMomMax == 0) {
                    mMomMax = bpm;
                } else if (mMomMax < bpm) {
                    mMomMax = bpm;
                }
            }
            short count = (short) samples.length;
            byte[] data = txValue;
            int dataLength = txValue.length;

            mSmdFileWriter.writeChunk(type, (byte) bpm, seqNum, timestamp, count, data, dataLength);
        }
    }
}