package kr.claud.synesper.ui.register;

import androidx.lifecycle.Observer;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.ms.api.login.Login;
import kr.claud.libs.crypto.AES256Chiper;
import kr.claud.libs.enums.KeySize;
import kr.claud.synesper.AppData;
import kr.claud.synesper.R;
import kr.claud.synesper.RegisterActivity;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.databinding.FragmentRegisterInfoBinding;
import kr.claud.synesper.dialog.DeliveryPickerDialog;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.dialog.ProfilePhotoDialog;
import kr.claud.synesper.media.ProfileImage;
import ky.labsource.widget.CircleImageView;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterInfoFragment extends RegisterFragment {
    public static final String TAG = "RegisterInfoFragment";

    public static RegisterInfoFragment newInstance() {
        return new RegisterInfoFragment();
    }

    private FragmentRegisterInfoBinding binding;

    private Bitmap bitmapPhoto = null;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mFragmentPage = 1;
        binding = FragmentRegisterInfoBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        final CircleImageView profilePhoto = binding.imageViewPhoto;
        final Button nextButton = binding.buttonNext;

        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final EditText passwordConfirmEditText = binding.passwordConfirm;

        final EditText confirmEditText = binding.passwordConfirm;
        final EditText emailEditText = binding.editTextEmail;
        final EditText nameEditText = binding.editTextName;
        final EditText deliveryEditText = binding.editTextDelivery;

//        if (BuildConfig.USER_TYPE == BuildConfig.USER_TYPE_SINGLE) {
//            AppData ad = AppData.I();
//            usernameEditText.setText(ad.mRootUser);
//            usernameEditText.setEnabled(false);
//        }

        mViewModel.getRegisterFormState().observe(getViewLifecycleOwner(), new Observer<RegisterFormState>() {
            @Override
            public void onChanged(RegisterFormState registerFormState) {
                if (registerFormState == null) {
                    return;
                }
                nextButton.setEnabled(registerFormState.isDataValid());
                if (registerFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(registerFormState.getUsernameError()));
                }
                if (registerFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(registerFormState.getPasswordError()));
                }
                if (registerFormState.getPasswordConfirmError() != null) {
                    passwordConfirmEditText.setError(getString(registerFormState.getPasswordConfirmError()));
                }
            }
        });

        mViewModel.getRegisterResult().observe(getViewLifecycleOwner(), new Observer<RegisterResult>() {
            @Override
            public void onChanged(RegisterResult registerResult) {
                if (registerResult == null)
                    return;

                //TODO:
                //loadingProgressBar.setVisibility(View.GONE);
                if (registerResult.getError() != null) {
                    //changeEditBoxAlertColor();
                    //showLoginFailed(registerResult.getError());
                }
                if (registerResult.getSuccess() != null) {
                    //updateUiWithUser(registerResult.getSuccess());
                    frgmentListener_onFragmentNext();
                }
            }
        });

        // Contextual processing listener when entering member ID
        TextWatcher afterUsernameChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                mViewModel.registerDataChanged(usernameEditText.getText().toString(), null, null);


            }
        };

        // Contextual processing listener when entering member password
        TextWatcher afterPasswordChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                mViewModel.registerDataChanged(usernameEditText.getText().toString(), passwordEditText.getText().toString(), passwordConfirmEditText.getText().toString());
            }
        };

        usernameEditText.addTextChangedListener(afterUsernameChangedListener);
        passwordEditText.addTextChangedListener(afterPasswordChangedListener);
        passwordConfirmEditText.addTextChangedListener(afterPasswordChangedListener);
        confirmEditText.addTextChangedListener(afterPasswordChangedListener);

        confirmEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    //mViewModel.register(usernameEditText.getText().toString(), passwordEditText.getText().toString(), passwordConfirmEditText.getText().toString());
                }
                return false;
            }
        });

        //emailEditText.addTextChangedListener(afterTextChangedListener);
        //nameEditText.addTextChangedListener(afterTextChangedListener);
        //nameEditText.addTextChangedListener(afterTextChangedListener);

        initDeliveryWidgets();

        profilePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectPhotoSource();
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String passwd = passwordEditText.getText().toString();
                String passwdConfirm = passwordConfirmEditText.getText().toString();

                Activity acty = getActivity();
                // Make sure that you have filled all the data
                RegisterFormState registerFormState = mViewModel.getRegisterFormState().getValue();
                if (registerFormState.getPasswordError() != null) {
                    DialogUtil.showDialogMessage(acty, "비밀번호", "잘못된 비밀번호 형식입니다. 다시 입력하세요.", null);
                    return;
                }
                if (registerFormState.getPasswordConfirmError() != null) {
                    DialogUtil.showDialogMessage(acty, "비밀번호 확인", "잘못된 비밀번호 형식입니다. 다시 입력하세요.", null);
                    return;
                }

                if (passwd.compareTo(passwdConfirm) != 0) {
                    DialogUtil.showDialogMessage(acty, "비밀번호 확인", "비밀번호를 확인하고 다시 입력하세요.", null);
                    return;
                }

                if (nameEditText.getText().toString().length() == 0) {
                    DialogUtil.showDialogMessage(acty, "이름", "이름을 입력하세요.", null);
                    return;
                }

                // Duplicate ID check
                duplicateID(usernameEditText.getText().toString());
            }
        });
    }

    /**
     * Duplicate Check Id
     * id : UserId
     */
    private void duplicateID(String id) {
        Activity acty = getActivity();
        Login.checkId(id, new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    if (response.code() == 200) {
                        try {
                            String result = response.body().string();
                            Log.i("checkId", result);
                            if (result.equals("DUPLICATE")) {
                                DialogUtil.showDialogMessage(acty, "아이디 중복", "다른 아이디를 사용해 주세요.", null);
                            } else {
                                // Save user information in ViewModel
                                saveViewModel(binding.password.getText().toString(), binding.username.getText().toString(), binding.editTextName.getText().toString(), binding.editTextEmail.getText().toString(), binding.editTextDelivery.getText().toString());
                                join();
                            }
                        } catch (IOException e) {
                            Log.e("checkID", e.toString());
                            throw new RuntimeException(e);
                        }
                    } else {
                        DialogUtil.showDialogMessage(acty, "인터넷 연결 문제", "데이터 및 와이파이를 확인해주세요", null);
                        return;
                    }
                } else {
                    Log.i("kim(LoginAtivity code)", response.code() + "번");
                    DialogUtil.showDialogMessage(acty, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                    Log.e("checkID", "response is null");
                    return;
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Log.e("checkID", t.toString());
                return;
            }
        });
    }

    /**
     * Save user information in ViewModel
     */
    private void saveViewModel(String passwordEditText, String usernameEditText, String nameEditText, String emailEditText, String deliveryEditText) {
        String passwdAES;
        try {
            AES256Chiper aes = new AES256Chiper(AppData.aesKeyStr, KeySize.KEYSIZE16, AppData.scrambles);
            passwdAES = aes.AES_Encode(passwordEditText);
        } catch (UnsupportedEncodingException | NoSuchPaddingException |
                 IllegalBlockSizeException | NoSuchAlgorithmException |
                 BadPaddingException | InvalidKeyException |
                 InvalidAlgorithmParameterException e) {
            throw new RuntimeException(e);
        }
        mViewModel.mUserRegister.setUserId(usernameEditText);
        mViewModel.mUserRegister.setUserPasswd(passwdAES);
        mViewModel.mUserRegister.setUserName(nameEditText);
        mViewModel.mUserRegister.setUserEmail(emailEditText);
        mViewModel.mUserRegister.setUserDelivery(deliveryEditText);

        if (bitmapPhoto != null) {
            ProfileImage pi = mViewModel.mUserRegister.mProfileImage;
            pi.setImage(bitmapPhoto);
            pi.saveToJpeg(mViewModel.mUserRegister.userId());
        }
    }

    /**
     * Register UserInfo
     */
    private void join() {
        Activity acty = getActivity();
        try {
            Login.join(mViewModel.mUserRegister.mUser.id, mViewModel.mUserRegister.mUser.email, mViewModel.mUserRegister.mUser.name, binding.password.getText().toString(), mViewModel.mUserRegister.mUser.delivery, new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    if (response.isSuccessful()) {
                        if (response.code() == 200) {

                            mViewModel.next(new RegisterResult(new RegisteredInUserView(binding.editTextName.getText().toString())));
                        } else {
                            Log.i("kim(LoginAtivity code)", response.code() + "번");
                            DialogUtil.showDialogMessage(acty, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                        }
                    } else {
                        Log.i("kim(LoginAtivity code)", response.code() + "번");
                        DialogUtil.showDialogMessage(acty, "서버 연결 문제", "죄송합니다. 잠시후 다시 실행해주세요.", null);
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    DialogUtil.showDialogMessage(acty, "회원가입 실패", "실패!!", null);
                    Log.e("registerUser Error", call.toString());    //수정
                }
            });
        } catch (JSONException e) {
            DialogUtil.showDialogMessage(acty, "회원가입 실패", "실패!!", null);
            Log.e("registerUser Error", e.toString()); //수정
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    public void selectPhotoSource() {
        DialogUtil.showProfilePhoto(getContext(), new ProfilePhotoDialog.ProfilePhotoDialogListener() {
            @Override
            public void onPositiveClicked(String result) {
                RegisterActivity racty = (RegisterActivity) getActivity();
                racty.clickProfilePhotoByInfoFragment(result);
            }

            @Override
            public void onNegativeClicked() {

            }
        });
    }

    public void updateProfilePhoto(Bitmap bitmap) {
        if (bitmap != null) {
            binding.imageViewPhoto.setImageBitmap(bitmap);
        } else {
            binding.imageViewPhoto.setImageResource(R.drawable.profile_app_bar_icon1);
        }

        bitmapPhoto = bitmap;
        //updateNextButtonUi();
    }
/*
    public void updateNextButtonUi() {
        if (photoChanged || nameChanged || deliveryChanged) {
            nextButton.setEnabled(true);
        } else {
            nextButton.setEnabled(false);
        }
    }
*/

    private void initDeliveryWidgets() {
        final ImageView deliveryImageView = binding.imageViewCalendar;
        deliveryImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtil.showDeliveryPicker(getContext(), new DeliveryPickerDialog.DeliveryPickerDialogListener() {
                    @Override
                    public void onClearClicked() {

                    }

                    @Override
                    public void onPositiveClicked(int year, int month, int day) {
                        String szDelivery = DBHelper.stringDateFrom(year, month, day);
                        String szWeek = UserData.weeksPregnantFromDelivery(new Date(), year, month, day) + " " + getContext().getString(R.string.signup_n_week);
                        binding.editTextDelivery.setText(szDelivery);
                        binding.textViewWeek.setText(szWeek);
                    }

                    @Override
                    public void onNegativeClicked() {

                    }
                });
            }
        });
    }
}