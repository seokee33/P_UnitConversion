package ky.labsource.common;

import android.graphics.Canvas;

public interface ViewLayerIface {

    interface OnLayerInvalidListener {
        void onInvalidate(ViewLayer layer, boolean bInvalid);
    }

    interface OnLayerDrawListener {
        boolean onDraw(ViewLayer layer, Canvas canvas);
    }

    interface IResources {
        boolean createObjects();
        void destroyObjects();
    }
}
