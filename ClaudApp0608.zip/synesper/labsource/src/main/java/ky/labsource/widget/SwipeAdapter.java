package ky.labsource.widget;


import android.content.Context;
//import android.support.annotation.LayoutRes;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewParent;
import android.widget.BaseAdapter;
import android.widget.ListView;

import androidx.annotation.LayoutRes;


public abstract class SwipeAdapter extends BaseAdapter {
    public static final String TAG = "SwipeAdapter";

    private Context context;

    protected int swipeKey;
    public int getSwipeKey() { return swipeKey; }
    public void setSwipeKey(int key) { swipeKey = key; }

    protected int positionPrevious;
    protected int positionSelected;
    public int getPositionSelected() { return positionSelected; }
    public void setSelectedItem(int pos) {
        positionPrevious = positionSelected;

        if (positionSelected == pos) {
            positionSelected = -1;
        }
        else
            positionSelected = pos;
    }

    public void clearItemSelection() {
        positionPrevious = -1;
        positionSelected = -1;
    }


    protected int mRightWidth = 200;
    public int getRightWidth() { return mRightWidth; }
    public void setRightWidth(int width) { mRightWidth = width; }

    protected void registerOnItemClickListener(View v, final int position, final View parent) {
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((parent != null) && (parent instanceof  ListView)) {
                    ((ListView) parent).performItemClick(v, position, getItemId(position));
                }
            }
        });
    }

    protected void registerOnItemChildClickListener(View v, final int position, final View parent) {
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if ((parent != null) && (parent instanceof  SwipeListView)) {
                    ((SwipeListView) parent).performItemChildClick(v, position, getItemId(position));
                }
            }
        });
    }


    protected void registerClickListener(View v, final int position) {
        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewParent parent = v.getParent();
                while (parent != null) {
                    if ((parent instanceof SwipeListView) || (parent instanceof ListView)) {
                        break;
                    }
                    parent = parent.getParent();
                }

                if (parent != null) {
                    ((ListView) parent).performItemClick(v, position, getItemId(position));
                }

                //if (mItemChildClickListener != null) {
                //    mItemChildClickListener.onClick(v, position);
                //}
            }
        });
    }


    public SwipeAdapter(Context context) {
        this.context = context;
        this.swipeKey = -1;

        this.positionPrevious = -1;
        this.positionSelected = -1;
    }


    public void enableSwipeView(View v, boolean bEnable) {
        if (swipeKey != -1)
            v.setTag(swipeKey, Boolean.valueOf(bEnable));
    }

    public boolean isSwipeView(View v) {
        if (swipeKey == -1)
            return false;

        Boolean tag = (Boolean) v.getTag(swipeKey);
        if (tag != null)
            return tag.booleanValue();
        return false;
    }


    public View getSwipeView(int position, View convertView, @LayoutRes int resource, @LayoutRes int resourceSelected) {
        LayoutInflater inflater = LayoutInflater.from(context);
        int resId = (position == getPositionSelected()) ? resourceSelected : resource;
        View v;

        if (convertView != null && positionSelected != position && positionPrevious != position) {
            v = convertView;
        } else {
            v = inflater.inflate(resId, null);
        }
        return v;
    }



/*
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewGroup vg;
        LayoutInflater inflater = LayoutInflater.from(context);

        if (position == positionSelected) {
            vg = (ViewGroup) inflater.inflate(R.layout.device_element_selected, null);
        }
        else {
            //if (convertView != null) {
            //    vg = (ViewGroup) convertView;
            //} else {
                vg = (ViewGroup) inflater.inflate(R.layout.device_element, null);
            //}
        }


        if (position == positionSelected) {
            final ImageView ivConnect = vg.findViewById(R.id.imageViewConnect);
            ivConnect.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                }
            });
        }

        return vg;
    }
    */
}