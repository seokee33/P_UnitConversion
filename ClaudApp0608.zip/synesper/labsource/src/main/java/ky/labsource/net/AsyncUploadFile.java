package ky.labsource.net;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AsyncUploadFile extends AsyncTask<String, Void, JSONArray>
{
    private static final String TAG = "AsyncUploadFile";
    private static final boolean CONFIG_HTTP_UPLOAD = true;


    public interface AsyncUploadFileCallback {
        void onPreExecute(AsyncUploadFile aufTask);
        void onPostExecute(AsyncUploadFile aufTask, JSONArray paramJSONArray);
        void onError(AsyncUploadFile aufTask, String errMsg);
    }
    private AsyncUploadFileCallback _callback = null;
    public void setCallback(AsyncUploadFileCallback cb) {
        _callback = cb;
    }

    //---------------------------------------------------------
    private ProgressDialog mProgressDialog = null;

    //HttpClient httpclient;
    //HttpPost httppost;
    //List<NameValuePair> value;

    public AsyncUploadFile() {}

    protected JSONArray doInBackground(String... strings)
    {
        String fileUploadUrl = strings[0];
        String sourceFileUri = strings[1];
        String uploadFileName = strings[2];
        Log.d(TAG, sourceFileUri);

        //String[] splitStr = sourceFileUri.split(Pattern.quote("/"));
        //String fileName = strUserCode.substring(0, 4) + strUserCode.substring(5, 9) + "_" + splitStr[splitStr.length - 1];
        String fileName = uploadFileName;
        Log.d(TAG, "File Name='" + fileName + "'");

        File sourceFile = new File(sourceFileUri);
        if (!sourceFile.isFile())
        {
            if (_callback != null) {
                _callback.onError(this, "Local file not exist:" + sourceFileUri);
            }

            //imageuploaddialog.dismiss();
            //Log.e("uploadFile", "Source File not exist :"+ sourceFileUri);
            return null;
        }

        //long lFileSize = sourceFile.length();
        if (CONFIG_HTTP_UPLOAD) {
            try {
                String lineEnd = "\r\n";
                String twoHyphens = "--";
                String boundary = "*****";
                int maxBufferSize = 0x100000;
                int serverResponseCode = 0;

                FileInputStream fileInputStream = new FileInputStream(sourceFile);
                URL url = new URL(fileUploadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setUseCaches(false);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                conn.setRequestProperty("uploaded_file", fileName);

                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                dos.writeBytes(twoHyphens + boundary + lineEnd);
                //dos.writeUTF("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\"" + fileName + "\"" + lineEnd);
                dos.writeBytes(lineEnd);

                int bytesAvailable = fileInputStream.available();
                int bufferSize = Math.min(bytesAvailable, maxBufferSize);
                byte[] buffer = new byte[bufferSize];
                int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                while (bytesRead > 0) {
                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);
                }

                dos.writeBytes(lineEnd);
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
                serverResponseCode = conn.getResponseCode();
                String serverResponseMessage = conn.getResponseMessage();

                Log.i("uploadFile", "Upload File Name=" + fileName);
                Log.i("uploadFile", "HTTP Response is : " + serverResponseMessage + ": " + serverResponseCode);

                if (serverResponseCode == 200) {
                    if (_callback != null) {
                        _callback.onError(this, "HTTP Response(" + serverResponseCode + "):" + serverResponseMessage);
                    }

                    //imageuploaddialog.dismiss();
                    //mActivity.runOnUiThread(new Runnable() {
                    //    @Override
                    //    public void run() {
                    //        Toast.makeText(mContext, mActivity.getString(R.string.file_upload_complete), Toast.LENGTH_SHORT).show();
                    //    }
                    //});
                }
                fileInputStream.close();
                dos.flush();
                dos.close();
            } catch (MalformedURLException ex) {
                ex.printStackTrace();

                if (_callback != null) {
                    _callback.onError(this, ex.getMessage());
                }
                //imageuploaddialog.dismiss();
                //mActivity.runOnUiThread(new Runnable() {
                //    @Override
                //    public void run() {
                //        Toast.makeText(mContext, mActivity.getString(R.string.malformed_url), Toast.LENGTH_SHORT).show();
                //    }
                //});

                //Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
            } catch (Exception e) {
                e.printStackTrace();

                if (_callback != null) {
                    _callback.onError(this, e.getMessage());
                }
                //mActivity.runOnUiThread(new Runnable() {
                //    @Override
                //    public void run() {
                //        Toast.makeText(mContext, mActivity.getString(R.string.file_upload_fail), Toast.LENGTH_SHORT).show();
                //    }
                //});

                //Log.e("Upload file Exception", "Exception : " + e.getMessage(), e);
            }
        }
        return null;
    }

    protected void onPostExecute(JSONArray paramJSONArray)
    {
        super.onPostExecute(paramJSONArray);

        if (_callback != null) {
            _callback.onPostExecute(this, paramJSONArray);
        }

        //Log.d("ServerConnectUploadFile", "Task Completed!");
        //if (imageuploaddialog != null) {
        //    imageuploaddialog.dismiss();
        //}
    }

    protected void onPreExecute()
    {
        super.onPreExecute();

        if (_callback != null) {
            _callback.onPreExecute(this);
        }

        //Log.d("ServerConnectUploadFile", "Starting Task...");
        //imageuploaddialog = ProgressDialog.show(mContext, mActivity.getString(R.string.uploading_image), mActivity.getString(R.string.connecting_to_server), true);
    }
}
