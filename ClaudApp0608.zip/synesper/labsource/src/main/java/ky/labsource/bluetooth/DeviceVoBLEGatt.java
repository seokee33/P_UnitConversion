package ky.labsource.bluetooth;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;

import ky.labsource.bluetooth.ble.UUIDGroup;

import static android.bluetooth.BluetoothGattCharacteristic.FORMAT_UINT8;
import static ky.labsource.bluetooth.BLEManager.ACTION_DATA_AVAILABLE;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_CONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_DISCONNECTED;
import static ky.labsource.bluetooth.BLEManager.ACTION_GATT_SERVICES_DISCOVERED;

// .\voice_over_bluetooth_low_energy_app.exe -p COM18 -o my_audio_file -a 90:FD:9F:5F:D1:1B -v
/*
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)

        if (ActivityCompat.checkSelfPermission(mCtx, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

 */
public class DeviceVoBLEGatt extends DeviceGatt {
    private final static String TAG = DeviceVoBLEGatt.class.getSimpleName();

    private boolean _b_audioData = true;
    private int _u8_sampleRate = 16;
    private boolean _b_filtering = false;
    private boolean _b_encoding = true;
    private boolean _b_transfer = true;
    /*
        sr_8k = 8, sr_16k = 16,

        true,                              // Audio Data notification enabled
        sr_16k,                            // The default ADC sample rate
        false,                             // Enable filtering
        true,                              // Enable encoding
        true,                              // Enable transfer status
     */


    public DeviceVoBLEGatt(Context ctx, BluetoothDevice device) {
        super.connect(ctx, device);

        config(BluetoothDevice.PHY_LE_1M_MASK, 250);
        registerVoBLEUUID();
    }


    public void registerVoBLEUUID() {
        UUIDGroup vobleService = UUIDGroup.SERVICE(UUIDGroup.UUID_SERVICE_VOBLE.toString());
        vobleService.addCharUUID(UUIDGroup.UUID_CHAR_AUDIO_DATA);
        vobleService.addCharUUID(UUIDGroup.UUID_CHAR_SAMPLE_RATE);
        vobleService.addCharUUID(UUIDGroup.UUID_CHAR_FILTER_ENABLE);
        vobleService.addCharUUID(UUIDGroup.UUID_CHAR_ENCODING_ENABLE);
        vobleService.addCharUUID(UUIDGroup.UUID_CHAR_TRANSFER_STATUS);
        mUUIDServices.add(vobleService);
    }


    @SuppressLint("MissingPermission")
    public void enableVoBLENotification(int srValue, boolean bFilter, boolean bEncoding, boolean bTransfer)
    {
        BluetoothGattService curService = mBluetoothGatt.getService(UUIDGroup.UUID_SERVICE_VOBLE);
        if (curService == null) {
            Log.e(TAG, "Service not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }

        //----------------------------
        // 1. Audio Data
        BluetoothGattCharacteristic audioDataChar = curService.getCharacteristic(UUIDGroup.UUID_CHAR_AUDIO_DATA);
        if (audioDataChar == null) {
            Log.e(TAG, "Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }

        mBluetoothGatt.setCharacteristicNotification(audioDataChar, true);

        BluetoothGattDescriptor descriptor = audioDataChar.getDescriptor(UUIDGroup.UUID_CCCD);
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);

        //----------------------------
        // 2. Sample Rate
        BluetoothGattCharacteristic srChar = curService.getCharacteristic(UUIDGroup.UUID_CHAR_SAMPLE_RATE);
        if (srChar == null) {
            Log.e(TAG, "Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }
        byte[] srArr = new byte[1];
        srArr[0] = (byte)(srValue & 0xFF);
        srChar.setValue(srArr);
        //srChar.setValue(srValue, FORMAT_UINT8, 1);  //TODO:  ????
        //rChar.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
        boolean status = mBluetoothGatt.writeCharacteristic(srChar);
        Log.d(TAG, "write sample rate char - status=" + status);

        //----------------------------
        // 3. Filter
        BluetoothGattCharacteristic fChar = curService.getCharacteristic(UUIDGroup.UUID_CHAR_FILTER_ENABLE);
        if (fChar == null) {
            Log.e(TAG, "Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }
        byte[] fArr = new byte[1];
        fArr[0] = (byte)((bFilter) ? 1 : 0);
        fChar.setValue(fArr);
        //fChar.setValue((bFilter) ? 1 : 0, FORMAT_UINT8, 1);
        status = mBluetoothGatt.writeCharacteristic(fChar);
        Log.d(TAG, "write filter char - status=" + status);

        //----------------------------
        // 4. Encoding
        BluetoothGattCharacteristic encChar = curService.getCharacteristic(UUIDGroup.UUID_CHAR_ENCODING_ENABLE);
        if (encChar == null) {
            Log.e(TAG, "Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }
        byte[] encArr = new byte[1];
        encArr[0] = (byte)((bEncoding) ? 1 : 0);
        encChar.setValue(encArr);
        //encChar.setValue((bEncoding) ? 1 : 0, FORMAT_UINT8, 1);
        status = mBluetoothGatt.writeCharacteristic(encChar);
        Log.d(TAG, "write encoding char - status=" + status);

        //----------------------------
        // 5. Transfer Status
        BluetoothGattCharacteristic transChar = curService.getCharacteristic(UUIDGroup.UUID_CHAR_TRANSFER_STATUS);
        if (transChar == null) {
            Log.e(TAG, "Charateristic not found!");
            BLEManager.broadcastUpdate(mCtx, BLEManager.DEVICE_DOES_NOT_SUPPORT_VOBLE);
            return;
        }
        mBluetoothGatt.setCharacteristicNotification(transChar, true);

        descriptor = transChar.getDescriptor(UUIDGroup.UUID_CCCD);
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);

        //transChar.setValue((bTransfer) ? 1 : 0, FORMAT_UINT8, 1);
        //status = mBluetoothGatt.writeCharacteristic(transChar);
        //Log.d(TAG, "write transfer char - status=" + status);
    }

    //===================================
    @Override
    public void onPhyUpdate(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
        super.onPhyUpdate(gatt, txPhy, rxPhy, status);
        //Log.w(TAG, "onPhyUpdate: txPhy=" + txPhy + ", rxPhy=" + rxPhy);
    }

    @Override
    public void onPhyRead(BluetoothGatt gatt, int txPhy, int rxPhy, int status) {
        super.onPhyRead(gatt, txPhy, rxPhy, status);
        //Log.w(TAG, "onPhyRead: txPhy=" + txPhy + ", rxPhy=" + rxPhy);
    }

    @SuppressLint("MissingPermission")
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
        String intentAction;
        mConnectionState = newState;

        if (newState == BluetoothProfile.STATE_CONNECTED) {
            Log.i(TAG, "Connected to GATT server.");

            if (config_phy > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //phyOptions – preferred coding to use when transmitting on the LE Coded PHY. Can be one of BluetoothDevice.PHY_OPTION_NO_PREFERRED, BluetoothDevice.PHY_OPTION_S2 or BluetoothDevice.PHY_OPTION_S8
                mBluetoothGatt.setPreferredPhy(config_phy, config_phy, BluetoothDevice.PHY_OPTION_NO_PREFERRED);
            }

            if (config_mtu > 0) {
                gatt.requestMtu(config_mtu);
            } else {
                // Attempts to discover services after successful connection.
                gatt.discoverServices();
                //Log.i(TAG, "Attempting to start service discovery:" + );
            }

            intentAction = ACTION_GATT_CONNECTED;
            BLEManager.broadcastUpdate(mCtx, intentAction);
        } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
            Log.i(TAG, "Disconnected from GATT server.");

            intentAction = ACTION_GATT_DISCONNECTED;
            BLEManager.broadcastUpdate(mCtx, intentAction);
        }
        //super.onConnectionStateChange(gatt, status, newState);
    }

    @Override
    public void onServicesDiscovered(BluetoothGatt gatt, int status) {
        super.onServicesDiscovered(gatt, status);

        if (status == BluetoothGatt.GATT_SUCCESS) {
            if (_b_audioData)
                enableVoBLENotification(_u8_sampleRate, _b_filtering, _b_encoding, _b_transfer);
        }
    }

    @Override
    public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        super.onCharacteristicRead(gatt, characteristic, status);
    }

    @Override
    public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
        super.onCharacteristicWrite(gatt, characteristic, status);
    }

    @Override
    public void onDescriptorRead(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        super.onDescriptorRead(gatt, descriptor, status);
    }

    @Override
    public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
        super.onDescriptorWrite(gatt, descriptor, status);
    }

    @Override
    public void onReliableWriteCompleted(BluetoothGatt gatt, int status) {
        super.onReliableWriteCompleted(gatt, status);
    }

    @Override
    public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status) {
        super.onReadRemoteRssi(gatt, rssi, status);
    }

    @Override
    public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
        super.onMtuChanged(gatt, mtu, status);
    }

    @Override
    public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
        super.onCharacteristicChanged(gatt, characteristic);
        BLEManager.broadcastUpdate(mCtx, ACTION_DATA_AVAILABLE, characteristic);
    }
    //===================================
}
