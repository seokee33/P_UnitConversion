package ky.labsource.widget;

import android.content.Context;

public class DisplayUtils {
	public static float DPFromPixel(Context context, float pixel) {
		return (pixel / context.getResources().getDisplayMetrics().density);
	}
	
	public static float PixelFromDP(Context context, float DP) {
		return (DP * (context.getResources().getDisplayMetrics().density));
	}
}
