package kr.claud.synesper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

public class SplashActivity extends AppCompatActivity {

    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {  // 실행이 끝난후 확인 가능
            switch (msg.what) {

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        AppData appData = AppData.New(SplashActivity.this);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                AppData.loadPreferences(SplashActivity.this);


                Intent intent = new Intent(SplashActivity.this, UserActivity.class);
                startActivity(intent);

                finish();
                //mHandler.sendEmptyMessage(0);
            }
        }, 3000);
    }

    @Override
    protected void onStop() {
        super.onStop();

        AppData.storePreferences(this);
    }
}