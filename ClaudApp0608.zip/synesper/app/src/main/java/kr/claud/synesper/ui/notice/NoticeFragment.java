package kr.claud.synesper.ui.notice;

import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Date;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.MainActivity;
import kr.claud.synesper.R;
import kr.claud.synesper.adapter.HcalDataDetailAdapter;
import kr.claud.synesper.adapter.HcalNoticeAdapter;
import kr.claud.synesper.adapter.HcalNoticeDetailAdapter;
import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.databinding.FragmentNoticeBinding;
import kr.claud.synesper.dialog.DatePickerDialog;
import kr.claud.synesper.dialog.DialogUtil;
import kr.claud.synesper.ui.measurement.MeasurementCache;
import kr.claud.synesper.ui.measurement.MeasurementFragment;


/*
   알림 메시지:
   새 장치와 연결되었습니다.

   17주 태아의 심박 평균은 160 ~ 170 bpm로 비슷한 주수의 태아의 심박 평균수치보다 높게(낮게) 측정되었습니다.
   설정된 임신부 맥박은 60 ~ 80 bpm로 설정치보다 높게(낮게) 측정되었습니다.
 */

public class NoticeFragment extends Fragment {
    public static final String TAG = "NoticeFragment";

    private FragmentNoticeBinding binding;
    private NoticeViewModel noticeViewModel;

    private TextView mHcalNoticeTextView;
    private ImageView mImageViewDatePicker;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        noticeViewModel = new ViewModelProvider(this).get(NoticeViewModel.class);
        noticeViewModel.createAdapter(getContext());

        binding = FragmentNoticeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        initButton(root);
        initHcalNotice(root);
        initHcalNoticeDetail(root);
        //final TextView textView = binding.textNotice;
        //noticeViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        saveRecyclerViewState();

        MainActivity macty = (MainActivity) getActivity();
        macty.destroyChildFragment(NoticeFragment.class);

        super.onDestroyView();
        binding = null;
    }

    private void initButton(View root) {
        mImageViewDatePicker = (ImageView) root.findViewById(R.id.imageViewDatePicker);
        mImageViewDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DialogUtil.showDatePicker(getContext(), new DatePickerDialog.DatePickerDialogListener() {
                    @Override
                    public void onPositiveClicked(int year, int month, int day) {
                        populateHcalNoticeDetail(DateUtil.dateFrom(year, month, day));
                    }

                    @Override
                    public void onNegativeClicked() {

                    }
                });
            }
        });
    }

    //----------------------------------------------------
    // Hcal Notice
    private HcalNoticeAdapter.OnAdapterListener mOnAdapterListener = new HcalNoticeAdapter.OnAdapterListener() {
        @Override
        public void onItemClick(View v, HcalNoticeAdapter.HcalNoticeItem item, int pos) {
            Log.d(TAG, "onItemClick: bt addr=[" + item.getWeekday() + "] selected!!!");
            populateHcalNoticeDetail(item.getDate());
        }

        @Override
        public void onItemChanged(HcalNoticeAdapter adapter, int firstPos, int lastPos) {
            LinearLayoutManager layoutManager = (LinearLayoutManager) mHcalNoticeView.getLayoutManager();
            if (layoutManager != null) {
                firstPos = layoutManager.findFirstCompletelyVisibleItemPosition();
                lastPos = layoutManager.findLastCompletelyVisibleItemPosition();
            }

            int centerPos = (firstPos + lastPos) / 2;
            HcalNoticeAdapter.HcalNoticeItem item = adapter.getItem(centerPos);
            if (item != null) {
                int year = item.getYear();
                int month = item.getMonth();
                String sz = String.format("%4d년 %02d월", year, month);
                mHcalNoticeTextView.setText(sz);
            }

            //Log.d(TAG, "Item Count=" + adapter.getItemCount());
        }
    };



    private HcalNoticeDetailAdapter.OnAdapterListener mOnAdapterDetailListener = new HcalNoticeDetailAdapter.OnAdapterListener() {
        @Override
        public void onItemClick(View v, HcalNoticeDetailAdapter.HcalNoticeDetailItem item, int pos) {
        }

        @Override
        public void onItemChanged(HcalNoticeDetailAdapter adapter, int firstPos, int lastPos) {
            HcalNoticeDetailAdapter.HcalNoticeDetailItem item = adapter.getItem(firstPos);

            Log.d(TAG, "Item Count=" + adapter.getItemCount());
        }

        @Override
        public void onDelete(HcalNoticeDetailAdapter adapter, int pos) {
            HcalNoticeDetailAdapter.HcalNoticeDetailItem item = adapter.getItem(pos);
            AppData ad = AppData.I();
            int userNum = ad.mUserData.userNum();
            ad.removeNotice(userNum, item.getDate());
            adapter.removeHcalNoticeDetail(pos);

            updateHcalNotice(item.getDate());
        }
    };

    //---------------------------------------------------------
    private RecyclerView mHcalNoticeView;
    private static Parcelable recyclerViewState = null;

    private void initHcalNotice(View root) {
        noticeViewModel.setAdapterListener(mOnAdapterListener);

        mHcalNoticeTextView = (TextView) root.findViewById(R.id.textViewHcalNotice);

        mHcalNoticeView = (RecyclerView) root.findViewById(R.id.recyclerHcalNotice);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mLinearLayoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        mHcalNoticeView.setLayoutManager(mLinearLayoutManager);

        HcalNoticeAdapter adapter = noticeViewModel.getAdapter();
        mHcalNoticeView.setAdapter(adapter);
        mHcalNoticeView.addOnScrollListener(adapter.mOnScrollListener);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mHcalNoticeView.getContext(), mLinearLayoutManager.getOrientation());
        //mHcalNoticeView.addItemDecoration(dividerItemDecoration);

        mHcalNoticeView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                if (recyclerViewState != null) {
                    restoreRecyclerViewState();
                }

                if (mHcalNoticeView.getLayoutManager() != null) {
                    int pos = ((LinearLayoutManager) mHcalNoticeView.getLayoutManager()).findFirstVisibleItemPosition();
                    HcalNoticeAdapter.HcalNoticeItem ni = adapter.getItem(pos);
                    String sz = String.format("%4d년 %02d월", ni.getYear(), ni.getMonth());
                    mHcalNoticeTextView.setText(sz);
                }

                mHcalNoticeView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
        });


        //------------------------------------------
        updateHcalNotice(new Date());
    }

    private void saveRecyclerViewState() {
        if (mHcalNoticeView.getLayoutManager() != null) {
            recyclerViewState = mHcalNoticeView.getLayoutManager().onSaveInstanceState();
        }
    }

    private void restoreRecyclerViewState() {
        if (mHcalNoticeView.getLayoutManager() != null) {
            mHcalNoticeView.getLayoutManager().onRestoreInstanceState(recyclerViewState);
            recyclerViewState = null;
        }
    }

    private void updateHcalNotice(Date date) {
        AppData ad = AppData.I();
        NoticeCache.NoticeDay nd = ad.getNotice(date);
        int notice = 0;
        if (nd != null) {
            notice = nd.getCount();
        }

        HcalNoticeAdapter adapter = noticeViewModel.getAdapter();
        if (adapter.getItemCount() == 0) {
            String curDate = HcalNoticeAdapter.HcalNoticeItem.stringFromDate(date);
            adapter.addHcalNotice(curDate, notice, true);
        } else {
            adapter.invalidateHcalNotice(date, notice);
        }
    }

    //---------------------------------------------------------
    private void initHcalNoticeDetail(View root) {
        noticeViewModel.setAdapterDetailListener(mOnAdapterDetailListener);

        final RecyclerView mHcalNoticeDetailView = (RecyclerView) root.findViewById(R.id.recyclerHcalNoticeDetail);
        LinearLayoutManager mLinearLayoutManager = new LinearLayoutManager(getContext());
        mHcalNoticeDetailView.setLayoutManager(mLinearLayoutManager);
        HcalNoticeDetailAdapter adapter = noticeViewModel.getAdapterDetail();

        mHcalNoticeDetailView.setAdapter(adapter);
        mHcalNoticeDetailView.addOnScrollListener(adapter.mOnScrollListener);
        //DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(mHcalNoticeView.getContext(), mLinearLayoutManager.getOrientation());
        //mHcalNoticeView.addItemDecoration(dividerItemDecoration);

        //if (adapter.getItemCount() == 0) {
            //int day, HcalNoticeDetailItem.ItemType itype, String msg, int bpm, String result
            //adapter.addHcalNoticeDetailBaby(5, getString(R.string.notice_msg_ex1), 101, "Bad", true);
            //adapter.addHcalNoticeDetailBaby(4, getString(R.string.notice_msg_ex1), 99, "Bad", true);
            //adapter.addHcalNoticeDetailMom(4, getString(R.string.notice_msg_ex2), 170, "Bad", true);
            //adapter.addHcalNoticeDetailEtc(3, getString(R.string.notice_msg_ex3), 0, "", true);
        //}
    }

    private void populateHcalNoticeDetail(Date date) {
        noticeViewModel.clearArrayListDetail();
        HcalNoticeDetailAdapter adapter = noticeViewModel.getAdapterDetail();
        adapter.setDate(date);

        AppData ad = AppData.I();
        NoticeCache.NoticeDay nd = ad.getNotice(date);
        if (nd != null) {
            ArrayList<DBHelper.NoticeItem> items = nd.getItems();
            for (DBHelper.NoticeItem ni : items) {
                Date niDate = DBHelper.dateFromString2(ni.date, ni.time);
                if (niDate != null) {
                    if (ni.type >= 100 && ni.type < 200) {
                        String notiDecision = null;
                        if (ni.type == NoticeConstant.MBPM_LOW.getCode()) {
                            notiDecision = getString(R.string.notice_decision_low);
                        } else if (ni.type == NoticeConstant.MBPM_HIGH.getCode()) {
                            notiDecision = getString(R.string.notice_decision_high);
                        } else if (ni.type == NoticeConstant.MBPM_LOWHIGH.getCode()) {
                            notiDecision = getString(R.string.notice_decision_lowhigh);
                        }

                        if (notiDecision != null) {
                            String resFmt = getString(R.string.notice_mom_msg_template);
                            String notiMsg = String.format(resFmt, ni.avgMin + "~" + ni.avgMax, notiDecision);
                            adapter.addHcalNoticeDetailMom(niDate, notiMsg, ni.bpm, ni.avgMin, ni.avgMax, "Bad", true);
                        }
                    }
                }
            }
        }
    }
}