package kr.claud.synesper.ui.setting.menu;

import android.util.Log;

import androidx.annotation.Nullable;

/**
 * Data validation state of the login form.
 */
public class AccountFormState {
    @Nullable
    private Integer usernameError;
    @Nullable
    private Integer passwordError;
    @Nullable
    private Integer passwordNewError;
    @Nullable
    private Integer passwordConfirmError;
    private boolean isDataValid;

    AccountFormState(@Nullable Integer usernameError, @Nullable Integer passwordError, @Nullable Integer passwordNewError, @Nullable Integer passwordConfirmError) {
        this.usernameError = usernameError;
        this.passwordError = passwordError;
        this.passwordNewError = passwordNewError;
        this.passwordConfirmError = passwordConfirmError;
        this.isDataValid = false;
    }

    AccountFormState(boolean isDataValid) {
        this.usernameError = null;
        this.passwordError = null;
        this.passwordNewError = null;
        this.passwordConfirmError = null;
        this.isDataValid = isDataValid;
    }

    @Nullable
    public Integer getUsernameError() {
        return usernameError;
    }

    @Nullable
    public Integer getPasswordError() {
        return passwordError;
    }

    @Nullable
    public Integer getPasswordNewError() {
        return passwordNewError;
    }

    @Nullable
    public Integer getPasswordConfirmError() {
        return passwordConfirmError;
    }

    public boolean isDataValid() {
        return isDataValid;
    }
}