package com.ms.api.file;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.PUT;

public interface FileUploadService {
    @PUT("measure")
    Call<ResponseBody> uploadFile(@Header("Cookie") String cookie, @Body MultipartBody body);

    @PUT("test")
    Call<ResponseBody> uploadTest();

    @GET("measure/latest")
    Call<ResponseBody> checkUpload();
}