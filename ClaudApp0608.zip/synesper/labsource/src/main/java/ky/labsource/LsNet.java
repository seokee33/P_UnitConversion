package ky.labsource;

import ky.labsource.net.AsyncUploadFile;

public class LsNet {
    private static final String TAG = "LsNet";

    public static void AsyncUploadFile(String httpServer, String imagePath, String uploadName, AsyncUploadFile.AsyncUploadFileCallback cb) {
        AsyncUploadFile aufTask = new AsyncUploadFile();
        aufTask.setCallback(cb);
        aufTask.execute(httpServer, imagePath, uploadName);
    }

    public static void UploadFileToHttpServer(String httpServer, String filePath) {

    }
}