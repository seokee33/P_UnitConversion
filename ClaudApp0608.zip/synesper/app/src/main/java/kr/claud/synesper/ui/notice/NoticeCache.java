package kr.claud.synesper.ui.notice;

import android.util.Log;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import kr.claud.synesper.data.DBHelper;

public class NoticeCache {
    public static final String TAG = "NoticeCache";

    private DBHelper _db;

    public NoticeCache(DBHelper db) {
        _db = db;

        initCache();
    }

    public NoticeDay get(int userNum, Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);

        NoticeMonth mm = loadCache(userNum, year, month);
        return mm.get(day);
    }


    public boolean update(int userNum, Date date, int type, int bpm, int avgMin, int avgMax) {
        ArrayList<DBHelper.NoticeItem> notiArr = _db.selectNotice(userNum, date);
        boolean bRet = false;
        if (notiArr.size() == 0) {
            bRet = _db.insertNotice(userNum, date, type, bpm, avgMin, avgMax);
        } else {
            DBHelper.NoticeItem ni = notiArr.get(0);
            bRet = _db.updateNotice(userNum, date, type, bpm, avgMin, avgMax);
        }

        if (bRet) {
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH) + 1;
            removeMonth(year, month);
            Log.d(TAG, "update() - removeMonth:" + year + "." + month);
        }
        return bRet;
    }

    public void remove(int userNum, Date date) {
        _db.deleteNotice(userNum, date);

        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        removeMonth(year, month);
    }

    //-------------------------------------------------
    ArrayList<NoticeMonth> _months;

    private void initCache() {
        _months = new ArrayList<>();
    }

    private NoticeMonth loadCache(int userNum, int year, int month) {
        NoticeMonth mm = findMonth(year, month);
        if (mm == null) {
            mm = new NoticeMonth(year, month);
            mm.load(userNum);
            _months.add(mm);
        }
        return mm;
    }

    private NoticeMonth reloadCache(int userNum, int year, int month) {
        removeMonth(year, month);
        NoticeMonth mm = new NoticeMonth(year, month);
        mm.load(userNum);
        _months.add(mm);
        return mm;
    }

    private NoticeMonth findMonth(int year, int month) {
        for(NoticeMonth mm : _months) {
            if (mm.year == year && mm.month == month)
                return mm;
        }
        return null;
    }

    private void removeMonth(int year, int month) {
        for(NoticeMonth mm : _months) {
            if (mm.year == year && mm.month == month) {
                _months.remove(mm);
                break;
            }
        }
    }


    public class NoticeDay {
        public int day;
        public ArrayList<DBHelper.NoticeItem> _items;

        public NoticeDay(int day, ArrayList<DBHelper.NoticeItem> items) {
            this.day = day;
            this._items = items;

            for (DBHelper.NoticeItem ni : this._items) {
            }
        }

        public ArrayList<DBHelper.NoticeItem> getItems() {
            return _items;
        }

        public int getCount() {
            if (_items == null)
                return 0;
            return _items.size();
        }
    }

    public class NoticeMonth {
        public int year;
        public int month;
        ArrayList<NoticeDay> _days;

        private int refCount;

        public NoticeMonth(int year, int month) {
            this.year = year;
            this.month = month;
            _days = new ArrayList<>();

            refCount = 0;
        }

        public void load(int userNum) {
            _days.clear();
            for(int i=1 ; i<=31 ; i++) {
                Date date = DBHelper.dateFrom(year, month, i);
                ArrayList<DBHelper.NoticeItem> items = _db.selectNotices(userNum, date);
                if (items.size() > 0) {
                    NoticeDay nd = new NoticeDay(i, items);
                    _days.add(nd);
                }
            }
        }

        public NoticeDay get(int day) {
            refCount++;
            for(NoticeDay nd : _days) {
                if (nd.day == day)
                    return nd;
            }
            return null;
        }
    }
}