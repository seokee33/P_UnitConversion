package kr.claud.synesper.dsp;

public class PulseSignal {
    private final static String TAG = PulseSignal.class.getSimpleName();

    private final static int NSLOT = 4;
    private final static int NSAMPLE = 24;
    private final static int  MAXWAVE = 64;


    private MovingAverage _ma = null;
    private RemoveDC _dc = null;

    //20230224
    private static final float DC_REMOVER_ALPHA = 0.95f;
    private DCRemover _dcr = null;
    private BuLp1 _lpf = null;

    private short amplitude_avg_total;
    private short cycle_max;
    private short cycle_min;
    private boolean positive;
    private short prev_sig;

    public PulseSignal() {
        _ma = new MovingAverage();
        _dc = new RemoveDC();

        _dcr = new DCRemover(DC_REMOVER_ALPHA);
        _lpf = new BuLp1();

        init();
    }

    public void init() {
        _ma.init();
        _dc.init();

        _dcr.init(DC_REMOVER_ALPHA);
        _lpf.init();

        cycle_max = 20;
        cycle_min = -20;
        positive = false;
        prev_sig = 0;
        amplitude_avg_total = 0;
    }

    //low pass moving average filter
    public short maFilter(short value)
    {
        return _ma.filter(value);
    }

    //remove DC
    public short dcFilter(int sample)
    {
        return _dc.filter(sample);
    }

    //return true when beat detected
    public boolean isBeat(short signal)
    {
        boolean beat = false;
        //while positive slope record maximum
        if (positive && (signal > prev_sig))
            cycle_max = signal;
        //while negative slope record minimum
        if (!positive && (signal < prev_sig))
            cycle_min = signal;
        //  positive to negative i.e peak so declare beat
        if (positive && (signal < prev_sig)) {
            int amplitude = cycle_max - cycle_min;
            if (amplitude > 20 && amplitude < 3000) {
                beat = true;
                amplitude_avg_total += (amplitude - amplitude_avg_total/4);
            }
            cycle_min = 0;
            positive = false;
        }
        //negative to positive i.e valley bottom
        if (!positive && (signal > prev_sig)) {
            cycle_max= 0;
            positive = true;
        }
        prev_sig = signal; // save signal
        return beat;
    }

    //return average DC
    public int Pulse_avgDC()
    {
        return _dc.avgDC();
    }

    //return average AC
    public short Pulse_avgAC()
    {
        return (short) (amplitude_avg_total/4);
    }


    private short[] waveform = new short[MAXWAVE];
    private short[] disp_wave = new short[MAXWAVE];
    private short wavep;

    /*
     *   Record, scale  and display PPG Waveform
     */
    public void graphInit()
    {
        wavep = 0;
    }

    public void graphRecord(int waveval)
    {
        waveval = waveval/8;         // scale to fit in byte
        waveval += 128;              //shift so entired waveform is +ve
        waveval = waveval < 0 ? 0 : waveval;
        waveform[wavep] = (short) ((waveval>255) ? 255 : waveval);
        wavep = (short) ((wavep+1) % MAXWAVE);
    }

    public void graphScale()
    {
        int i;
        short maxw = 0;
        short minw = 255;
        for (i=0; i<MAXWAVE; i++) {
            maxw = waveform[i]>maxw ? waveform[i] : maxw;
            minw = waveform[i]<minw ? waveform[i] : minw;
        }

        short diff = (short) (maxw - minw + 1);
        short index = wavep;
        int idx;
        int off = 0;
        for (idx=index ; idx<MAXWAVE ; idx++)
        {
            disp_wave[off++] = (short) (31-((short)(waveform[idx]-minw)*16/diff));
        }
        for (idx=0 ; idx<index ; idx++)
        {
            disp_wave[off++] = (short) (31-((short)(waveform[idx]-minw)*16/diff));
        }
    }

    public void graphDraw(short X)
    {
        for (int i=0; i<MAXWAVE; i++)
        {
            short y = disp_wave[i];
            //PulseWaveform_drawPixel(X+i, y);
            if (i<MAXWAVE-1)
            {
                short nexty = disp_wave[i+1];
                if (nexty>y)
                {
                    //for (short iy = (short) (y+1); iy<nexty; ++iy)
                    //    PulseWaveform_drawPixel(X+i, iy);
                }
                else if (nexty<y)
                {
                    //for (short iy = (short) (nexty+1); iy<y; ++iy)
                    //    PulseWaveform_drawPixel(X+i, iy);
                }
            }
        }
    }


    //20230224
    public float dcRemover(float x) {
        return _dcr.step(x);
    }

    public float lpFilter(float x) {
        return _lpf.step(x);
    }


    //------------------------------------------------------------
    public static class MovingAverage {

        private short[] buffer = new short[NSLOT];
        private int nextslot;

        public MovingAverage() {
            init();
        }

        public void init() {
            nextslot = 0;
        }

        public short filter(short value)
        {
            buffer[nextslot] = value;
            nextslot = (nextslot+1) % NSLOT;

            int total = 0;
            if (NSLOT == 4) {
                total = buffer[0] + buffer[1] + buffer[2] + buffer[3];
            } else {
                for (int i = 0; i < NSLOT; ++i)
                    total += buffer[i];
            }
            return (short) (total/NSLOT);
        }
    }

    public static class RemoveDC {

        private int sample_avg_total;

        public RemoveDC() {
            init();
        }

        public void init() {
            sample_avg_total = 0;
        }

        //remove dc from sample
        public short filter(int sample)
        {
            sample_avg_total += (sample - sample_avg_total/NSAMPLE);
            return (short)(sample - sample_avg_total/NSAMPLE);
        }

        // return average dc
        public int avgDC()
        {
            return sample_avg_total/NSAMPLE;
        }
    }

    //20230224
    public static class DCRemover {
        private float alpha;
        private float dcw;

        public DCRemover(float alpha) {
            init(alpha);
        }

        public void init(float alpha) {
            this.alpha = alpha;
            this.dcw = 0.f;
        }

        public float step(float x) {
            float odcw = dcw;
            dcw = x + alpha * dcw;
            return dcw - odcw;
        }

        public float getDCW() {
            return dcw;
        }
    }

    public static class BuLp1 {
        private float v0;
        private float v1;

        public BuLp1() {
            init();
        }

        public void init() {
            v0 = 0.f;
            v1 = 0.f;
        }

        public float step(float x) {
            v0 = v1;
            v1 = (float)((2.452372752527856026e-1 * x) + (0.50952544949442879485 * v0));
            return (v0 + v1);
        }
    }
}
