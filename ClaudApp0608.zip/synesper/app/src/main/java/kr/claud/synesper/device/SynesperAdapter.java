package kr.claud.synesper.device;

import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import kr.claud.synesper.R;

public class SynesperAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int VIEWTYPE_HEADER = 0;
    public static final int VIEWTYPE_CONNECTED = 1;
    public static final int VIEWTYPE_CONNECTABLE = 2;

    private String mConnected;
    private ArrayList<SynesperItem> mList;

    public interface OnItemClickListener {
        void onItemClick(View v, SynesperItem item, int pos);
    }
    private OnItemClickListener mOnItemClickListener = null;
    public void setOnItemClickListener(OnItemClickListener l) {
        mOnItemClickListener = l;
    }

    public SynesperAdapter(String connected, ArrayList<SynesperItem> list) {
        this.mConnected = connected;
        this.mList = list;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        View view;
        switch (viewType) {
            case VIEWTYPE_HEADER:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.synesper_header_item, parent, false);
                viewHolder = new HeaderViewHolder(view);
                break;

            case VIEWTYPE_CONNECTED:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.synesper_connected_item, parent, false);
                viewHolder = new ConnectedViewHolder(view);
                break;

            case VIEWTYPE_CONNECTABLE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.stethodevice_item, parent, false);
                viewHolder = new SynesperViewHolder(view);
                break;
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        if (holder instanceof SynesperViewHolder) {
            int synePosition = position;
            if (mConnected != null && mConnected.length() > 0) {
                synePosition -= 2;
            }
            if (synePosition < mList.size()) {
                SynesperViewHolder synesperViewHolder = (SynesperViewHolder) holder;
                synesperViewHolder.name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
                synesperViewHolder.address.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
                synesperViewHolder.rssi.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

                synesperViewHolder.name.setGravity(Gravity.CENTER);
                synesperViewHolder.address.setGravity(Gravity.CENTER);
                synesperViewHolder.rssi.setGravity(Gravity.CENTER);

                synesperViewHolder.name.setText(mList.get(synePosition).getName());
                synesperViewHolder.address.setText(mList.get(synePosition).getAddress());
                synesperViewHolder.rssi.setText(String.valueOf(mList.get(synePosition).getRssi()));
            }
        } else if (holder instanceof HeaderViewHolder) {

        } else if (holder instanceof ConnectedViewHolder) {
            ConnectedViewHolder connectedViewHolder = (ConnectedViewHolder) holder;
            if (mConnected != null && mConnected.length() > 0) {
                connectedViewHolder.name.setText(mConnected);
            }
        }
    }

    @Override
    public int getItemViewType(int position) {
        if (mConnected != null && mConnected.length() > 0) {
            if (position == 0)
                return VIEWTYPE_HEADER;
            else if (position == 1)
                return VIEWTYPE_CONNECTED;
        }
        return VIEWTYPE_CONNECTABLE;
    }

    @Override
    public int getItemCount() {
        int count = (null != mList ? mList.size() : 0);
        if (mConnected != null && mConnected.length() > 0) {
            count += 2;
        }
        return count;
    }


    public void setConnected(String szConnected, boolean bNoti) {
        this.mConnected = szConnected;
        if (bNoti) {
            notifyDataSetChanged();
        }
    }

    public boolean addSynesper(String name, String address, int rssi) {
        SynesperAdapter.SynesperItem deviceItem = new SynesperAdapter.SynesperItem(name, address, rssi);
        boolean bRet = mList.add(deviceItem);
        notifyDataSetChanged();
        return bRet;
    }

    //------------------------------------------------------------------------
    public static class SynesperItem {
        private String name;
        private String address;
        private int rssi;

        public SynesperItem(String name, String address, int rssi) {
            this.name = name;
            this.address = address;
            this.rssi = rssi;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public int getRssi() {
            return rssi;
        }

        public void setRssi(int rssi) {
            this.rssi = rssi;
        }
    }

    //----------------------------------------------------
    public class HeaderViewHolder extends RecyclerView.ViewHolder {

        protected TextView header;

        public HeaderViewHolder(@NonNull View itemView) {
            super(itemView);

            this.header = (TextView) itemView.findViewById(R.id.header);
        }
    }

    public class ConnectedViewHolder extends RecyclerView.ViewHolder {

        protected TextView name;

        public ConnectedViewHolder(@NonNull View itemView) {
            super(itemView);

            this.name = (TextView) itemView.findViewById(R.id.connected);
        }
    }

    public class SynesperViewHolder extends RecyclerView.ViewHolder {

        protected TextView name;
        protected TextView address;
        protected TextView rssi;

        public SynesperViewHolder(@NonNull View itemView) {
            super(itemView);

            this.name = (TextView) itemView.findViewById(R.id.name);
            this.address = (TextView) itemView.findViewById(R.id.address);
            this.rssi = (TextView) itemView.findViewById(R.id.rssi);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        if (mOnItemClickListener != null) {
                            int synePosition = pos;
                            if (mConnected != null && mConnected.length() > 0) {
                                synePosition -= 2;
                            }
                            mOnItemClickListener.onItemClick(v, mList.get(synePosition), synePosition);
                        }
                    }
                }
            });
        }
    }
}
