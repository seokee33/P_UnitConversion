package kr.claud.synesper.ui.measurement;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class MeasurementViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public MeasurementViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is measurement fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}