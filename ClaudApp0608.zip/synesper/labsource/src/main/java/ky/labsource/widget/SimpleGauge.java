package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
//import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.ContextCompat;

import ky.labsource.R;

/*
    <ky.labsource.widget.SimpleGauge
        android:id="@+id/simpleGauge3"
        android:layout_width="161dp"
        android:layout_height="161dp"
        app:simpleGaugeDividerColor="@color/md_yellow_500"
        app:simpleGaugeDividerDrawFirst="false"
        app:simpleGaugeDividerDrawLast="true"
        app:simpleGaugeDividerSize="0"
        app:simpleGaugeDividerStep="10"
        app:simpleGaugeEndValue="100"
        app:simpleGaugeFitRadiusMode="Width"
        app:simpleGaugePointEndColor="@color/md_red_500"
        app:simpleGaugePointStartColor="@color/md_green_500"
        app:simpleGaugeStartAngle="210"
        app:simpleGaugeStartValue="0"
        app:simpleGaugeStrokeCap="ROUND"
        app:simpleGaugeStrokeColor="@color/md_grey_400"
        app:simpleGaugeStrokeWidth="40dp"
        app:simpleGaugeSweepAngle="120" />


        SimpleGauge sg = (SimpleGauge) findViewById(R.id.simpleGauge3);
        sg.setValue(80);
*/


public class SimpleGauge extends View {

    private static final int DEFAULT_LONG_POINTER_SIZE = 1;

    private Paint mPaint;
    private float mStrokeWidth;
    private int mStrokeColor;
    private RectF mRect;
    private String mStrokeCap;
    private int mStartAngle;
    private int mSweepAngle;
    private int mStartValue;
    private int mEndValue;
    private int mValue;
    private double mPointAngle;
    private int mPoint;
    private int mPointSize;
    private int mPointStartColor;
    private int mPointEndColor;
    private int mDividerColor;
    private int mDividerSize;
    private int mDividerStepAngle;
    private int mDividersCount;
    private boolean mDividerDrawFirst;
    private boolean mDividerDrawLast;
    private int mFitRadiusMode;

    private static final int FIT_RADIUS_AUTO = 0;
    private static final int FIT_RADIUS_WIDTH = 1;
    private static final int FIT_RADIUS_HEIGHT = 2;


    public SimpleGauge(Context context) {
        super(context);
        init();
    }
    public SimpleGauge(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.SimpleGauge, 0, 0);

        // stroke style
        setStrokeWidth(a.getDimension(R.styleable.SimpleGauge_simpleGaugeStrokeWidth, 10));
        setStrokeColor(a.getColor(R.styleable.SimpleGauge_simpleGaugeStrokeColor, ContextCompat.getColor(context, android.R.color.darker_gray)));
        setStrokeCap(a.getString(R.styleable.SimpleGauge_simpleGaugeStrokeCap));

        // angle start and sweep (opposite direction 0, 270, 180, 90)
        setStartAngle(a.getInt(R.styleable.SimpleGauge_simpleGaugeStartAngle, 0));
        setSweepAngle(a.getInt(R.styleable.SimpleGauge_simpleGaugeSweepAngle, 360));

        // scale (from mStartValue to mEndValue)
        setStartValue(a.getInt(R.styleable.SimpleGauge_simpleGaugeStartValue, 0));
        setEndValue(a.getInt(R.styleable.SimpleGauge_simpleGaugeEndValue, 1000));

        // pointer size and color
        setPointSize(a.getInt(R.styleable.SimpleGauge_simpleGaugePointSize, 0));
        setPointStartColor(a.getColor(R.styleable.SimpleGauge_simpleGaugePointStartColor, ContextCompat.getColor(context, android.R.color.white)));
        setPointEndColor(a.getColor(R.styleable.SimpleGauge_simpleGaugePointEndColor, ContextCompat.getColor(context, android.R.color.white)));

        // divider options
        int dividerSize = a.getInt(R.styleable.SimpleGauge_simpleGaugeDividerSize, 0);
        setDividerColor(a.getColor(R.styleable.SimpleGauge_simpleGaugeDividerColor, ContextCompat.getColor(context, android.R.color.white)));
        int dividerStep = a.getInt(R.styleable.SimpleGauge_simpleGaugeDividerStep, 0);
        setDividerDrawFirst(a.getBoolean(R.styleable.SimpleGauge_simpleGaugeDividerDrawFirst, true));
        setDividerDrawLast(a.getBoolean(R.styleable.SimpleGauge_simpleGaugeDividerDrawLast, true));

        //
        mFitRadiusMode = a.getInt(R.styleable.SimpleGauge_simpleGaugeFitRadiusMode, 0);

        // calculating one point sweep
        mPointAngle = ((double) Math.abs(mSweepAngle) / (mEndValue - mStartValue));

        // calculating divider step
        if (dividerSize > 0) {
            mDividerSize = mSweepAngle / (Math.abs(mEndValue - mStartValue) / dividerSize);
            mDividersCount = 100 / dividerStep;
            mDividerStepAngle = mSweepAngle / mDividersCount;
        }
        a.recycle();
        init();
    }

    private void init() {
        //main Paint
        mPaint = new Paint();
        mPaint.setColor(mStrokeColor);
        mPaint.setStrokeWidth(mStrokeWidth);
        mPaint.setAntiAlias(true);
        if (!TextUtils.isEmpty(mStrokeCap)) {
            if (mStrokeCap.equals("BUTT"))
                mPaint.setStrokeCap(Paint.Cap.BUTT);
            else if (mStrokeCap.equals("ROUND"))
                mPaint.setStrokeCap(Paint.Cap.ROUND);
        } else
            mPaint.setStrokeCap(Paint.Cap.BUTT);
        mPaint.setStyle(Paint.Style.STROKE);
        mRect = new RectF();

        mValue = mStartValue;
        mPoint = mStartAngle;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float padding = getStrokeWidth();
        float size = getWidth()<getHeight() ? getWidth() : getHeight();
        float width = size - (2*padding);
        float height = size - (2*padding);

        float radius = (width < height) ? width/2 : height/2;

        float rectLeft = (getWidth() - (2*padding))/2 - radius + padding;
        float rectTop = (getHeight() - (2*padding))/2 - radius + padding;
        float rectRight = (getWidth() - (2*padding))/2 - radius + padding + width;
        float rectBottom = (getHeight() - (2*padding))/2 - radius + padding + height;

        if (mFitRadiusMode == FIT_RADIUS_WIDTH) {
            width = getWidth() - (2*padding);
            height = width;
            radius = width/2;

            rectLeft = (getWidth() - (2*padding))/2 - radius + padding;
            rectRight = rectLeft + width;

            rectTop = padding;
            rectBottom = rectTop + height;
        }
        else if (mFitRadiusMode == FIT_RADIUS_HEIGHT) {
            height = getHeight() - (2*padding);
            width = height;
            radius = height/2;

            rectTop = (getHeight() - (2*padding))/2 - radius + padding;
            rectBottom = rectTop + height;

            rectLeft = padding;
            rectRight = rectLeft + width;
        }


        mRect.set(rectLeft, rectTop, rectRight, rectBottom);

        mPaint.setColor(mStrokeColor);
        mPaint.setShader(null);
        canvas.drawArc(mRect, mStartAngle, mSweepAngle, false, mPaint);
        mPaint.setColor(mPointStartColor);
        mPaint.setShader(new LinearGradient(getWidth(), getHeight(), 0, 0, mPointEndColor, mPointStartColor, Shader.TileMode.CLAMP));
        if (mPointSize>0) {//if size of pointer is defined
            if (mPoint > mStartAngle + mPointSize/2) {
                canvas.drawArc(mRect, mPoint - mPointSize/2, mPointSize, false, mPaint);
            }
            else { //to avoid excedding start/zero point
                canvas.drawArc(mRect, mPoint, mPointSize, false, mPaint);
            }
        }
        else { //draw from start point to value point (long pointer)
            if (mValue==mStartValue) //use non-zero default value for start point (to avoid lack of pointer for start/zero value)
                canvas.drawArc(mRect, mStartAngle, DEFAULT_LONG_POINTER_SIZE, false, mPaint);
            else
                canvas.drawArc(mRect, mStartAngle, mPoint - mStartAngle, false, mPaint);
        }

        if (mDividerSize > 0) {
            mPaint.setColor(mDividerColor);
            mPaint.setShader(null);
            int i = mDividerDrawFirst ? 0 : 1;
            int max = mDividerDrawLast ? mDividersCount + 1 : mDividersCount;
            for (; i < max; i++) {
                canvas.drawArc(mRect, mStartAngle + i* mDividerStepAngle, mDividerSize, false, mPaint);
            }
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        //mCanvasWidth = (float) w;
        //mCanvasHeight = (float) h;
        //mCanvasCenterX = w / 2f;
        //mCanvasCenterY = h / 2f;

        super.onSizeChanged(w, h, oldw, oldh);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        /*
        int size;
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int widthWithoutPadding = width - getPaddingLeft() - getPaddingRight();
        int heightWithoutPadding = height - getPaddingTop() - getPaddingBottom();

        if (widthWithoutPadding > heightWithoutPadding) {
            size = heightWithoutPadding;
        } else {
            size = widthWithoutPadding;
        }

        setMeasuredDimension(size + getPaddingLeft() + getPaddingRight(), size + getPaddingTop() + getPaddingBottom());
        */
    }

    public void setValue(int value) {
        mValue = value;
        mPoint = (int) (mStartAngle + (mValue-mStartValue) * mPointAngle);
        invalidate();
    }

    public int getValue() {
        return mValue;
    }

    @SuppressWarnings("unused")
    public float getStrokeWidth() {
        return mStrokeWidth;
    }

    public void setStrokeWidth(float strokeWidth) {
        mStrokeWidth = strokeWidth;
    }

    @SuppressWarnings("unused")
    public int getStrokeColor() {
        return mStrokeColor;
    }

    public void setStrokeColor(int strokeColor) {
        mStrokeColor = strokeColor;
    }

    @SuppressWarnings("unused")
    public String getStrokeCap() {
        return mStrokeCap;
    }

    public void setStrokeCap(String strokeCap) {
        mStrokeCap = strokeCap;
    }

    @SuppressWarnings("unused")
    public int getStartAngle() {
        return mStartAngle;
    }

    public void setStartAngle(int startAngle) {
        mStartAngle = startAngle;
    }

    @SuppressWarnings("unused")
    public int getSweepAngle() {
        return mSweepAngle;
    }

    public void setSweepAngle(int sweepAngle) {
        mSweepAngle = sweepAngle;
    }

    @SuppressWarnings("unused")
    public int getStartValue() {
        return mStartValue;
    }

    public void setStartValue(int startValue) {
        mStartValue = startValue;
    }

    @SuppressWarnings("unused")
    public int getEndValue() {
        return mEndValue;
    }

    public void setEndValue(int endValue) {
        mEndValue = endValue;
        mPointAngle = ((double) Math.abs(mSweepAngle) / (mEndValue - mStartValue));
        invalidate();
    }

    @SuppressWarnings("unused")
    public int getPointSize() {
        return mPointSize;
    }

    public void setPointSize(int pointSize) {
        mPointSize = pointSize;
    }

    @SuppressWarnings("unused")
    public int getPointStartColor() {
        return mPointStartColor;
    }

    public void setPointStartColor(int pointStartColor) {
        mPointStartColor = pointStartColor;
    }

    @SuppressWarnings("unused")
    public int getPointEndColor() {
        return mPointEndColor;
    }

    public void setPointEndColor(int pointEndColor) {
        mPointEndColor = pointEndColor;
    }

    @SuppressWarnings("unused")
    public int getDividerColor() {
        return mDividerColor;
    }

    public void setDividerColor(int dividerColor) {
        mDividerColor = dividerColor;
    }

    @SuppressWarnings("unused")
    public boolean isDividerDrawFirst() {
        return mDividerDrawFirst;
    }

    public void setDividerDrawFirst(boolean dividerDrawFirst) {
        mDividerDrawFirst = dividerDrawFirst;
    }

    @SuppressWarnings("unused")
    public boolean isDividerDrawLast() {
        return mDividerDrawLast;
    }

    public void setDividerDrawLast(boolean dividerDrawLast) {
        mDividerDrawLast = dividerDrawLast;
    }


}
