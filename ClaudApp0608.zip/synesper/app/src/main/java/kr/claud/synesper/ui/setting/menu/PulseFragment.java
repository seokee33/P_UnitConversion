package kr.claud.synesper.ui.setting.menu;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.slider.RangeSlider;

import kr.claud.synesper.AppData;
import kr.claud.synesper.databinding.FragmentPulseBinding;

public class PulseFragment extends Fragment {
    public static final String TAG = "PulseFragment";

    private FragmentPulseBinding binding;
    private RangeSlider momPulseRangeSlider;
    private boolean bMomPulseRangeChanged = false;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        PulseViewModel pulseViewModel = new ViewModelProvider(this).get(PulseViewModel.class);

        binding = FragmentPulseBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        //-----------------------------------------------------------
        AppData ad = AppData.I();

        momPulseRangeSlider = binding.rangeSliderPulse;
        momPulseRangeSlider.addOnSliderTouchListener(new RangeSlider.OnSliderTouchListener() {
            @Override
            public void onStartTrackingTouch(@NonNull RangeSlider slider) {

            }

            @Override
            public void onStopTrackingTouch(@NonNull RangeSlider slider) {
                //updateMomPulse();
                bMomPulseRangeChanged = true;
                binding.buttonApply.setEnabled(true);
            }
        });

        momPulseRangeSlider.setValueFrom(0f);
        momPulseRangeSlider.setValueTo(250f);
        momPulseRangeSlider.setStepSize(1f);

        float alertMin = (float) ((ad.mPrefMomAlertMin < 0) ? 0 : ad.mPrefMomAlertMin);
        float alertMax = (float) ((ad.mPrefMomAlertMax > 250) ? 0 : ad.mPrefMomAlertMax);

        //Log.d(TAG, "RangeSlider: min=" + ad.mPrefMomAlertMin + ", max=" + ad.mPrefMomAlertMax);
        momPulseRangeSlider.setValues(alertMin, alertMax);

        //-----------------------------------------------------------
        binding.switchMomPulse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (binding.switchMomPulse.isChecked()) {
                    momPulseRangeSlider.setEnabled(true);
                    binding.buttonApply.setEnabled(bMomPulseRangeChanged);
                } else {
                    momPulseRangeSlider.setEnabled(false);
                    binding.buttonApply.setEnabled(false);
                }
            }
        });

        binding.buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateMomPulse();

                binding.textViewMomMin.setText("" + ad.mPrefMomAlertMin);
                binding.textViewMomMax.setText("" + ad.mPrefMomAlertMax);

                bMomPulseRangeChanged = false;
                binding.buttonApply.setEnabled(false);
            }
        });


        // init state
        momPulseRangeSlider.setEnabled(false);
        binding.buttonApply.setEnabled(false);

        binding.textViewMomMin.setText("" + ad.mPrefMomAlertMin);
        binding.textViewMomMax.setText("" + ad.mPrefMomAlertMax);

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void updateMomPulse() {
        AppData ad = AppData.I();

        int minNum = Float.toString(momPulseRangeSlider.getValues().get(0)).indexOf(".");
        int maxNum = Float.toString(momPulseRangeSlider.getValues().get(1)).indexOf(".");
        String minVal = Float.toString(momPulseRangeSlider.getValues().get(0)).substring(0, minNum);
        String maxVal = Float.toString(momPulseRangeSlider.getValues().get(1)).substring(0, maxNum);

        ad.mPrefMomAlertMin = Integer.parseInt(minVal);
        ad.mPrefMomAlertMax = Integer.parseInt(maxVal);
    }
}