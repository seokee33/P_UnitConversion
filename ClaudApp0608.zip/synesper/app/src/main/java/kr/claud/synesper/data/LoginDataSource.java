package kr.claud.synesper.data;

import kr.claud.synesper.AppData;
import kr.claud.synesper.data.model.LoggedInUser;

import java.io.IOException;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    // 4, Try to sign in from AppData
    public Result<LoggedInUser> login(String username, String password) {
        try {
            AppData ad = AppData.I();
            int nLogin = ad.login(username, password);
            if (nLogin == AppData.LOGIN_OK) {
                LoggedInUser loggedInUser = new LoggedInUser(ad.mUserData.userId(), ad.mUserData.userName());
                return new Result.Success<>(loggedInUser);
            } else {
                throw new Exception();
            }
        } catch (Exception e) {
            return new Result.Error(new IOException("Error logging in", e));
        }
    }

    public void logout() {
        // TODO: revoke authentication
    }
}