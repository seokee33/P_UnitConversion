package kr.claud.synesper;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.util.Log;


import java.util.ArrayList;
import java.util.Date;

import kr.claud.synesper.data.DBHelper;
import kr.claud.synesper.data.UserData;
import kr.claud.synesper.ui.measurement.MeasurementCache;
import kr.claud.synesper.ui.measurement.MeasurementFragment;
import kr.claud.synesper.ui.notice.NoticeCache;
import kr.claud.synesper.ui.notice.NoticeConstant;

public class AppData {
    private static  final String TAG = AppData.class.getSimpleName();


    //////////////////
    public static boolean BLE_RECEIVE_STATE_Profile = false;
    public boolean changeBLE_RECEIVE_STATE_Profile(MeasurementFragment measFrag){
        if(BLE_RECEIVE_STATE_Profile){
            BLE_RECEIVE_STATE_Profile = false;
            if (measFrag != null) {
                measFrag.changeGraphState(true);
            }
        }else{
            BLE_RECEIVE_STATE_Profile = true;
        }
        return BLE_RECEIVE_STATE_Profile;
    }

    //////////////////
    public static final int LOGIN_OK = 1;
    public static final int LOGIN_FAIL = 0;
    public static final int LOGIN_UNREG = -1;

    //-----------------------------------------------------------
    public BuildTarget gBuildTarget = new BuildTarget();

    public DBHelper mSqliteDB = null;
    public UserData mUserData = null;

    public MeasurementCache mMeasCache = null;
    public NoticeCache mNoticeCache = null;
    //---------------------------------------------------------
    private static final String buildNumberKey   = "keyBuildNumber";
    private static final String runFirstKey      = "keyRunFirst";
    private static final String userNameKey      = "keyUserName";
    private static final String passwdKey        = "keyPasswd";
    private static final String autoLoginKey     = "keyAutoLogin";
    private static final String rememberIdKey    = "keyRememberId";
    private static final String deviceNameKey    = "keyDeviceName";
    private static final String deviceAddrKey    = "keyDeviceAddr";
    private static final String volumeOnKey      = "keyVolumeOn";
    private static final String babyAlertMaxKey  = "keyBabyAlertMax";
    private static final String babyAlertMinKey  = "keyBabyAlertMin";

    private static final String momAlertMaxKey   = "keyMomAlertMax";
    private static final String momAlertMinKey   = "keyMomAlertMin";

    private static final String checkLTEKey = "checkLTEKey";

    public int mBuildNumber = 0;

    public boolean mAppRunFirst = false;
    public String mPrefUserName = null;
    public String mPrefPasswd = null;

    public boolean mAutoLogin = true;
    public boolean mRememberId = false;

    public String mPrefDeviceName = null;
    public String mPrefDeviceAddr = null;

    public boolean mPrefVolumeOn = false;

    public int mPrefBabyAlertMax = Integer.MAX_VALUE;
    public int mPrefBabyAlertMin = 0;

    public int mPrefMomAlertMax = 150;
    public int mPrefMomAlertMin = 50;

    public boolean mPrefCheckLTE = false;
    public boolean mPrefServerOK = true;

    //-----------------------------------------------------------
    static {
        _appData = null;

        emailEncoded = null;
        pwEncoded = null;

        aesKeyStr = "~c!l@a#u$d%";
        scrambles = new byte[] { 5, 1, 4, 15 };
    }

    private static AppData _appData;

    public static String emailEncoded;
    public static String pwEncoded;
    public static String aesKeyStr;
    public static byte[] scrambles;
    //-----------------------------------------------------------

    public static AppData New(Context ctx) {
        if (_appData == null) {
            _appData = new AppData(ctx);
        }
        return _appData;
    }

    public static AppData I() { return _appData; }

    public AppData(Context ctx) {
        mSqliteDB = new DBHelper(ctx, BuildConfig.SQLITEDB_VERSION);
        mSqliteDB.init();

        mUserData = new UserData(ctx);
        mMeasCache = new MeasurementCache(mSqliteDB);
        mNoticeCache = new NoticeCache(mSqliteDB);
        //mSqliteDB.loadDBFile();
    }

    public void closeAppData() {
        //mSqliteDB.storeDBFile();
    }

    public void clearDB(){
        mSqliteDB.resetTable();
    }

    // Looks up a member in SQLite using their username, and if they exist, tries to log them in against the entered information, the last step in the app's internal login.
    public int login(String id, String passwd) {
        ArrayList<DBHelper.UserItem> usrArr = mSqliteDB.selectUser(id);
        if (usrArr.size() > 0) {
            DBHelper.UserItem usr = usrArr.get(0);

/*
            Log.d(TAG, "num=" + usr.num);
            Log.d(TAG, "id=" + usr.id);
            Log.d(TAG, "passwd=" + usr.passwd);
            Log.d(TAG, "name=" + usr.name);
            Log.d(TAG, "delivery=" + usr.delivery);
            Log.d(TAG, "email=" + usr.email);
*/
            if (passwd.length() == 0) {
                return LOGIN_UNREG;
            } else if (passwd.compareTo(usr.passwd) == 0) {
                mUserData.setUser(usr);
                mUserData.setProfileImage();
                return LOGIN_OK;
            }
        }
        return LOGIN_FAIL;
    }

    // If the membership information is updated, update the membership information in the SQLite DB. If the membership information does not exist, perform an insertion.
    public boolean updateUser(DBHelper.UserItem user) {
        Log.d(TAG, "num=" + user.num);
        Log.d(TAG, "id=" + user.id);
        Log.d(TAG, "passwd=" + user.passwd);
        Log.d(TAG, "name=" + user.name);
        Log.d(TAG, "delivery=" + user.delivery);
        Log.d(TAG, "email=" + user.email);

        ArrayList<DBHelper.UserItem> usrArr = mSqliteDB.selectUser(user.id);
        if (usrArr.size() > 0) {
            mSqliteDB.updateUser(user.num, user.id, user.passwd, user.name, user.delivery, user.email);
        } else {
            mSqliteDB.insertUser(user.id, user.passwd, user.name, user.delivery, user.email);
        }
        return false;
    }
    public MeasurementCache.MeasurementDay getMeasurement(Date date) {
        Log.d(TAG, "Measurement[" + date.toString() + "]");
        return mMeasCache.get(mUserData.userNum(), date);
    }

    public boolean updateMeasurement(Date date, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, boolean uploadState) {
        return updateMeasurement(mUserData.userNum(), date, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
    }

    public MeasurementCache.MeasurementDay getMeasurement(int userNum, Date date) {
        return mMeasCache.get(userNum, date);
    }

    public boolean updateMeasurement(int userNum, Date date, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, boolean uploadState) {
        return mMeasCache.update(userNum, date, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
    }

    public void removeMeasurement(int userNum, Date date) {
        if (date == null)
            return;
        mMeasCache.remove(userNum, date);
    }

    //---------------------------------------------------------------
    public NoticeCache.NoticeDay getNotice(Date date) {
        return mNoticeCache.get(mUserData.userNum(), date);
    }

    public boolean updateNotice(int userNum, Date date, int type, int bpm, int avgMin, int avgMax) {
        return mNoticeCache.update(userNum, date, type, bpm, avgMin, avgMax);
    }

    public boolean updateNoticeBaby(int userNum, Date date, int bpmMin, int bpmMax) {
        boolean bUpdate = false;
        if (bpmMin < mPrefBabyAlertMin) {
            int type = NoticeConstant.BBPM_LOW.getCode();
            if (updateNotice(userNum, date, type, bpmMin, mPrefBabyAlertMin, mPrefBabyAlertMax))
                bUpdate = true;
        }
        if (bpmMax > mPrefBabyAlertMax) {
            int type = NoticeConstant.BBPM_HIGH.getCode();
            if (updateNotice(userNum, date, type, bpmMax, mPrefBabyAlertMin, mPrefBabyAlertMax))
                bUpdate = true;
        }
        return bUpdate;
    }

    public boolean updateNoticeMom(int userNum, Date date, int bpmMin, int bpmMax) {
        boolean bUpdate = false;
        int type = -1;
        int bpm = 0;
        if (bpmMin < mPrefMomAlertMin && bpmMax > mPrefMomAlertMax) {
            type = NoticeConstant.MBPM_LOWHIGH.getCode();
            bpm = bpmMin;
        } else if (bpmMin < mPrefMomAlertMin) {
            type = NoticeConstant.MBPM_LOW.getCode();
            bpm = bpmMin;
        } else if (bpmMax > mPrefMomAlertMax) {
            type = NoticeConstant.MBPM_HIGH.getCode();
            bpm = bpmMax;
        }

        if (type != -1) {
            if (updateNotice(userNum, date, type, bpm, mPrefMomAlertMin, mPrefMomAlertMax))
                bUpdate = true;
        }
        return bUpdate;
    }

    public boolean updateNoticeDevice(int userNum, Date date, int type) {
        return updateNotice(userNum, date, type, 0, 0, 0);
    }

    public void removeNotice(int userNum, Date date) {
        if (date == null)
            return;
        mNoticeCache.remove(userNum, date);
    }
    //--------------------------------------------------------------
    // Preferences
    public static SharedPreferences getPrefs(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void loadPreferences(Context context) {
        AppData ad = AppData.I();
        if (ad != null) {
            ad.loadPreferences(getPrefs(context));
        }
    }

    public static void storePreferences(Context context) {
        AppData ad = AppData.I();
        if (ad != null) {
            ad.storePreferences(getPrefs(context));
        }
    }

    public static void clearPreferences(Context context) {
        AppData ad = AppData.I();
        if (ad != null) {
            ad.clearPreferences(getPrefs(context));
        }
    }

    public void setDevice(String devName, String devAddr) {
        mPrefDeviceName = devName == null ? "" : devName;
        mPrefDeviceAddr = devAddr == null ? "" : devAddr;
    }

    //--------------------------------------------------------------------------
    public void setLETCheck(boolean check){
        mPrefCheckLTE = check;
    }
    // 1 : wifi
    // 2 : data
    // 3 : 연결 불가
    // 4 : error
    public int getNetworkInfo(Activity acty){
        ConnectivityManager connectivityManager = (ConnectivityManager) acty.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager != null) {
            // 현재 활성화된 네트워크 정보를 가져옴
            NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();

            if (activeNetwork != null) {
                // 인터넷 연결 가능 여부 확인
                boolean isConnected = activeNetwork.isConnected();

                // 연결 유형 확인
                int networkType = activeNetwork.getType();

                if (isConnected) {
                    if (networkType == ConnectivityManager.TYPE_WIFI) {
                        // WiFi를 사용 중
                        return 1;
                    } else if (networkType == ConnectivityManager.TYPE_MOBILE) {
                        // 데이터를 사용 중
                        return 2;
                    }
                } else {
                    // 인터넷 연결 불가
                    return 3;
                }
            }
        }

        return 4;

    }

    public void setVolume(boolean bOn) {
        mPrefVolumeOn = bOn;
    }

    public void loadPreferences(SharedPreferences prefs)
    {
        mBuildNumber = prefs.getInt(buildNumberKey, 0);
        if (mBuildNumber != BuildConfig.BUILD_NUMBER) {
            clearPreferences(prefs);

            mBuildNumber = BuildConfig.BUILD_NUMBER;
        }

        mAppRunFirst = prefs.getBoolean(runFirstKey, true);
        mPrefUserName = prefs.getString(userNameKey, "");
        mPrefPasswd = prefs.getString(passwdKey, "");
        mAutoLogin = prefs.getBoolean(autoLoginKey, true);
        mRememberId = prefs.getBoolean(rememberIdKey, false);

        mPrefDeviceName = prefs.getString(deviceNameKey, "");
        mPrefDeviceAddr = prefs.getString(deviceAddrKey, "");

        mPrefVolumeOn = prefs.getBoolean(volumeOnKey, false);

        mPrefBabyAlertMax = prefs.getInt(babyAlertMaxKey, Integer.MAX_VALUE);
        mPrefBabyAlertMin = prefs.getInt(babyAlertMinKey, 0);

        mPrefMomAlertMax = prefs.getInt(momAlertMaxKey, 150);
        mPrefMomAlertMin = prefs.getInt(momAlertMinKey, 50);

        mPrefCheckLTE = prefs.getBoolean(checkLTEKey,false);

        //mFileDB.setAvailableStartYear(prefs.getInt("keyStartYear", 0));

        Log.d(TAG, "------------------------------------");
        Log.d(TAG, "App build number=" + mBuildNumber);
        Log.d(TAG, "App run first=" + mAppRunFirst);
        Log.d(TAG, "User Name=" + mPrefUserName);
        Log.d(TAG, "Auto Login=" + mAutoLogin);
        Log.d(TAG, "Remember ID=" + mRememberId);
        Log.d(TAG, "Device=" + mPrefDeviceName + "[" + mPrefDeviceAddr + "]");
        Log.d(TAG, "Volume On=" + mPrefVolumeOn);
        Log.d(TAG, "MomPulse Range: min=" + mPrefMomAlertMin + ", max=" + mPrefMomAlertMax);
        //Log.d(TAG, "Start Year=" + mFileDB.getAvailableStartYear());
        Log.d(TAG, "------------------------------------");

    }

    public void storePreferences(SharedPreferences prefs)
    {
        //Resources res = context.getResources();

        //String keyPrefEnable = res.getString(R.string.key_pref_enable);
        //String keyUser = res.getString(R.string.key_user);
        //String keyPlace = res.getString(R.string.key_place);
        //String keyAuthMsg = res.getString(R.string.key_auth_msg);

        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(buildNumberKey, BuildConfig.BUILD_NUMBER);
        editor.putBoolean(runFirstKey, false);
        editor.putString(userNameKey, (mPrefUserName == null) ? "" : mPrefUserName);
        editor.putString(passwdKey, (mPrefPasswd == null) ? "" : mPrefPasswd);
        editor.putBoolean(autoLoginKey, mAutoLogin);
        editor.putBoolean(rememberIdKey, mRememberId);

        editor.putString(deviceNameKey, (mPrefDeviceName == null) ? "" : mPrefDeviceName);
        editor.putString(deviceAddrKey, (mPrefDeviceAddr == null) ? "" : mPrefDeviceAddr);

        editor.putBoolean(volumeOnKey, mPrefVolumeOn);

        editor.putInt(babyAlertMaxKey, mPrefBabyAlertMax);
        editor.putInt(babyAlertMinKey, mPrefBabyAlertMin);

        editor.putInt(momAlertMaxKey, mPrefMomAlertMax);
        editor.putInt(momAlertMinKey, mPrefMomAlertMin);

        editor.apply();
    }

    public void clearPreferences(SharedPreferences prefs) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.commit();
    }

    //---------------------------------------------------------------------
    public class BuildTarget {

        public BuildTarget() {
            if (BuildConfig.BUILD_TARGET == 1) {

            }
        }
    }
}