package kr.claud.synesper;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import kr.claud.libs.framework.fragment.FragmentUtil;
import kr.claud.synesper.dialog.ProfilePhotoDialog;
import kr.claud.synesper.media.ProfileImage;
import kr.claud.synesper.ui.register.RegisterCompletedFragment;
import kr.claud.synesper.ui.register.RegisterDeviceFragment;
import kr.claud.synesper.ui.register.RegisterFragment;
import kr.claud.synesper.ui.register.RegisterInfoFragment;
import kr.claud.synesper.ui.register.RegisterPersonalInfoConsentFragment;
import kr.claud.synesper.ui.register.RegisterViewModel;
import kr.claud.synesper.ui.setting.menu.ProfileFragment;

public class RegisterActivity extends AppCompatActivity {

    public static final String TAG = "RegisterActivity";

    private RegisterViewModel viewModel;
    //private RegisterFragment mRegisterFragment = null;

    private TextView mTextViewPage;
    private TextView mTextViewTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mTextViewPage = (TextView) findViewById(R.id.textViewPage);
        mTextViewTitle = (TextView) findViewById(R.id.textViewPageTitle);

        viewModel = new ViewModelProvider(this).get(RegisterViewModel.class).init(this);

        // The first fragment screen is the personal information consent screen
        if (savedInstanceState == null) {
            navigateFragment(RegisterPersonalInfoConsentFragment.class);

/*
            mRegisterFragment = RegisterInfoFragment.newInstance();
            mRegisterFragment.setOnFragmentListener(mOnFragmentListener);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, mRegisterFragment)
                    .commitNow();

 */
        }
    }

    //--------------------------------------------------------
    public void navigateFragment(Class cls) {
        try {
            RegisterFragment registerFragment = (RegisterFragment) cls.newInstance();
            registerFragment.setOnFragmentListener(mOnFragmentListener);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, registerFragment)
                    .commitNow();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        }
/*
        RegisterFragment registerFragment = RegisterInfoFragment.newInstance();
        registerFragment.setOnFragmentListener(mOnFragmentListener);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.container, registerFragment)
                .commitNow();
 */
    }

    // Listener to process fragments by class
    //  - Register Personal InfoConsent Fragment: Personal Information Consent
    //  - Register Info Fragment : Enter member information
    //  - RegisterDeviceFragment : Register device
    //  - RegisterCompletedFragment: Membership registration completed
    RegisterFragment.OnFragmentListener mOnFragmentListener = new RegisterFragment.OnFragmentListener() {
        @Override
        public void onViewCreated(RegisterFragment fragment, View v) {
            fragment.setViewModel(viewModel);
            if(fragment.getClass() == RegisterPersonalInfoConsentFragment.class){
                mTextViewPage.setText(R.string.signup_tab_page1);
                mTextViewTitle.setText(R.string.signup_pic_titile);
            } else if (fragment.getClass() == RegisterInfoFragment.class) {
                mTextViewPage.setText(R.string.signup_tab_page2);
                mTextViewTitle.setText(R.string.signup_infomation);
            } else if (fragment.getClass() == RegisterDeviceFragment.class) {
                mTextViewPage.setText(R.string.signup_tab_page3);
                mTextViewTitle.setText(R.string.signup_connect_device);
            } else if (fragment.getClass() == RegisterCompletedFragment.class) {
                mTextViewPage.setText(R.string.signup_tab_page4);
                mTextViewTitle.setText(R.string.signup_completed);
            }
        }

        @Override
        public void onFragmentNext(RegisterFragment fragment) {
            if(fragment instanceof RegisterPersonalInfoConsentFragment){
                navigateFragment(RegisterInfoFragment.class);
            } else if (fragment instanceof RegisterInfoFragment) {
                navigateFragment(RegisterDeviceFragment.class);
            } else if (fragment instanceof RegisterDeviceFragment) {
                navigateFragment(RegisterCompletedFragment.class);
            } else if (fragment instanceof RegisterCompletedFragment) {
                setResult(UserActivity.RESULT_REGISTER_OK);

                AppData ad = AppData.I();
                ad.updateUser(viewModel.mUserRegister.mUser);
                ad.setDevice(viewModel.mUserRegister.mDevName, viewModel.mUserRegister.mDevAddr);

                //Complete and destroy login activity once successful
                finish();
            }
        }
    };


    // Member profile image processing (camera)
    ActivityResultLauncher<Intent> cameraActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                    if (data != null && result.getResultCode() == RESULT_OK) {
                        Bitmap bitmap = ProfileImage.bitmapFromCamera(data);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateProfileFragmentPhoto(bitmap);
                            }
                        });
                    } else if (result.getResultCode() == RESULT_CANCELED) {

                    }
                }
            });

    //Member profile image processing (gallery)
    ActivityResultLauncher<Intent> galleryActivityResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    Intent data = result.getData();
                    if (data != null && result.getResultCode() == RESULT_OK) {
                        Bitmap bitmap = ProfileImage.bitmapFromGallery(data, RegisterActivity.this);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                updateProfileFragmentPhoto(bitmap);
                            }
                        });
                    } else if (result.getResultCode() == RESULT_CANCELED) {
                        Toast.makeText(RegisterActivity.this, "사진 선택 취소", Toast.LENGTH_LONG).show();
                    }
                }
            });

    public void clickProfilePhotoByInfoFragment(String result) {
        switch(result) {
            case ProfilePhotoDialog.RESULT_CAMERA:
                Intent imageTakeIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (imageTakeIntent.resolveActivity(getPackageManager()) != null) {
                    cameraActivityResultLauncher.launch(imageTakeIntent);
                    //startActivityForResult(imageTakeIntent, REQCODE_OPEN_CAMERA);
                }
                break;

            case ProfilePhotoDialog.RESULT_GALLERY:
                Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                galleryActivityResultLauncher.launch(i);
                //startActivityForResult(i, REQCODE_OPEN_GALLERY);
                break;
        }
    }

    public void updateProfileFragmentPhoto(Bitmap bitmap) {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        if (fragment instanceof RegisterInfoFragment) {
            RegisterInfoFragment rifrag = (RegisterInfoFragment) fragment;
            rifrag.updateProfilePhoto(bitmap);
        }
    }
}