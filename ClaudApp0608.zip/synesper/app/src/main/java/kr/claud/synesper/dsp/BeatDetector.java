package kr.claud.synesper.dsp;


public class BeatDetector {

    public static final long BEATDETECTOR_INIT_HOLDOFF = 2000;             // in ms, how long to wait before counting
    public static final long BEATDETECTOR_MASKING_HOLDOFF = 200;           // in ms, non-retriggerable window after beat detection
    public static final float BEATDETECTOR_BPFILTER_ALPHA = 0.6f;           // EMA factor for the beat period value
    public static final float BEATDETECTOR_MIN_THRESHOLD = 20;              // minimum threshold (filtered) value
    public static final float BEATDETECTOR_MAX_THRESHOLD = 800;             // maximum threshold (filtered) value
    public static final float BEATDETECTOR_STEP_RESILIENCY = 30;            // maximum negative jump that triggers the beat edge
    public static final float BEATDETECTOR_THRESHOLD_FALLOFF_TARGET = 0.3f; // thr chasing factor of the max value when beat
    public static final float BEATDETECTOR_THRESHOLD_DECAY_FACTOR = 0.99f;  // thr chasing factor when no beat
    public static final long BEATDETECTOR_INVALID_READOUT_DELAY = 2000;    // in ms, no-beat time to cause a reset
    public static final long BEATDETECTOR_SAMPLES_PERIOD = 10;             // in ms, 1/Fs


    public enum State {
        INIT,
        WAITING,
        FOLLOWING_SLOPE,
        MAYBE_DETECTED,
        MASKING;
    }

    private State _state;
    private float _threshold;
    private float _samplerate;
    private float _beatPeriod;
    private float _lastMaxValue;
    private long _tsLastBeat;

    private long _millisLast;
    private long _millisStart;
    private float _step;

    public interface OnBeatDetectorListener {
        void onDetect();
    }

    // Constructor
    public BeatDetector() {
        init();
    }

    public void init() {
        _state = State.INIT;
        _threshold = BEATDETECTOR_MIN_THRESHOLD;
        _samplerate = 100;
        _beatPeriod = 0;
        _lastMaxValue = 0;
        _tsLastBeat = 0;

        _millisLast = 0;
        _millisStart = 0;
        _step = 1000/_samplerate;  // millisec
    }

    public long millis() {
        return System.currentTimeMillis();
    }

    public float getRate()
    {
        if (_beatPeriod != 0) {
            return 1 / _beatPeriod * 1000 * 60;
        } else {
            return 0;
        }
    }

    public float getCurrentThreshold()
    {
        return _threshold;
    }

    public boolean checkForBeat(short[] samples, OnBeatDetectorListener l) {
        long curMillis = millis();
        if (curMillis - _millisLast > 5000) {
            init();
        }
        _millisLast = curMillis;

        boolean bBeat = false;
        float msec = _millisStart;
        for (short s : samples) {
            msec += _step;
            if (checkForBeat((float) s, (long) msec)) {
                if (!bBeat && l != null) {
                    l.onDetect();
                }
                bBeat = true;
            }
        }
        _millisStart = (long) msec;
        return bBeat;
    }
/*
    public boolean checkForBeat2(short[] samples) {
        long curMillis = millis();
        boolean bBeat = false;
        long step = (curMillis - _millisLast) / samples.length;
        long msec = _millisLast;
        if (step > BEATDETECTOR_SAMPLES_PERIOD*10) {
            step = BEATDETECTOR_SAMPLES_PERIOD;
            msec = curMillis - step*samples.length;
        }
        for (short s : samples) {
            msec += step;
            if (checkForBeat((float) s, msec)) {
                bBeat = true;
            }
        }
        _millisLast = curMillis;
        return bBeat;
    }
*/
    public boolean checkForBeat(float sample, long msec)
    {
        boolean beatDetected = false;

        switch (_state) {
            case INIT:
                if (msec > BEATDETECTOR_INIT_HOLDOFF) {
                    _state = State.WAITING;
                }
                break;

            case WAITING:
                if (sample > _threshold) {
                    _threshold = Math.min(sample, BEATDETECTOR_MAX_THRESHOLD);
                    _state = State.FOLLOWING_SLOPE;
                }

                // Tracking lost, resetting
                if (msec - _tsLastBeat > BEATDETECTOR_INVALID_READOUT_DELAY) {
                    _beatPeriod = 0;
                    _lastMaxValue = 0;
                }

                decreaseThreshold();
                break;

            case FOLLOWING_SLOPE:
                if (sample < _threshold) {
                    _state = State.MAYBE_DETECTED;
                } else {
                    _threshold = Math.min(sample, BEATDETECTOR_MAX_THRESHOLD);
                }
                break;

            case MAYBE_DETECTED:
                if (sample + BEATDETECTOR_STEP_RESILIENCY < _threshold) {
                    // Found a beat
                    beatDetected = true;
                    _lastMaxValue = sample;
                    _state = State.MASKING;
                    float delta = msec - _tsLastBeat;
                    if (delta > 0.f) {
                        _beatPeriod = BEATDETECTOR_BPFILTER_ALPHA * delta + (1 - BEATDETECTOR_BPFILTER_ALPHA) * _beatPeriod;
                    }

                    _tsLastBeat = msec;
                } else {
                    _state = State.FOLLOWING_SLOPE;
                }
                break;

            case MASKING:
                if (msec - _tsLastBeat > BEATDETECTOR_MASKING_HOLDOFF) {
                    _state = State.WAITING;
                }
                decreaseThreshold();
                break;

            default:
                throw new IllegalStateException("Unexpected value: " + _state);
        }

        return beatDetected;
    }

    public void decreaseThreshold()
    {
        // When a valid beat rate readout is present, target the
        if (_lastMaxValue > 0 && _beatPeriod > 0) {
            _threshold -= _lastMaxValue * (1 - BEATDETECTOR_THRESHOLD_FALLOFF_TARGET) / (_beatPeriod / BEATDETECTOR_SAMPLES_PERIOD);
        } else {
            // Asymptotic decay
            _threshold *= BEATDETECTOR_THRESHOLD_DECAY_FACTOR;
        }

        if (_threshold < BEATDETECTOR_MIN_THRESHOLD) {
            _threshold = BEATDETECTOR_MIN_THRESHOLD;
        }
    }
}