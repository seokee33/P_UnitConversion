package ky.labsource.bluetooth.ble;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UUIDGroup {


    // UUID for UART
    //public static final String UUID_SERVICE_UART     = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
    //public static final String UUID_CHAR_RX          = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
    //public static final String UUID_CHAR_TX          = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";

    public static final UUID UUID_TX_POWER             = UUID.fromString("00001804-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_TX_POWER_LEVEL       = UUID.fromString("00002a07-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_CCCD                 = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_FIRMWARE_REVISON     = UUID.fromString("00002a26-0000-1000-8000-00805f9b34fb");
    public static final UUID DIS_UUID                  = UUID.fromString("0000180a-0000-1000-8000-00805f9b34fb");
    public static final UUID UUID_SERVICE_UART         = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    public static final UUID UUID_CHAR_RX              = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");
    public static final UUID UUID_CHAR_TX              = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");

    // UUID for voble(voice over ble)
    public static final UUID UUID_SERVICE_VOBLE        = UUID.fromString("b7ef1193-dc2e-4362-93d3-df429eb3ad10");
    /*  UUIDs of the characteristics*/
    public static final UUID UUID_CHAR_AUDIO_DATA      = UUID.fromString("00ce7a72-ec08-473d-943e-81ec27fdc5f2");
    public static final UUID UUID_CHAR_SAMPLE_RATE     = UUID.fromString("00ce7a72-ec08-473d-943e-81ec27fdc601");
    public static final UUID UUID_CHAR_FILTER_ENABLE   = UUID.fromString("00ce7a72-ec08-473d-943e-81ec27fdc602");
    public static final UUID UUID_CHAR_ENCODING_ENABLE = UUID.fromString("00ce7a72-ec08-473d-943e-81ec27fdc603");
    public static final UUID UUID_CHAR_TRANSFER_STATUS = UUID.fromString("00ce7a72-ec08-473d-943e-81ec27fdc604");


    private UUID _uuidService;
    private List<UUID> _uuidChars;

    /**
     * Creates a {@code UUIDService} from the string
     *
     * @param  name
     *         A string that specifies a {@code UUIDService}
     *
     * @return  A {@code UUIDService} with the specified value
     *
     */
    @NotNull
    public static UUIDGroup SERVICE(String name) {
        return new UUIDGroup(name);
    }


    public UUIDGroup(String name) {
        _uuidService = UUID.fromString(name);
        _uuidChars = new ArrayList<>();
    }

    public void addCharUUIDs(@NotNull String... uuids) {
        for (String usz : uuids) {
            _uuidChars.add(UUID.fromString(usz));
        }
    }

    public void addCharUUIDs(UUID... uuids) {
        for (UUID u : uuids) {
            _uuidChars.add(u);
        }
    }

    public void addCharUUID(String uuidStr) {
        _uuidChars.add(UUID.fromString(uuidStr));
    }

    public void addCharUUID(UUID uuid) {
        _uuidChars.add(uuid);
    }
}
