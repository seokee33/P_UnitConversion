package kr.claud.synesper.ui.register;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import kr.claud.synesper.R;
import kr.claud.synesper.databinding.FragmentRegisterDeviceBinding;
import kr.claud.synesper.device.SynesperAdapter;
import ky.labsource.LsBluetooth;

public class RegisterDeviceFragment extends RegisterFragment {
    public static final String TAG = "RegisterDeviceFragment";

    public static RegisterDeviceFragment newInstance() {
        return new RegisterDeviceFragment();
    }

    private FragmentRegisterDeviceBinding binding;
    private RecyclerView mSynesperView;
    private String selDevName = null;
    private String selDevAddr = null;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mFragmentPage = 2;
        binding = FragmentRegisterDeviceBinding.inflate(inflater, container, false);  //R.layout.fragment_register_device

        View root = binding.getRoot();
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final Button nextButton = binding.buttonNext;
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mViewModel.mUserRegister.setDevice(selDevName, selDevAddr);//디바이스 설정
                //mViewModel.next(new RegisterResult(new RegisteredInUserView("Next")));
                frgmentListener_onFragmentNext();
            }
        });

        initSynesperView(view);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    //-----------------------------------------------
    private ImageView mImageViewScan;
    private TextView mTextViewConnectedDeviceName;
    private ImageView mImageViewConnectedClear;
    private boolean mScanButtonClicked = false;
    private boolean mScanning = false;
    private Handler mHandler;

    private void initSynesperView(View root) {
        mSynesperView = binding.recyclerViewDevice;
        mViewModel.initSynesperAdapter(mSynesperView, mOnItemClickListener, getContext());

        mScanButtonClicked = false;
        mScanning = false;
        mHandler = new Handler();

        mImageViewScan = binding.imageViewDevice;
        mTextViewConnectedDeviceName = binding.textViewConnectedDeviceName;
        mImageViewConnectedClear = binding.imageViewConnectedClear;

        mImageViewScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Scan Click!!!");

                if (mScanButtonClicked)
                    return;

                mScanButtonClicked = true;

                mImageViewScan.setEnabled(false);

                if (!mScanning) {
                    scanStartLeDevice();
                } else {
                    scanStopLeDevice();
                }
            }
        });

        mImageViewConnectedClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeDeviceName(null, null);
            }
        });
    }

    private void updateDeviceName(String devName) {
        if (devName == null || devName.length() == 0) {
            mTextViewConnectedDeviceName.setText(R.string.signup_no_device_connected_);
            //setStateStartButton(false);
        } else {
            mTextViewConnectedDeviceName.setText(devName);
            //setStateStartButton(true);
        }
    }

    private void changeDeviceName(String devName, String devAddr) {
        selDevName = devName;
        selDevAddr = devAddr;

        updateDeviceName(devName);
    }


    private void scanStartLeDevice() {
        LsBluetooth lsBt = LsBluetooth.IGet();

        Runnable scanRunnable = new Runnable() {
            @Override
            public void run() {
                lsBt.ScanStop();
                //mBtnCancel.setText(R.string.scan);

                //mHandler.removeCallbacks(mDisappearRunnable);
                //mHandler.post(mDisappearRunnable);
            }
        };

        mViewModel.clearArrayList();

        // Stops scanning after a pre-defined scan period.
        //mHandler.postDelayed(scanRunnable, SCAN_PERIOD);
        lsBt.ScanStartWithInterval(mOnLeScanListener, 5000);

        //mBtnCancel.setText(R.string.cancel);
    }

    private void scanStopLeDevice() {
        LsBluetooth lsBt = LsBluetooth.IGet();
        lsBt.ScanStop();
    }


    private SynesperAdapter.OnItemClickListener mOnItemClickListener = new SynesperAdapter.OnItemClickListener() {
        @Override
        public void onItemClick(View v, SynesperAdapter.SynesperItem item, int pos) {
            Log.d(TAG, "onItemClick: bt addr=[" + item.getAddress() + "] selected!!!");

            changeDeviceName(item.getName(), item.getAddress());

            if (mScanning) {
                scanStopLeDevice();
            }

            /*
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    LsBluetooth lsBt = LsBluetooth.IGet();
                    if (lsBt != null) {
                        lsBt.disconnect();
                        lsBt.connect(getContext(), item.getAddress());
                    }
                }
            }, 100);
             */
        }
    };


    LsBluetooth.OnLeScanListener mOnLeScanListener = new LsBluetooth.OnLeScanListener() {
        @Override
        public void onStarted() {
            Log.d(TAG, "[LE] Scan Start ================");
            mScanning = true;
            //mImageViewScan.setText("STOP");
            mImageViewScan.setEnabled(true);
            mScanButtonClicked = false;
        }

        @Override
        public boolean onDone(int itemCount) {
            Log.d(TAG, "[LE] Scan Done -----------------");
            Log.d(TAG, "itemCount=" + itemCount);
            return true;
        }

        @Override
        public void onStopped() {
            Log.d(TAG, "[LE] Scan Stop -----------------");
            mScanning = false;
            //mImageViewScan.setText("SCAN");
            mImageViewScan.setEnabled(true);
            mScanButtonClicked = false;
        }

        @Override
        public boolean onDeviceFound(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
            @SuppressLint("MissingPermission") String devName = device.getName();
            if (devName == null)
                return false;

            String namePrefix = devName.substring(0, 5);
            if (namePrefix != null && namePrefix.compareTo("VoBLE") == 0)
                return true;

            namePrefix = devName.substring(0, 3);
            if (namePrefix != null && namePrefix.compareTo("CSY") == 0)
                return true;

            namePrefix = devName.substring(0, 4);
            if (namePrefix != null && namePrefix.compareTo("SSBN") == 0)
                return true;

            return false;
        }

        @Override
        public void onDeviceAdded(final BluetoothDevice device, final int rssi) {
            getActivity().runOnUiThread(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    mViewModel.addSynesper(device.getName(), device.getAddress(),   rssi);
                    Log.d(TAG, "[LE] Scan: Addr=" + device.getAddress() + ", rssi=" + rssi);
                }
            });
        }

        @Override
        public void onDeviceUpdated(BluetoothDevice device, int rssi) {

        }
    };
}