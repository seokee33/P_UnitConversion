package kr.claud.synesper.ui.setting.menu;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class PulseViewModel extends ViewModel {

    public PulseViewModel() {
    }
}