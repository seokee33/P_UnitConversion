package ky.labsource.common;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;



public abstract class ViewLayer extends Canvas implements ViewLayerIface.IResources {
    public static final String TAG = "ViewLayer";
    public static final int UNDEF_ID = -1;

    protected int _id = UNDEF_ID;
    protected RectF _rect = new RectF();
    protected Bitmap _bitmap = null;


    //--- Layer Invalid Listener ---
    protected ViewLayerIface.OnLayerInvalidListener _layerInvalidListener = null;
    public void setOnLayerInvalidListener(ViewLayerIface.OnLayerInvalidListener listener) { _layerInvalidListener = listener; }

    //--- Layer Draw Listener ---
    protected ViewLayerIface.OnLayerDrawListener _layerDrawListener = null;
    public void setOnLayerDrawListener(ViewLayerIface.OnLayerDrawListener listener) { _layerDrawListener = listener; }

    protected boolean _bEnabled = true;
    public boolean isEnabled() { return _bEnabled; }
    public void setEnabled(boolean bEnabled) {
        this._bEnabled = bEnabled;
    }

    protected boolean _bRedraw = false;
    protected boolean _bInvalid = false;
    public boolean isInvalid() { return _bInvalid; }

    /**
     * ViewLayer 를 다시 그리도록 설정
     *
     * @param bInvalid layer가 속한 View가 다시 그려져야 함을 지시
     * @param bRedraw  _bitmap 이 생성된 경우 onDraw() 에서는 _bRedraw의 값이 true 이면
     *                 layer의 Canvas 에 그린 후 _bitmap을 기본 레이어의 Canvas에 그린다.
     *                 false 이면 현재의 _bitmap을 그대로 기본 레이어의 Canavas에 그린다.
     *                 _bitmap 이 생성되지 않은 경우 기본 레이어의 Canvas에 onDraw() 함수를
     *                 통해 직접 그리기를 한다.
     */

    public void invalidate(boolean bInvalid, boolean bRedraw) {
        _bRedraw = bRedraw;
        _bInvalid = bInvalid;

        if (_layerInvalidListener != null)
            _layerInvalidListener.onInvalidate(this, _bInvalid);
    }

    public float LAYER_X(float world_x) { return (world_x - _rect.left); }
    public float LAYER_Y(float world_y) { return (world_y - _rect.top); }


    public boolean create(RectF r, boolean bCreateBitmap) {
        return create(r, bCreateBitmap, UNDEF_ID);
    }

    public boolean create(RectF r, boolean bCreateBitmap, int id) {
        _id = id;
        _rect.set((float)(int)r.left, (float)(int)r.top, (float)(int)r.right, (float)(int)r.bottom);

        if (bCreateBitmap) {
            createBitmap();
        }
        else {
            destroyBitmap();
        }

        return true;
    }

    public void destroy() {
        _bitmap = null;
    }

    public void moveTo(int x, int y) {
        _rect.offsetTo(x, y);
    }

    public float WidthF() {
        return _rect.width();
    }

    public float HeightF() {
        return _rect.height();
    }

    public void createBitmap() {
        int w = (int) _rect.width();
        int h = (int) _rect.height();
        if (w > 0 && h > 0) {
            _bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            clearBitmap();

            setBitmap(_bitmap);
        }
    }

    public void destroyBitmap() {
        _bitmap = null;
        setBitmap(null);
    }

    public void clearBitmap() {
        drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
        if (_bitmap != null)
            _bitmap.eraseColor(Color.TRANSPARENT);
    }

    public void translateBitmap(int dx, int dy)
    {
        if (_bitmap == null)
            return;

        int bmWidth = _bitmap.getWidth();
        int bmHeight = _bitmap.getHeight();
        Bitmap.Config bmConfig = _bitmap.getConfig();

        Bitmap translateBitmap = Bitmap.createBitmap(bmWidth, bmHeight, bmConfig);
        translateBitmap.eraseColor(Color.TRANSPARENT);
        Canvas translateCanvas = new Canvas(translateBitmap);
        Matrix translateMatrix = new Matrix();

        translateMatrix.setTranslate(dx, dy);
        translateCanvas.drawBitmap(_bitmap, translateMatrix, new Paint());

        _bitmap = translateBitmap;
        setBitmap(_bitmap);
    }


    public void drawBitmapTo(Canvas canvas) {
        if (_bitmap != null)
            canvas.drawBitmap(_bitmap, _rect.left, _rect.top, null);

        _bRedraw = false;
        _bInvalid = false;
    }

    public void drawTo(Canvas canvas) {
        if (_bitmap != null) {
            if (_bRedraw) {
                clearBitmap();

                if (_layerDrawListener != null)
                    _layerDrawListener.onDraw(this, this);
            }

            drawBitmapTo(canvas);
        }
        else {
            if (_layerDrawListener != null)
                _layerDrawListener.onDraw(this, canvas);
        }

        _bRedraw = false;
        _bInvalid = false;
    }
}
