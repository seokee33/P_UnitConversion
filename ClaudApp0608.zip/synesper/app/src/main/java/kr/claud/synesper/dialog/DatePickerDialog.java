package kr.claud.synesper.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;

import androidx.annotation.NonNull;

import kr.claud.synesper.R;

public class DatePickerDialog  extends Dialog implements View.OnClickListener {

    private DatePicker datePicker;
    private Button btnOk;
    private Button btnCancel;

    public interface DatePickerDialogListener {
        void onPositiveClicked(int year, int month, int day);
        void onNegativeClicked();
    }
    private DatePickerDialogListener mDatePickerDialogListener;
    public void setDialogListener(DatePickerDialogListener l) {
        this.mDatePickerDialogListener = l;
    }


    public DatePickerDialog(@NonNull Context context) {
        super(context);
    }

    public DatePickerDialog(@NonNull Context context, int themeResId) {
        super(context, themeResId);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_date_picker);

        datePicker = (DatePicker) findViewById(R.id.dataPickerDelivery);
        btnOk = (Button) findViewById(R.id.buttonOK);
        btnCancel = (Button) findViewById(R.id.buttonCancel);

        btnOk.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.buttonOK:
                if (mDatePickerDialogListener != null) {
                    int year = datePicker.getYear();
                    int month = datePicker.getMonth() + 1;
                    int day = datePicker.getDayOfMonth();
                    mDatePickerDialogListener.onPositiveClicked(year, month, day);
                }
                dismiss();
                break;

            case R.id.buttonCancel:
                if (mDatePickerDialogListener != null) {
                    mDatePickerDialogListener.onNegativeClicked();
                }
                dismiss();
                break;
        }
    }
}
