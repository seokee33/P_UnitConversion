package ky.labsource.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
//import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.content.ContextCompat;

import ky.labsource.R;
import ky.labsource.common.StepDivider;

/**
 * CircleGauge view class.
 *
 * usage:
 *         mCircleGauge = (CircleGauge) findViewById(R.id.circleGauge);
 *         mCircleGauge.setOnCircleGaugeTouchEventListener(mCircleGaugeTouchEventListener);
 *         mCircleGauge.setOnCircleGaugeHeadDrawListener(mCircleGaugeHeadDrawListener);
 *         mCircleGauge.setOnCircleGaugeTailDrawListener(mCircleGaugeTailDrawListener);
 *         mCircleGauge.setBottomText(getString(R.string.measure_unit_usvperhour));
 *         mCircleGauge.invalidate();
 *
 *
 *         mCircleGauge.moveValue(100f);
 *         mCircleGauge.setValue(100f);
 */
public class CircleGauge extends View {
    private static final String TAG = "CircleGauge";

    // Attrs
    private float    maStrokeWidth;
    private int      maStrokeColor;
    private String   maStrokeCap;
    private int      maFaceColor = Color.BLACK;

    private String   maTopText;
    private int      maTopTextColor = Color.WHITE;
    private float    maTopTextSize = 0;
    private Drawable maTopDrawable;
    private String   maBottomText;
    private int      maBottomTextColor = Color.WHITE;
    private float    maBottomTextSize = 0;
    private Drawable maBottomDrawable;

    private float    maMinValue = 0;
    private float    maMaxValue = 100;
    private float    maValue = 0;


    private static final int NUM_MODE_INT = 0;
    private static final int NUM_MODE_POINT2 = 1;

    private int      maNumMode = NUM_MODE_INT;



    public float getStrokeWidth() { return maStrokeWidth; }
    public void setStrokeWidth(float strokeWidth) {
        maStrokeWidth = strokeWidth;
        clearCircleGaugeBitmap();
    }
    public int getStrokeColor() { return maStrokeColor; }
    public void setStrokeColor(int strokeColor) {
        maStrokeColor = strokeColor;
        clearCircleGaugeBitmap();
    }
    public int getFaceColor() { return maFaceColor; }
    public void setFaceColor(int faceColor) {
        maFaceColor = faceColor;
        clearCircleGaugeBitmap();
    }
    public String getTopText() { return maTopText; }
    public void setTopText(String topText) { maTopText = topText; }
    public int getTopTextColor() { return maTopTextColor; }
    public void setTopTextColor(int color) {
        maTopTextColor = color;
        topTextPaint.setColor(maTopTextColor);
    }
    public float getTopTextSize() { return maTopTextSize; }
    public void setTopTextSize(float size) {
        maTopTextSize = size;
        topTextPaint.setTextSize(maTopTextSize);
    }
    public Drawable getTopDrawable() { return maTopDrawable; }
    public void setTopDrawable(Drawable topDrawable) { maTopDrawable = topDrawable; }

    public String getBottomText() { return maBottomText; }
    public void setBottomText(String bottomText) { maBottomText = bottomText; }
    public int getBottomTextColor() { return maBottomTextColor; }
    public void setBottomTextColor(int color) {
        maBottomTextColor = color;
        bottomTextPaint.setColor(maBottomTextColor);
    }
    public float getBottomTextSize() { return maBottomTextSize; }
    public void setBottomTextSize(float size) {
        maBottomTextSize = size;
        bottomTextPaint.setTextSize(maBottomTextSize);
    }

    /**
     * Gets the bottom drawable attribute value.
     *
     * @return The bottom drawable attribute value.
     */
    public Drawable getBottomDrawable() {
        return maBottomDrawable;
    }

    /**
     * Sets the view's bottom drawable attribute value. In the example view, this drawable is
     * drawn above the text.
     *
     * @param bottomDrawable The bottom drawable attribute value to use.
     */
    public void setBottomDrawable(Drawable bottomDrawable) {
        maBottomDrawable = bottomDrawable;
    }


    public float getMinValue() { return maMinValue; }
    public void setMinValue(float value) {
        maMinValue = value;
        if (maMinValue > maMaxValue)
            maMaxValue = maMinValue + 1;
        mPointAngle = ((double) Math.abs(mSweepAngle) / (maMaxValue - maMinValue));
        if (getValue() < maMinValue)
            setValue(maMinValue);
    }
    public float getMaxValue() { return maMaxValue; }
    public void setMaxValue(float value) {
        maMaxValue = value;
        if (maMinValue > maMaxValue)
            maMinValue = maMaxValue - 1;
        mPointAngle = ((double) Math.abs(mSweepAngle) / (maMaxValue - maMinValue));
        if (getValue() > maMaxValue)
            setValue(maMaxValue);
    }
    public float getValue() { return maValue; }
    public void setValue(float value) {
        float tmpValue;
        maValue = value;
        tmpValue = value;
        if (value > maMaxValue)
            tmpValue = maMaxValue;
        mPoint = (int) (mStartAngle + (tmpValue-maMinValue) * mPointAngle);
    }

    //==========================
    private static final int mStartAngle = 210;
    private static final int mSweepAngle = 120;

    private double mPointAngle;
    private int mPoint;

    private float[] mSectorRates = {          1f,           2f,        7f };
    private int[] mSectorColors  = { Color.GREEN, Color.YELLOW, Color.RED };



    private StepDivider.OnStepDividerListener mOnStepDividerListener = new StepDivider.OnStepDividerListener() {
        @Override
        public void onStep(StepDivider stepDivider, int point, boolean bLast) {
            CircleGauge.this.invalidate();

            Log.i(TAG, "onStep():invalidate - " + point + " / " + getCurPoint());
        }
    };

    private StepDivider mStepAnimation = new StepDivider(3.f, 300, mOnStepDividerListener);

    private int getCurPoint() {
        if (mStepAnimation.isEnabled())
            return (int)mStepAnimation.getCurPoint();
        return mPoint;
    }

    public void moveValue(float value) {
        int curPoint = mPoint;
        setValue(value);
        mStepAnimation.move(curPoint, mPoint, StepDivider.REGULARTIME);
    }

    public void setSectors(float[] rates, int[] colors) {
        clearCircleGaugeBitmap();

        mSectorRates = rates;
        mSectorColors = colors;
    }

    //==========================
    private int    mCircleGaugeBitmapWidth = 0;
    private int    mCircleGaugeBitmapHeight = 0;
    private Bitmap mCircleGaugeBitmap = null;
    private Canvas mCircleGaugeCanvas = null;


    private Paint mOuterPaint;

    private Paint mRimPaint;
    private Paint mRimCirclePaint;
    private Paint mRimShadowPaint;
    private Paint mFacePaint;


    private Paint topTextPaint;
    private Paint bottomTextPaint;


    RectF mRectOuter;
    RectF mRectInner;
    Rect mRectTop;
    Rect mRectBottom;
    Rect mRectGauge;
    Rect mRectGaugeHead;
    Rect mRectGaugeTail;
    //----------------------------------


    private TextPaint mTextPaint;
    private float mTextWidth;
    private float mTextHeight;


    //==================================================
    public CircleGauge(Context context) {
        super(context);

        initGdiObject();
    }

    public CircleGauge(Context context, AttributeSet attrs) {
        super(context, attrs);

        init(attrs, 0);
        initGdiObject();
    }

    public CircleGauge(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        init(attrs, defStyle);
        initGdiObject();
    }

    private void init(AttributeSet attrs, int defStyle) {
        // Load attributes
        final TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.CircleGauge, defStyle, 0);

        // stroke style
        maStrokeWidth = a.getDimension(R.styleable.CircleGauge_circleGaugeStrokeWidth, 10);
        maStrokeColor = a.getColor(R.styleable.CircleGauge_circleGaugeStrokeColor, ContextCompat.getColor(getContext(), android.R.color.darker_gray));
        maStrokeCap = a.getString(R.styleable.CircleGauge_circleGaugeStrokeCap);

        //
        maFaceColor = a.getColor(R.styleable.CircleGauge_circleGaugeFaceColor, maFaceColor);


        //mExampleString = a.getString(R.styleable.CircleGauge_circleGaugeString);
        //mExampleColor = a.getColor(R.styleable.CircleGauge_circleGaugeColor, mExampleColor);
        // Use getDimensionPixelSize or getDimensionPixelOffset when dealing with
        // values that should fall on pixel boundaries.
        //mExampleDimension = a.getDimension(R.styleable.CircleGauge_circleGaugeDimension, mExampleDimension);

        maTopText = a.getString(R.styleable.CircleGauge_circleGaugeTopText);
        maTopTextColor = a.getColor(R.styleable.CircleGauge_circleGaugeTopTextColor, maTopTextColor);
        maTopTextSize = a.getDimension(R.styleable.CircleGauge_circleGaugeTopTextSize, maTopTextSize);
        if (a.hasValue(R.styleable.CircleGauge_circleGaugeTopDrawable)) {
            maTopDrawable = a.getDrawable(R.styleable.CircleGauge_circleGaugeTopDrawable);
            maTopDrawable.setCallback(this);
        }
        maBottomText = a.getString(R.styleable.CircleGauge_circleGaugeBottomText);
        maBottomTextColor = a.getColor(R.styleable.CircleGauge_circleGaugeBottomTextColor, maBottomTextColor);
        maBottomTextSize = a.getDimension(R.styleable.CircleGauge_circleGaugeBottomTextSize, maBottomTextSize);
        if (a.hasValue(R.styleable.CircleGauge_circleGaugeBottomDrawable)) {
            maBottomDrawable = a.getDrawable(R.styleable.CircleGauge_circleGaugeBottomDrawable);
            maBottomDrawable.setCallback(this);
        }


        maMinValue = a.getFloat(R.styleable.CircleGauge_circleGaugeMinValue, maMinValue);
        maMaxValue = a.getFloat(R.styleable.CircleGauge_circleGaugeMaxValue, maMaxValue);
        maValue = a.getFloat(R.styleable.CircleGauge_circleGaugeValue, maValue);

        mPointAngle = ((double) Math.abs(mSweepAngle) / (maMaxValue - maMinValue));
        mPoint = (int) (mStartAngle + (maValue-maMinValue) * mPointAngle);

        a.recycle();
    }

    private boolean createCircleGaugeBitmap(int w, int h) {
        if (mCircleGaugeBitmapWidth == w && mCircleGaugeBitmapHeight == h) {
            if (mCircleGaugeBitmap != null && mCircleGaugeCanvas != null)
                return false;
        }

        if (mCircleGaugeCanvas != null)
            mCircleGaugeCanvas = null;
        if (mCircleGaugeBitmap != null)
            mCircleGaugeBitmap = null;

        mCircleGaugeBitmapWidth = w;
        mCircleGaugeBitmapHeight = h;

        mCircleGaugeBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCircleGaugeCanvas = new Canvas();
        mCircleGaugeCanvas.setBitmap(mCircleGaugeBitmap);
        return true;
    }

    public void clearCircleGaugeBitmap() {
        if (mCircleGaugeCanvas != null)
            mCircleGaugeCanvas = null;
        if (mCircleGaugeBitmap != null)
            mCircleGaugeBitmap = null;

        mCircleGaugeBitmapWidth = 0;
        mCircleGaugeBitmapHeight = 0;
    }

    private void initGdiObject() {
        // Set up a default TextPaint object
        mOuterPaint = new Paint();
        mOuterPaint.setColor(maStrokeColor);
        mOuterPaint.setAntiAlias(true);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND); // ROUND or BUTT
        mOuterPaint.setStyle(Paint.Style.STROKE);

        mRimPaint = new Paint();
        mRimPaint.setFlags(Paint.ANTI_ALIAS_FLAG);

        mRimCirclePaint = new Paint();
        mRimCirclePaint.setAntiAlias(true);
        mRimCirclePaint.setStyle(Paint.Style.STROKE);

        mRimShadowPaint = new Paint();
        mRimShadowPaint.setStyle(Paint.Style.FILL);


        mFacePaint = new Paint();
        mFacePaint.setAntiAlias(true);
        mFacePaint.setStyle(Paint.Style.FILL);
        mFacePaint.setColor(maFaceColor);


        topTextPaint = new Paint();
        topTextPaint.setColor(maTopTextColor);
        topTextPaint.setTypeface(Typeface.SANS_SERIF);
        topTextPaint.setTextAlign(Paint.Align.CENTER);
        topTextPaint.setTextSize(maTopTextSize);

        bottomTextPaint = new Paint();
        bottomTextPaint.setColor(maBottomTextColor);
        bottomTextPaint.setTypeface(Typeface.SANS_SERIF);
        bottomTextPaint.setTextAlign(Paint.Align.CENTER);
        bottomTextPaint.setTextSize(maBottomTextSize);
        bottomTextPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));


        mRectOuter = new RectF();
        mRectInner = new RectF();
        mRectTop = new Rect();
        mRectBottom = new Rect();
        mRectGauge = new Rect();
        mRectGaugeHead = new Rect();
        mRectGaugeTail = new Rect();
        //-------------------------------------
        mTextPaint = new TextPaint();
        mTextPaint.setFlags(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.setTextAlign(Paint.Align.LEFT);

        // Update TextPaint and text measurements from attributes
        invalidateTextPaintAndMeasurements();
    }

    private void invalidateTextPaintAndMeasurements() {
        mTextPaint.setTextSize(maTopTextSize);
        mTextPaint.setColor(maTopTextColor);
        mTextWidth = mTextPaint.measureText(maTopText);

        Paint.FontMetrics fontMetrics = mTextPaint.getFontMetrics();
        mTextHeight = fontMetrics.bottom;
    }

    private void recalcLayout() {
        float paddingLeft = getPaddingLeft();
        float paddingTop = getPaddingTop();
        float paddingRight = getPaddingRight();
        float paddingBottom = getPaddingBottom();

        float contentWidth = getWidth() - paddingLeft - paddingRight;
        float contentHeight = getHeight() - paddingTop - paddingBottom;

        float outerDiameter = (contentHeight < contentWidth - maStrokeWidth) ? (contentHeight + maStrokeWidth) : contentWidth;
        float outerRadius = outerDiameter / 2f;
        float innerRadius = outerRadius - maStrokeWidth;
        float innerDiameter = innerRadius * 2f;

        float rectLeft = (contentWidth - outerDiameter)/2 + paddingLeft;
        float rectTop = paddingTop;
        float rectRight = rectLeft + outerDiameter;
        float rectBottom = rectTop + outerDiameter;

        mRectOuter = new RectF(rectLeft, rectTop, rectRight, rectBottom);

        float cxOuter = mRectOuter.centerX();
        float cyOuter = mRectOuter.centerY();
        mRectInner.set(cxOuter - innerRadius, cyOuter - innerRadius, cxOuter + innerRadius, cyOuter + innerRadius);

        float cxInner = mRectInner.centerX();
        float cyInner = mRectInner.centerY();

        mRectTop.set((int)(cxInner - innerRadius/2), (int)(mRectInner.top + innerDiameter*0.12f), (int)(cxInner + innerRadius/2), (int)(cyInner - innerRadius*5/12));
        mRectBottom.set((int)(cxInner - innerRadius/2), (int)(cyInner + innerRadius*5/12), (int)(cxInner + innerRadius/2), (int)(mRectInner.bottom - innerDiameter*0.12f));
        mRectGauge.set((int)(mRectInner.left + innerDiameter*0.15f), (int)(cyInner - innerRadius*5/12), (int)(mRectInner.right - innerDiameter*0.15f), (int)(cyInner + innerRadius*5/12));
        mRectGaugeHead.set(mRectGauge);
        mRectGaugeHead.bottom = mRectGaugeHead.top + (int)(mRectGauge.height()*0.2f);
        mRectGaugeTail.set(mRectGauge);
        mRectGaugeTail.top = mRectGaugeTail.bottom - (int)(mRectGauge.height()*0.2f);
    }

    private void drawOuterBackground(Canvas canvas, RectF rcArea) {
        float strokeWidth = maStrokeWidth;

        RectF rcDrawBorder = new RectF(rcArea);
        rcDrawBorder.inset(strokeWidth/2, strokeWidth/2);

        mOuterPaint.setStrokeWidth(strokeWidth);
        mOuterPaint.setColor(0x88000000);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        mOuterPaint.setShader(null);
        canvas.drawArc(rcDrawBorder, mStartAngle, mSweepAngle, false, mOuterPaint);

        strokeWidth = strokeWidth - 8f;

        mOuterPaint.setStrokeWidth(strokeWidth);
        mOuterPaint.setColor(maStrokeColor);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        mOuterPaint.setShader(null);
        //mOuterPaint.setShader(new LinearGradient(getWidth(), getHeight(), 0, 0, mPointEndColor, mPointStartColor, Shader.TileMode.CLAMP));
        //mOuterPaint.setShader(new LinearGradient(0, 0, getWidth(), 0, colors, pos, Shader.TileMode.CLAMP));
        canvas.drawArc(rcDrawBorder, mStartAngle, mSweepAngle, false, mOuterPaint);

        RectF rcDraw = new RectF(rcDrawBorder);
        //int mPointStartColor = Color.GREEN;
        //int mPointEndColor = Color.RED;
        mOuterPaint.setStrokeWidth(strokeWidth*0.8f);

        //mPointStartColor = Color.LTGRAY;
        //mPointEndColor = Color.DKGRAY;

        int nSector = mSectorRates.length;
        float sumRate = 0f;
        for (float r : mSectorRates) sumRate += r;

        mOuterPaint.setShader(null);
        //mOuterPaint.setShader(new LinearGradient(getWidth(), getHeight(), 0, 0, mPointEndColor, mPointStartColor, Shader.TileMode.CLAMP));

        float startAngle = mStartAngle;
        float sweepAngle = 0.1f;
        mOuterPaint.setColor(mSectorColors[0]);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawArc(rcDraw, startAngle, sweepAngle, false, mOuterPaint);

        int i;
        mOuterPaint.setStrokeCap(Paint.Cap.BUTT);
        for (i=0 ; i<nSector ; i++) {
            float secRate = mSectorRates[i]/sumRate;
            sweepAngle = mSweepAngle*secRate;
            mOuterPaint.setColor(mSectorColors[i]);

            float adjStart = (i == 0) ? 0f : 0.5f;
            float adjSweep = adjStart + ((i == (nSector-1)) ? 0f : 0.5f);

            canvas.drawArc(rcDraw, startAngle + adjStart, sweepAngle - adjSweep, false, mOuterPaint);
            startAngle += sweepAngle;
        }
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        canvas.drawArc(rcDraw, startAngle - 0.1f, 0.1f, false, mOuterPaint);

        /*
        mPointStartColor = Color.GREEN;
        mPointEndColor = Color.RED;
        //mOuterPaint.setStrokeWidth(strokeWidth*0.1f);
        mOuterPaint.setColor(Color.GREEN);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        mOuterPaint.setShader(new LinearGradient(getWidth(), getHeight(), 0, 0, colors, pos, Shader.TileMode.CLAMP));
        if (maValue == maMinValue) //use non-zero default value for start point (to avoid lack of pointer for start/zero value)
            canvas.drawArc(rcDraw, mStartAngle, 0.1f, false, mOuterPaint);
        else
            canvas.drawArc(rcDraw, mStartAngle, mPoint - mStartAngle, false, mOuterPaint);
        */

        //TODO:
        RectF rcText = new RectF(rcArea);
        rcText.inset(maStrokeWidth*0.6f, maStrokeWidth*0.6f);

        Path pathSafety = new Path();
        pathSafety.addArc(rcText, mStartAngle, mSweepAngle/3f);
        Path pathDanger = new Path();
        pathDanger.addArc(rcText, mStartAngle + mSweepAngle*2f/3f, mSweepAngle/3f);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        paint.setColor(0x88000000); //Color.GREEN
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setTextSize(maStrokeWidth*0.35f);
        canvas.drawTextOnPath("SAFETY", pathSafety, 0, 0, paint);


        paint.setColor(0x88000000); //Color.RED
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTextSize(maStrokeWidth*0.35f);
        canvas.drawTextOnPath("DANGER", pathDanger, 0, 0, paint);


        //------------------------
        //RectF rcShadow = new RectF(rcDraw);
        //rcShadow.offset(strokeWidth*0.07f, strokeWidth*0.01f);
        //drawOuterNeedle(canvas, rcShadow, 0x88888888);
        //drawOuterNeedle(canvas, rcDraw, Color.BLACK);

/*
        startAngle = mPoint - 0.05f;
        sweepAngle = 0.1f;
        mOuterPaint.setColor(Color.BLACK);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        mOuterPaint.setStrokeWidth(strokeWidth*0.7f);
        mOuterPaint.setShadowLayer(0.5f, 5, 5, SHADOW_COLOR);
        canvas.drawArc(rcDraw, startAngle, sweepAngle, false, mOuterPaint);
        mOuterPaint.clearShadowLayer();
        mOuterPaint.setColor(0xFFFF0000);
        mOuterPaint.setStrokeCap(Paint.Cap.ROUND);
        mOuterPaint.setStrokeWidth(strokeWidth*0.4f);
        canvas.drawArc(rcDraw, startAngle, sweepAngle, false, mOuterPaint);
*/
    }

    private void drawOuterRange(Canvas canvas, RectF rcArea) {
        RectF rcValue = new RectF(rcArea);
        rcValue.inset(maStrokeWidth*1.2f, maStrokeWidth*1.2f);

        Path pathMin = new Path();
        pathMin.addArc(rcValue, mStartAngle - mSweepAngle*0.2f, mSweepAngle*0.4f);
        Path pathMax = new Path();
        pathMax.addArc(rcValue, mStartAngle + mSweepAngle*0.8f, mSweepAngle*0.4f);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        paint.setTextSize(maStrokeWidth/4f);

        paint.setColor(Color.BLACK); //Color.GREEN
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawTextOnPath(String.valueOf(maMinValue), pathMin, 0, 0, paint);

        paint.setColor(Color.BLACK); //Color.RED
        paint.setTextAlign(Paint.Align.CENTER);
        canvas.drawTextOnPath(String.valueOf(maMaxValue), pathMax, 0, 0, paint);
    }

    private void drawOuterNeedle(Canvas canvas, RectF rcNeedle, int needleColor) {
        float strokeWidth = maStrokeWidth;
        double needleDegree = 360. - getCurPoint();
        //final int SHADOW_COLOR = 0x80333333;
        float needleRadius = strokeWidth*0.3f;
        float needleStroke = strokeWidth*0.15f;
        float r = rcNeedle.width()*0.47f;
        float cx = rcNeedle.centerX() + r * (float)Math.cos((float)Math.toRadians(needleDegree));
        float cy = rcNeedle.centerY() - r * (float)Math.sin((float)Math.toRadians(needleDegree));
        //float[] pts = new float[4*3];

        Path pathTri = new Path();
        pathTri.setFillType(Path.FillType.EVEN_ODD);
        float tx = rcNeedle.centerX() + (r + needleRadius + needleStroke*1.5f) * (float)Math.cos((float)Math.toRadians(needleDegree));
        float ty = rcNeedle.centerY() - (r + needleRadius + needleStroke*1.5f) * (float)Math.sin((float)Math.toRadians(needleDegree));
        pathTri.moveTo(tx,ty);
        tx = rcNeedle.centerX() + (r + needleRadius) * (float)Math.cos((float)Math.toRadians(needleDegree - 2));
        ty = rcNeedle.centerY() - (r + needleRadius) * (float)Math.sin((float)Math.toRadians(needleDegree - 2));
        pathTri.lineTo(tx,ty);
        tx = rcNeedle.centerX() + (r + needleRadius) * (float)Math.cos((float)Math.toRadians(needleDegree + 2));
        ty = rcNeedle.centerY() - (r + needleRadius) * (float)Math.sin((float)Math.toRadians(needleDegree + 2));
        pathTri.lineTo(tx,ty);
        pathTri.close();

        float x1 = rcNeedle.centerX() + (r + needleRadius) * (float)Math.cos((float)Math.toRadians(needleDegree));
        float y1 = rcNeedle.centerY() - (r + needleRadius) * (float)Math.sin((float)Math.toRadians(needleDegree));
        float x2 = rcNeedle.centerX() + (r - needleRadius) * (float)Math.cos((float)Math.toRadians(needleDegree));
        float y2 = rcNeedle.centerY() - (r - needleRadius) * (float)Math.sin((float)Math.toRadians(needleDegree));

        Paint needlePaint = new Paint();
        needlePaint.setAntiAlias(true);
        needlePaint.setColor(needleColor);
        //needlePaint.setShadowLayer(3.0f, 5, 5, SHADOW_COLOR);

        needlePaint.setStyle(Paint.Style.FILL);
        needlePaint.setStrokeWidth(1.0f);
        canvas.drawPath(pathTri, needlePaint);

        needlePaint.setStyle(Paint.Style.STROKE);
        needlePaint.setStrokeWidth(needleStroke);
        canvas.drawLine(rcNeedle.centerX(), rcNeedle.centerY(), x2, y2, needlePaint);

        canvas.drawCircle(cx, cy, needleRadius, needlePaint);
        //needlePaint.clearShadowLayer();
    }

    private void drawInnerBackground(Canvas canvas, RectF rcArea) {
        float innerWidth = rcArea.width();
        float innerHeight = rcArea.height();

        RectF rimRect = new RectF(innerWidth * .05f, innerHeight * .05f, innerWidth * 0.95f, innerHeight * 0.95f);
        rimRect.offset(rcArea.left, rcArea.top);
        drawInnerRim(canvas, rimRect);

        float rimSize = 0.02f * innerWidth;
        RectF faceRect = new RectF();
        faceRect.set(rimRect.left + rimSize, rimRect.top + rimSize, rimRect.right - rimSize, rimRect.bottom - rimSize);


        mRimShadowPaint.setShader(new RadialGradient(0.5f * innerWidth + rcArea.left, 0.5f * innerHeight + rcArea.top, faceRect.width() / 2.0f,
                new int[]{0x00000000, 0x00000500, 0x50000500},
                new float[]{0.96f, 0.96f, 0.99f},
                Shader.TileMode.MIRROR));
        mFacePaint.setColor(maFaceColor);

        canvas.drawOval(faceRect, mFacePaint);
        //canvas.drawOval(faceRect, mRimCirclePaint);
        //canvas.drawOval(faceRect, mRimShadowPaint);

        Paint sepaPaint = new Paint();
        sepaPaint.setStrokeWidth(rcArea.height()*0.01f);
        sepaPaint.setAntiAlias(true);
        sepaPaint.setColor(Color.WHITE);

        canvas.drawLine(mRectGauge.left, mRectTop.bottom, mRectGauge.right, mRectTop.bottom, sepaPaint);
        canvas.drawLine(mRectGauge.left, mRectBottom.top, mRectGauge.right, mRectBottom.top, sepaPaint);
    }

    private void drawInnerRim(Canvas canvas, RectF rimRect) {
        float innerWidth = rimRect.width();
        float innerHeight = rimRect.height();

        mRimPaint.setShader(new LinearGradient(innerWidth * 0.40f + rimRect.left, innerHeight * 0.0f + rimRect.top, innerWidth * 0.60f + rimRect.left, innerHeight * 1.0f + rimRect.top,
                Color.rgb(0xf0, 0xf5, 0xf0),
                Color.rgb(0x30, 0x31, 0x30),
                Shader.TileMode.CLAMP));

        mRimCirclePaint.setColor(Color.argb(0x4f, 0x33, 0x36, 0x33));
        mRimCirclePaint.setStrokeWidth(0.005f);

        canvas.drawOval(rimRect, mRimPaint);
        canvas.drawOval(rimRect, mRimCirclePaint);
    }

    private void drawTopAndBottom(Canvas canvas, Rect rcTop, Rect rcBottom) {
        if (maTopDrawable != null) {
            maTopDrawable.setBounds(rcTop.left, rcTop.top, rcTop.right, rcTop.bottom);
            maTopDrawable.draw(canvas);
        }
        else {
            if (!TextUtils.isEmpty(maTopText)) {
                canvas.drawText(maTopText, rcTop.centerX(), rcTop.centerY(), topTextPaint);
                //drawTextCentered(maTopText, rcTop.centerX(), rcTop.centerY(), topTextPaint, canvas);
            }
        }

        if (maBottomDrawable != null) {
            maBottomDrawable.setBounds(rcBottom.left, rcBottom.top, rcBottom.right, rcBottom.bottom);
            maBottomDrawable.draw(canvas);
        }
        else {
            if (!TextUtils.isEmpty(maBottomText)) {
                canvas.drawText(maBottomText, rcBottom.centerX(), rcBottom.centerY()+rcBottom.height()/4, bottomTextPaint);
                //drawTextCentered(maBottomText, rcBottom.centerX(), rcBottom.centerY(), bottomTextPaint, canvas);
            }
        }

        Paint sepaPaint = new Paint();
        sepaPaint.setStrokeWidth(rcTop.height()*0.02f);
        sepaPaint.setColor(Color.WHITE);

        //canvas.drawLine(rcTop.left, rcTop.bottom, rcTop.right, rcTop.bottom, sepaPaint);
        //canvas.drawLine(rcBottom.left, rcBottom.top, rcBottom.right, rcBottom.top, sepaPaint);
    }

    private void drawGauge(Canvas canvas, Rect rcArea) {
        int iVal = (int)maValue;
        int dVal = (int)((maValue - (float)iVal)*100);

        Paint textPaint = new Paint();
        textPaint.setAntiAlias(true);
        textPaint.setTextSize(rcArea.height()*0.5f);
        textPaint.setColor(Color.WHITE);

        if (maNumMode == NUM_MODE_INT) {
            float xpos = rcArea.right;// - rcArea.width()*0.1f;
            float ypos = rcArea.centerY() + rcArea.height()*0.2f;
            textPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(String.valueOf(iVal), xpos, ypos, textPaint);
        }
        else {
            Rect rcBound = new Rect();
            float xpos = rcArea.centerX() + rcArea.width()*0.1f;
            float ypos = rcArea.centerY() + rcArea.height()*0.2f;
            textPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(String.valueOf(iVal), xpos, ypos, textPaint);

            textPaint.setTextAlign(Paint.Align.LEFT);
            textPaint.getTextBounds(".", 0, 1, rcBound);
            canvas.drawText(".", xpos, ypos, textPaint);
            xpos += rcBound.width()*2;
            canvas.drawText(String.valueOf(dVal), xpos, ypos, textPaint);
        }
    }

    private void drawTextCentered(String text, float x, float y, Paint paint, Canvas canvas) {
        //float xPos = x - (paint.measureText(text)/2f);
        float yPos = (y - ((paint.descent() + paint.ascent()) / 2f));
        canvas.drawText(text, x, yPos, paint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();

        int contentWidth = getWidth() - paddingLeft - paddingRight;
        int contentHeight = getHeight() - paddingTop - paddingBottom;

        if (createCircleGaugeBitmap(contentWidth, contentHeight)) {
            drawOuterBackground(mCircleGaugeCanvas, mRectOuter);
            //drawInnerBackground(mCircleGaugeCanvas, mRectInner);
        }

        canvas.drawBitmap(mCircleGaugeBitmap, paddingLeft, paddingTop, null);

        drawOuterRange(canvas, mRectOuter);

        RectF rcNeedle = new RectF(mRectOuter);
        rcNeedle.inset(maStrokeWidth/2, maStrokeWidth/2);
        RectF rcNeedleShadow = new RectF(rcNeedle);
        rcNeedleShadow.offset(maStrokeWidth*0.07f, maStrokeWidth*0.01f);
        drawOuterNeedle(canvas, rcNeedleShadow, 0x88888888);
        drawOuterNeedle(canvas, rcNeedle, Color.BLACK);

        //Log.i(TAG, "onDraw() - " + getCurPoint());

        //float innerWidth = mRectInner.width();
        //float innerHeight = mRectInner.height();
        //RectF rimRect = new RectF(innerWidth * .05f, innerHeight * .05f, innerWidth * 0.95f, innerHeight * 0.95f);
        //rimRect.offset(mRectInner.left, mRectInner.top);
        //drawInnerRim(canvas, rimRect);
        drawInnerBackground(canvas, mRectInner);

        drawTopAndBottom(canvas, mRectTop, mRectBottom);
        drawGauge(canvas, mRectGauge);
        if (mCircleGaugeHeadDrawListener != null)
            mCircleGaugeHeadDrawListener.onDraw(canvas, mRectGaugeHead);
        if (mCircleGaugeTailDrawListener != null)
            mCircleGaugeTailDrawListener.onDraw(canvas, mRectGaugeTail);

        //canvas.drawText(maTopText, paddingLeft + (contentWidth - mTextWidth) / 2, paddingTop, mTextPaint);

        // Draw the example drawable on top of the text.
        //if (maDrawableUnit != null) {
        //    maDrawableUnit.setBounds(paddingLeft, paddingTop, paddingLeft + contentWidth, paddingTop + contentHeight);
        //    maDrawableUnit.draw(canvas);
        //}
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        //mCanvasWidth = (float) w;
        //mCanvasHeight = (float) h;
        //mCanvasCenterX = w / 2f;
        //mCanvasCenterY = h / 2f;

        recalcLayout();

        super.onSizeChanged(w, h, oldw, oldh);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        /*
        int size;
        int width = getMeasuredWidth();
        int height = getMeasuredHeight();
        int widthWithoutPadding = width - getPaddingLeft() - getPaddingRight();
        int heightWithoutPadding = height - getPaddingTop() - getPaddingBottom();

        if (widthWithoutPadding > heightWithoutPadding) {
            size = heightWithoutPadding;
        } else {
            size = widthWithoutPadding;
        }

        setMeasuredDimension(size + getPaddingLeft() + getPaddingRight(), size + getPaddingTop() + getPaddingBottom());
        */
    }


    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int x = (int)event.getX();
        int y = (int)event.getY();

        if (mCircleGaugeTouchEventListener != null) {
            if (mRectBottom.contains(x, y)) {
                mCircleGaugeTouchEventListener.onTouchEventBottom(event);
            }
            else if (mRectTop.contains(x, y)) {
                mCircleGaugeTouchEventListener.onTouchEventTop(event);
            }
            else if (mRectGauge.contains(x, y)) {
                mCircleGaugeTouchEventListener.onTouchEventGauge(event);
            }
        }

        /*
        int eventAction = event.getAction();
        switch (eventAction) {
            case MotionEvent.ACTION_DOWN:
                break;
            case MotionEvent.ACTION_UP:
                break;
            case MotionEvent.ACTION_MOVE:
                break;
        }
        */

        //Toast.makeText(this.getContext(), "Touched layout", Toast.LENGTH_SHORT).show();
        //Log.d("TOUCH", "Touched layout");
        return super.onTouchEvent(event);
    }

    //---------------------------------
    public interface OnCircleGaugeTouchEventListener {
        boolean onTouchEventTop(MotionEvent event);
        boolean onTouchEventBottom(MotionEvent event);
        boolean onTouchEventGauge(MotionEvent event);
    }
    private OnCircleGaugeTouchEventListener mCircleGaugeTouchEventListener = null;
    public void setOnCircleGaugeTouchEventListener(OnCircleGaugeTouchEventListener listener) { mCircleGaugeTouchEventListener = listener; }


    //---------------------------------
    public interface OnCircleGaugeDrawListener {
        void onDraw(Canvas canvas, Rect clientRect);
    }
    private OnCircleGaugeDrawListener mCircleGaugeHeadDrawListener = null;
    public void setOnCircleGaugeHeadDrawListener(OnCircleGaugeDrawListener listener) { mCircleGaugeHeadDrawListener = listener; }
    private OnCircleGaugeDrawListener mCircleGaugeTailDrawListener = null;
    public void setOnCircleGaugeTailDrawListener(OnCircleGaugeDrawListener listener) { mCircleGaugeTailDrawListener = listener; }
}
