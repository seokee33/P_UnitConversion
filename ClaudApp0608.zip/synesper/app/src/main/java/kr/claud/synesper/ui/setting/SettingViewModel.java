package kr.claud.synesper.ui.setting;

import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import kr.claud.synesper.adapter.SettingsAdapter;

public class SettingViewModel extends ViewModel {

    private static ArrayList<SettingsAdapter.SettingsItem> mArrayList;
    static {
        mArrayList = new ArrayList<>();
    }

    private SettingsAdapter mSettingsAdapter;


    public SettingViewModel() {
        mSettingsAdapter = new SettingsAdapter(mArrayList);
    }

    public void setAdapterItemClickListener(SettingsAdapter.OnItemClickListener l) {
        mSettingsAdapter.setOnItemClickListener(l);
    }

    public ArrayList<SettingsAdapter.SettingsItem> getArrayList() {
        return mArrayList;
    }

    public void clearArrayList() {
        mArrayList.clear();
        mSettingsAdapter.notifyDataSetChanged();
    }

    public SettingsAdapter getAdapter() {
        return mSettingsAdapter;
    }


}