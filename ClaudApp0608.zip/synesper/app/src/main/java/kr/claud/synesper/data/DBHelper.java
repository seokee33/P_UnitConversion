package kr.claud.synesper.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.NotNull;

import kr.claud.libs.datatype.DateUtil;
import kr.claud.synesper.AppData;
import kr.claud.synesper.data.model.LoggedInUser;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 *
 *  Tables:
 *  UserTable (NUM INTEGER PRIMARY KEY AUTOINCREMENT, ID TEXT, PASSWD TEXT, NAME TEXT, WEEK INTEGER, DELIVERY TEXT, EMAIL TEXT)
 *         col_1 = "Num"
 *         col_2 = "ID"
 *         col_3 = "Passwd"
 *         col_4 = "Name"
 *         col_5 = "Week"
 *         col_6 = "Delivery"
 *         col_7 = "Email"
 *  MeasureTable (USER INTEGER, DATE TEXT, BMIN INTEGER, BMAX INTEGER, MMIN INTEGER, MMAX INTEGER)
 *         col_1 = "User"  // Num@UserTable
 *         col_2 = "Date"
 *         col_3 = "Time"
 *         col_4 = "Bmin"
 *         col_5 = "Bmax"
 *         col_6 = "Bavg"
 *         col_7 = "Mmin"
 *         col_8 = "Mmax"
 *         col_9 = "Mavg"
 *         col_10 = "File"
 *  NoticeTable (USER INTEGER, DATE TEXT, TYPE INTEGER, BPM INTEGER)
 *         col_1 = "User"  // Num@UserTable
 *         col_2 = "Date"
 *         col_3 = "Time"
 *         col_4 = "Type"
 *         col_5 = "BPM"
 */
public class DBHelper extends SQLiteOpenHelper {
    private static final String TAG = DBHelper.class.getSimpleName();

    public static final String DATABASE_NAME = "synesper.db";
    public static final String DB_DATE_FORMAT = "yyyy-MM-dd";
    public static final String DB_TIME_FORMAT = "hh:mm:ss";

    public static String stringDateFrom(int year, int month, int day) {
        return DateUtil.stringDateFrom(year, month, day, DB_DATE_FORMAT);
    }

    public static String stringFromDate(Date date) {
        return DateUtil.stringFromDate(date, DB_DATE_FORMAT);
    }

    public static String stringTimeFromDate(Date date) {
        return DateUtil.stringTimeFromDate(date, DB_TIME_FORMAT);
    }

    public static Date dateFrom(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.set(year, month - 1, day);
        return c.getTime();
    }

    public static Date dateFromString(String str) {
        return DateUtil.dateFromString(str, DB_DATE_FORMAT);
    }

    public static Date dateFromString(String str, String fmt) {
        if (fmt == null) {
            fmt = DB_DATE_FORMAT;
        }
        return DateUtil.dateFromString(str, fmt);
    }

    public static Date dateFromString2(@NotNull String szDate, @NonNull String szTime, @NonNull String fmt) {
        if (szDate.length() == 0 || szTime.length() == 0)
            return null;

        String str = szDate + " " + szTime;
        SimpleDateFormat formatter = new SimpleDateFormat(fmt);
        try {
            Date date = formatter.parse(str);
            return date;
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Date dateFromString2(String szDate, String szTime) {
        if (szDate == null || szDate.length() == 0)
            return null;
        if (szTime == null || szTime.length() == 0)
            return null;

        String fmt = DB_DATE_FORMAT + " " + DB_TIME_FORMAT;
        return dateFromString2(szDate, szTime, fmt);
    }

    //------------------------------------

    public class UserTable {
        public String table_name = "user_table";

        public String col_1 = "Num";
        public String col_2 = "ID";
        public String col_3 = "Passwd";
        public String col_4 = "Name";
        public String col_5 = "Delivery";
        public String col_6 = "Email";

        public String stringCreateTable() {
            return "create table " + table_name + "(NUM INTEGER PRIMARY KEY AUTOINCREMENT, ID TEXT, PASSWD TEXT, NAME TEXT, DELIVERY TEXT, EMAIL TEXT)";
        }

        public String stringDropTable() {
            return "DROP TABLE IF EXISTS " + table_name;
        }

        public ContentValues contentValuesInsert(String id, String passwd, String name, String delivery, String email) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_2, id);
            contentValues.put(col_3, passwd);
            contentValues.put(col_4, name);
            contentValues.put(col_5, delivery);
            contentValues.put(col_6, email);
            return contentValues;
        }

        public ContentValues contentValuesUpdate(int num, String id, String passwd, String name, String delivery, String email) {
            ContentValues contentValues = new ContentValues();
            //contentValues.put(col_1, num);
            contentValues.put(col_2, id);
            contentValues.put(col_3, passwd);
            contentValues.put(col_4, name);
            contentValues.put(col_5, delivery);
            contentValues.put(col_6, email);
            return contentValues;
        }
    }

    public static class UserItem {
        public int num;
        public String id;
        public String name;
        public String passwd;
        public String delivery;
        public String email;

        public UserItem() {
            this.num = -1;
            this.id = "";
            this.name = "";
            this.passwd = "";
            this.delivery = "";
            this.email = "";
        }

        public UserItem(int num, String id, String passwd, String name, String delivery, String email) {
            this.num = num;
            this.id = id;
            this.name = name;
            this.passwd = passwd;
            this.delivery = delivery;
            this.email = email;
        }
    }

    //------------------------------------

    public class MeasureTable {
        public String table_name = "meas_table";

        public String col_1 = "User";  // USER Num
        public String col_2 = "Date";
        public String col_3 = "Time";
        public String col_4 = "Bmin";
        public String col_5 = "Bmax";
        public String col_6 = "Bavg";
        public String col_7 = "Mmin";
        public String col_8 = "Mmax";
        public String col_9 = "Mavg";
        public String col_10 = "File";
        public String col_11 = "UploadState";

        public String stringCreateTable() {
            return "create table " + table_name + "(USER INTEGER, DATE TEXT, TIME TEXT, BMIN INTEGER, BMAX INTEGER, BAVG INTEGER, MMIN INTEGER, MMAX INTEGER, MAVG INTEGER, FILE TEXT, UploadState INTEGER, FOREIGN KEY (USER) REFERENCES user_table(NUM) ON DELETE CASCADE)";
            //            return "create table " + table_name + "(USER INTEGER, DATE TEXT, TIME TEXT, BMIN INTEGER, BMAX INTEGER, BAVG INTEGER, MMIN INTEGER, MMAX INTEGER, MAVG INTEGER, FILE TEXT)";
        }

        public String stringDropTable() {
            return "DROP TABLE IF EXISTS " + table_name;
        }

        public ContentValues contentValuesInsert(int userNum, String date, String time, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, Boolean uploadState) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_1, userNum);
            contentValues.put(col_2, date);
            contentValues.put(col_3, time);
            contentValues.put(col_4, bMin);
            contentValues.put(col_5, bMax);
            contentValues.put(col_6, bAvg);
            contentValues.put(col_7, mMin);
            contentValues.put(col_8, mMax);
            contentValues.put(col_9, mAvg);
            contentValues.put(col_10, (file != null) ? file : "");
            contentValues.put(col_11, uploadState);
            return contentValues;
        }

        public ContentValues contentValuesUpdate(int userNum, String date, String time, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, Boolean uploadState) {
            return contentValuesInsert(userNum, date, time, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
        }
    }

    public class MeasureItem {
        public int userNum;
        public String date;
        public String time;
        public int babyMin;
        public int babyMax;
        public int babyAvg;
        public int momMin;
        public int momMax;
        public int momAvg;
        public String file;
        public Boolean uploadState;
        public MeasureItem(int userNum, String date, String time, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, Boolean uploadSate) {
            this.userNum = userNum;
            this.date = date;
            this.time = time;
            this.babyMin = bMin;
            this.babyMax = bMax;
            this.babyAvg = bAvg;
            this.momMin = mMin;
            this.momMax = mMax;
            this.momAvg = mAvg;
            this.file = file;
            this.uploadState = uploadSate;
        }
    }

    //------------------------------------
/*
    public enum DBT_Notice {
        USER ("User", "INTEGER"),
        DATE ("Date", "TEXT"   ),
        TIME ("Time", "TEXT"   ),
        TYPE ("Type", "INTEGER"),
        BPM  ("BPM",  "INTEGER");

        private String name;
        private String dtype;

        DBT_Notice(String name, String dtype) {
            this.name = name;
            this.dtype = dtype;
        }
    }


    public class DBTable {
        public String name;

        public DBTable(String name) {
            this.name = name;
        }

        public String queryCreateTable() {
            return "CREATE TABLE " + name + "(" + ")";
        }

        public String queryDropTable() {
            return "DROP TABLE IF EXISTS " + name;
        }

        public ContentValues contentValuesInsert() {
            ContentValues contentValues = new ContentValues();
            return contentValues;
        }

        public ContentValues contentValuesUpdate() {
            return contentValuesInsert();
        }
    }

    DBTable dbTable = new DBTable("notice", )
*/

    public class NoticeTable {
        public String table_name = "notice_table";

        public String col_1 = "User";  // USER Num
        public String col_2 = "Date";
        public String col_3 = "Time";
        public String col_4 = "Type";
        public String col_5 = "BPM";
        public String col_6 = "AvgMin";
        public String col_7 = "AvgMax";

        public String stringCreateTable() {
            return "create table " + table_name + "(USER INTEGER, DATE TEXT, TIME TEXT, TYPE INTEGER, BPM INTEGER, AvgMin INTEGER, AvgMax INTEGER)";
        }

        public String stringDropTable() {
            return "DROP TABLE IF EXISTS " + table_name;
        }

        public ContentValues contentValuesInsert(int userNum, String date, String time, int type, int bpm, int avgMin, int avgMax) {
            ContentValues contentValues = new ContentValues();
            contentValues.put(col_1, userNum);
            contentValues.put(col_2, date);
            contentValues.put(col_3, time);
            contentValues.put(col_4, type);
            contentValues.put(col_5, bpm);
            contentValues.put(col_6, avgMin);
            contentValues.put(col_7, avgMax);
            return contentValues;
        }

        public ContentValues contentValuesUpdate(int userNum, String date, String time, int type, int bpm, int avgMin, int avgMax) {
            return contentValuesInsert(userNum, date, time, type, bpm, avgMin, avgMax);
        }
    }

    public class NoticeItem {
        public int userNum;
        public String date;
        public String time;
        public int type;  // 0: baby, 1: mom
        public int bpm;
        public int avgMin;
        public int avgMax;

        public NoticeItem(int userNum, String date, String time, int type, int bpm, int avgMin, int avgMax) {
            this.userNum = userNum;
            this.date = date;
            this.time = time;
            this.type = type;
            this.bpm = bpm;
            this.avgMin = avgMin;
            this.avgMax = avgMax;
        }
    }

    //--------------------------------------------------------
    private UserTable userTable;
    private MeasureTable measureTable;
    private NoticeTable noticeTable;

    public DBHelper(Context context, int version) {
        super(context, DATABASE_NAME, null, version);

        userTable = new UserTable();
        measureTable = new MeasureTable();
        noticeTable = new NoticeTable();
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(userTable.stringCreateTable());
        sqLiteDatabase.execSQL(measureTable.stringCreateTable());
        sqLiteDatabase.execSQL(noticeTable.stringCreateTable());
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL(userTable.stringDropTable());
        sqLiteDatabase.execSQL(measureTable.stringDropTable());
        sqLiteDatabase.execSQL(noticeTable.stringDropTable());
        onCreate(sqLiteDatabase);
    }

    public void resetTable(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL(userTable.stringDropTable());
        db.execSQL(measureTable.stringDropTable());
        db.execSQL(noticeTable.stringDropTable());
    }

    public void init() {
        if (selectUser("synesper1").size() == 0) {
            String szDelivery = stringFromDate(new Date());
            insertUser("synesper1", "111111", "clairaudience", szDelivery, "user@claud.com");
        }
    }

    //------------------------------------------------------------
    // User Table
    public boolean insertUser(String id, String passwd, String name, String delivery, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = userTable.contentValuesInsert(id, passwd, name, delivery, email);
        long result = db.insert(userTable.table_name, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllUser() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + userTable.table_name, null);
        return res;
    }

    public Integer deleteUser(String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(userTable.table_name, "ID = ?", new String[]{ id });
    }

    public boolean updateUser(int num, String id, String passwd, String name, String delivery, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = userTable.contentValuesUpdate(num, id, passwd, name, delivery, email);
        db.update(userTable.table_name, contentValues, "ID = ?", new String[] { id });
        return true;
    }

    public ArrayList<UserItem> selectUser(String userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + userTable.table_name + " WHERE ID='" + userId + "'", null);
        ArrayList<UserItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                list.add(new UserItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getString(3), mCursor.getString(4), mCursor.getString(5)));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    public boolean changeLoginUserUpdate(String num, String id, String passwd, String name, String delivery, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<UserItem> items = selectUser(id);
        Log.i("AESPasswd","size : "+items.size()+", PW : "+passwd);
        db.delete(userTable.table_name,null,null);
        ContentValues values = new ContentValues();
        values.put("num",num);
        values.put("id",id);
        values.put("passwd", passwd);
        values.put("name", name);
        values.put("delivery", delivery);
        values.put("email", email);
        int rowsAffected = (int) db.insert(userTable.table_name, null,  values);
        Log.e("changeUserUpdate","UpdateSuccess");
        return rowsAffected > 0;
    }

    public boolean changeUserUpdate(String num, String id, String passwd, String name, String delivery, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ArrayList<UserItem> items = selectUser(id);
        Log.i("AESPasswd","size : "+items.size()+", PW : "+passwd);
        if(items.size()>0){
            if(items.get(0).passwd.equals(passwd)){
                Log.i("changeUserUpdate","success");
                return true;
            }else{
                ContentValues values = new ContentValues();
                values.put("num",num);
                values.put("id",id);
                values.put("passwd", passwd);
                values.put("name", name);
                values.put("delivery", delivery);
                values.put("email", email);
                int rowsAffected = db.update(userTable.table_name, values, "ID = "+id, null);
                Log.e("changeUserUpdate","UpdateSuccess");
                return rowsAffected > 0;
            }
        }else{
            db.delete(userTable.table_name,null,null);
            ContentValues values = new ContentValues();
            values.put("num",num);
            values.put("id",id);
            values.put("passwd", passwd);
            values.put("name", name);
            values.put("delivery", delivery);
            values.put("email", email);
            int rowsAffected = (int) db.insert(userTable.table_name, null,  values);
            Log.e("changeUserUpdate","UpdateSuccess");
            return rowsAffected > 0;
        }

    }

    public int getUserCountById(SQLiteDatabase db, String userId) {
        String[] columns = {"COUNT(*)"};
        String selection = "ID=?";
        String[] selectionArgs = {String.valueOf(userId)};
        Cursor cursor = db.query("user_table", columns, selection, selectionArgs, null, null, null);

        int count = 0;
        if (cursor != null) {
            cursor.moveToFirst();
            count = cursor.getInt(0);
            cursor.close();
        }
        return count;
    }

    //------------------------------------------------------------
    // Measure Table

    // 지정된 날짜와 시간으로 주어진 측정 데이터를 저장한다.
    public boolean insertMeasure(int userNum, Date date, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, Boolean uploadState) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = measureTable.contentValuesInsert(userNum, strDate, strTime, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
        long result = db.insert(measureTable.table_name, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    // 지정된 날짜와 시간에 해당하는 측정 데이터를 삭제한다.
    public Integer deleteMeasure(int userNum, Date date) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(measureTable.table_name, "USER=? AND DATE=? AND TIME=?", new String[] { ""+userNum, strDate, strTime });
    }

    // 지정된 날짜와 시간에 해당하는 측정 데이터를 갱신한다.
    public boolean updateMeasure(int userNum, Date date, int bMin, int bMax, int bAvg, int mMin, int mMax, int mAvg, String file, Boolean uploadState) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = measureTable.contentValuesUpdate(userNum, strDate, strTime, bMin, bMax, bAvg, mMin, mMax, mAvg, file, uploadState);
        db.update(measureTable.table_name, contentValues, "USER=? AND DATE=? AND TIME=?", new String[] { ""+userNum, strDate, strTime });
        return true;
    }

    // 지정된 날짜와 시간의 측정 데이터를 가져온다.
    public ArrayList<MeasureItem> selectMeasure(int userNum, Date date) {
        SQLiteDatabase db = this.getWritableDatabase();
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        Cursor mCursor = db.rawQuery("SELECT * FROM " + measureTable.table_name + " WHERE USER=" + userNum + " AND DATE='" + strDate + "' AND TIME='" + strTime + "'", null);
        ArrayList<MeasureItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                Boolean uploadState = (mCursor.getInt(10)!= 0);
                list.add(new MeasureItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6), mCursor.getInt(7), mCursor.getInt(8), mCursor.getString(9),uploadState));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    // 지정된 날짜의 모든 측정 데이터를 가져온다.
    public ArrayList<MeasureItem> selectMeasures(int userNum, Date date) {
        String strDate = DBHelper.stringFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + measureTable.table_name + " WHERE USER=" + userNum + " AND DATE='" + strDate + "'", null);
        ArrayList<MeasureItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                Boolean uploadState = (mCursor.getInt(10)!= 0);
                list.add(new MeasureItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6), mCursor.getInt(7), mCursor.getInt(8), mCursor.getString(9),uploadState));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    public ArrayList<MeasureItem> selectSyncMeasure(int userNum){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + measureTable.table_name + " WHERE USER=" + userNum + " AND UploadState=" + 0 + "", null);
        ArrayList<MeasureItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                Boolean uploadState = (mCursor.getInt(10)!= 0);
                list.add(new MeasureItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6), mCursor.getInt(7), mCursor.getInt(8), mCursor.getString(9),uploadState));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    public boolean updateSyncMeasure(int userNum, String date, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("UploadState",true);
        int rowsAffected = db.update(measureTable.table_name, values, "USER = "+userNum+" AND "+"DATE = '"+date+"' AND "+"TIME = '"+time+"'", null);
        Log.e("updateSyncMeasure","UpdateSuccess");
        return rowsAffected > 0;
    }

    public ArrayList<MeasureItem> selectMeasureRange(int userNum, Date sdate, Date edate) {
        SQLiteDatabase db = this.getWritableDatabase();
        String szSdate = stringFromDate(sdate);
        String szEdate = stringFromDate(edate);
        Cursor mCursor = db.rawQuery("SELECT * FROM " + measureTable.table_name + " WHERE USER=" + userNum + " AND DATE BETWEEN '" + szSdate + "' AND '" + szEdate + "'", null);
        ArrayList<MeasureItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                Boolean uploadState = (mCursor.getInt(10)!= 0);
                list.add(new MeasureItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6), mCursor.getInt(7), mCursor.getInt(8), mCursor.getString(9),uploadState));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    //---------------------------------------------------------------
    // Notice Table
    public boolean insertNotice(int userNum, Date date, int type, int bpm, int avgMin, int avgMax) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = noticeTable.contentValuesInsert(userNum, strDate, strTime, type, bpm, avgMin, avgMax);
        long result = db.insert(noticeTable.table_name, null, contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    // 지정된 날짜와 시간에 해당하는 측정 데이터를 삭제한다.
    public Integer deleteNotice(int userNum, Date date) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(noticeTable.table_name, "USER=? AND DATE=? AND TIME=?", new String[] { ""+userNum, strDate, strTime });
    }

    // 지정된 날짜와 시간에 해당하는 측정 데이터를 갱신한다.
    public boolean updateNotice(int userNum, Date date, int type, int bpm, int avgMin, int avgMax) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = noticeTable.contentValuesUpdate(userNum, strDate, strTime, type, bpm, avgMin, avgMax);
        db.update(noticeTable.table_name, contentValues, "USER=? AND DATE=? AND TIME=?", new String[] { ""+userNum, strDate, strTime });
        return true;
    }

    // 지정된 날짜와 시간의 측정 데이터를 가져온다.
    public ArrayList<NoticeItem> selectNotice(int userNum, Date date) {
        String strDate = DBHelper.stringFromDate(date);
        String strTime = DBHelper.stringTimeFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + noticeTable.table_name + " WHERE USER=" + userNum + " AND DATE='" + strDate + "' AND TIME='" + strTime + "'", null);
        ArrayList<NoticeItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                list.add(new NoticeItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6)));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    // 지정된 날짜의 모든 측정 데이터를 가져온다.
    public ArrayList<NoticeItem> selectNotices(int userNum, Date date) {
        String strDate = DBHelper.stringFromDate(date);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + noticeTable.table_name + " WHERE USER=" + userNum + " AND DATE='" + strDate + "'", null);
        ArrayList<NoticeItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                list.add(new NoticeItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6)));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }

    public ArrayList<NoticeItem> selectNoticeRange(int userNum, Date sdate, Date edate) {
        SQLiteDatabase db = this.getWritableDatabase();
        String szSdate = stringFromDate(sdate);
        String szEdate = stringFromDate(edate);
        Cursor mCursor = db.rawQuery("SELECT * FROM " + noticeTable.table_name + " WHERE USER=" + userNum + " AND DATE BETWEEN '" + szSdate + "' AND '" + szEdate + "'", null);
        ArrayList<NoticeItem> list = new ArrayList<>();
        if(mCursor.moveToFirst()) {
            do {
                list.add(new NoticeItem(mCursor.getInt(0), mCursor.getString(1), mCursor.getString(2), mCursor.getInt(3), mCursor.getInt(4), mCursor.getInt(5), mCursor.getInt(6)));
            } while(mCursor.moveToNext());
        }
        mCursor.close();
        return list;
    }
}